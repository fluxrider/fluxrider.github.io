/*
 * Written by David Lareau
 * on October 22, 2005
 */

#include "Level.h"

// Construct
Level::Level(void) {
}

Level::~Level(void) {
}

// Methods
MoveType Level::movePlayer(Direction direction) {
	MoveType moveType = FACE;
	Position adjacent = getOffsetPosition(player, direction, 1);
	Position jump = getOffsetPosition(player, direction, 2);
	
	// if box next to me, push
	if(hasBox(adjacent)) {
		// do it if there is space after the box
		Fringe type = getFloorType(jump);
		if(type!=WALL && !hasBox(jump)) {
			player = adjacent;
			boxes.remove(adjacent);
			boxes.push_back(jump);
			moveType = PUSH;
		}
	}
	// walk if floor/target
	else {
		Fringe type = getFloorType(adjacent);
		if(type != WALL) {
			player = adjacent;
			moveType = WALK;
		}
	}
	
	return moveType;
}

string Level::toString() {
	string level = "";
	
	// traverse the grid
	for(size_t r = 0; r < grid.size(); r++) {
		for(size_t c = 0; c < grid[r].size(); c++) {
			Fringe fringe = grid[r][c];
			Position p;
			p.x = c;
			p.y = r;
			switch(fringe) {
				case WALL:
					level += "#";
					break;
				case TARGET:
					if(hasBox(p)) {
						level += "*";
					} else if (p == player) {
						level += "+";
					} else {
						level += ".";
					}
					break;
				case FLOOR:
					if(hasBox(p)) {
						level += "$";
					} else if (p == player) {
						level += "@";
					} else {
						level += " ";
					}
					break;
			}
		}
		level += "\n";
	}
	
	return level;
}

void Level::setLevel(string level) {
	// reset structures
	grid.clear();
	boxes.clear();
	
	// read map and build representation
	int x = 0;
	int y = 0;
	vector<Fringe> row;
	Position p;
	// parse map
	for(size_t i = 0; i < level.size(); i++) {
		char c = level[i];
		switch(c) {
			// wall
			case '#':
				row.push_back(WALL);
				break;
			// floor
			case ' ':
				row.push_back(FLOOR);
				break;
			// target
			case '.':
				row.push_back(TARGET);
				break;
			// identify box
			case '*':
				row.push_back(TARGET);
				p.x = x;
				p.y = y;
				boxes.push_back(p);
				break;
			case '$':
				p.x = x;
				p.y = y;
				boxes.push_back(p);
				row.push_back(FLOOR);
				break;
			// identify player
			case '+':
				row.push_back(TARGET);
				p.x = x;
				p.y = y;
				player = p;
				break;
			case '@':
				p.x = x;
				p.y = y;
				player = p;
				row.push_back(FLOOR);
				break;
			case '\r':
			case '\n':
				if(x!=0) {
					y++; // advance row
					x = 0;
					grid.push_back(row);
					row.clear();
				}
				break;
		}
		if(c != '\n' && c!= '\r') x++; // advance column
	}
	if(!row.empty()) {
		grid.push_back(row);
	}
}

bool Level::hasBox(Position p) {
	// for each box
  list<Position>::const_iterator i;
  for(i = boxes.begin(); i != boxes.end(); i++) {
		// is it at the specified position?
		Position box = *i;
		if(box == p) return true;
  }
	return false;
}

Position Level::getPlayer() {
	return player;
}

Fringe Level::getFloorType(Position p) {
	if(fitsInGrid(p)) {
		return grid[p.y][p.x];
	}
	return WALL;
}

Position Level::getOffsetPosition(Position p, Direction d, int steps) {
	switch(d) {
		case NORTH:
			p.y -= steps;
			break;
		case SOUTH:
			p.y += steps;
			break;
		case EAST:
			p.x += steps;
			break;
		case WEST:
			p.x -= steps;
			break;
	}
	return p;
}

bool Level::fitsInGrid(Position p) {
	return p.y >= 0 && p.x >= 0 && p.y < grid.size() && p.x < grid[p.y].size();
}

bool Level::isSolved(void) {
	// for each box
  list<Position>::const_iterator i;
  for(i = boxes.begin(); i != boxes.end(); i++) {
		// is it not on a target?
		if(grid[(*i).y][(*i).x] != TARGET) return false;
  }
	return true;
}

vector< vector<Fringe> > & Level::getGrid(void) {
	return grid;
}

list<Position> & Level::getBoxes(void) {
	return boxes;
}

int Level::getWidth() {
	int max = 0;
	for(size_t r = 0; r < grid.size(); r++) {
		if(max < grid[r].size()) max = grid[r].size();
	}
	return max;
}

int Level::getHeight() {
	return grid.size();
}
