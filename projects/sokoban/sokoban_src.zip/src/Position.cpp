/*
 * Written by David Lareau
 * on October 22, 2005
 */
 
#include "Position.h"

bool Position::operator ==(Position p) {
	return this->x == p.x && this->y == p.y;
}
