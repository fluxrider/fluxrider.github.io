/*
 * Written by David Lareau
 * on October 22, 2005
 */

#include "SokobanKyra.h"

#include <stdexcept>
#include <iostream>
#include <fstream>
#include <sstream>

#include "resources.h"
#include "directory.h"

using namespace std;
using namespace grinliz;


// Timer callback

#define SDL_TIMER_EVENT ( SDL_USEREVENT + 0 )
const int TIMER_INTERVAL = 40;

Uint32 TimerCallback(Uint32 interval)
{
	SDL_Event event;
	event.type = SDL_TIMER_EVENT;

	SDL_PeepEvents( &event, 1, SDL_ADDEVENT, 0 );
	return TIMER_INTERVAL;
}


// Construct
SokobanKyra::SokobanKyra(bool windowed, bool software, int w, int h, bool nosound)
: screenWidth(w), screenHeight(h), engine(0), levelRoot(0), dialoguePane(0),
nosound(nosound)
{
	SDL_Surface * screen = initSDL(windowed, software);
	initKyra(screen);
	initGameResources();
	if(!nosound)
		startMusic("resources\\music.mid");
}

SokobanKyra::~SokobanKyra(void) {
	if(!nosound) {
		Mix_FreeMusic(music);
		Mix_CloseAudio();
	}
	if(engine) delete engine;
	SDL_Quit();
}

// Methods
void SokobanKyra::start(Sokoban & game) {
	// read map directory & create map list
	initializeLevelList("resources\\levels\\");
	
	// load map
	game.loadMap(levelpath);
	
	// show help
	showHelp();

	// Start timing!
	SDL_SetTimer( TIMER_INTERVAL, TimerCallback );

	// enable keyboard repeat
	SDL_EnableKeyRepeat(50,50);
	
	// hide cursor
	SDL_ShowCursor(SDL_DISABLE);
	
	SDL_Event event;
	bool done = false;
	bool bypassInput = false;
	
	while( !done && SDL_WaitEvent(&event) )
	{
		// shutdown event
		if(event.type == SDL_QUIT)
			done = true;

		// keyboard event
		if(event.type == SDL_KEYDOWN) {
			if(!bypassInput) {
				// allow only one key per tick
				bypassInput = true;
				switch(((SDL_KeyboardEvent&)event).keysym.sym) {
					// change direction
					case SDLK_LEFT:
						game.move(WEST);
						break;
					case SDLK_RIGHT:
						game.move(EAST);
						break;
					case SDLK_UP:
						game.move(NORTH);
						break;
					case SDLK_DOWN:
						game.move(SOUTH);
						break;
					case SDLK_r:
						game.reset();
						break;
					case SDLK_q:
						done = true;
						break;
					case SDLK_EQUALS:
						if(!nosound)
           		Mix_VolumeMusic(MIX_MAX_VOLUME/2);
						break;
					case SDLK_m:
						if(!nosound)
           		Mix_VolumeMusic(0);
						break;
					case SDLK_KP_PLUS:
					case SDLK_PLUS:
						if(!nosound)
           		Mix_VolumeMusic(Mix_VolumeMusic(-1) + 1);
						break;
					case SDLK_KP_MINUS:
					case SDLK_MINUS:
						if(!nosound)
           		Mix_VolumeMusic(Mix_VolumeMusic(-1) - 1);
						break;
					case SDLK_SPACE:
					case SDLK_RETURN:
						hideDialoguePane();
						break;
					case SDLK_LEFTBRACKET:
					case SDLK_PAGEDOWN:
						levelIndex--;
						if(levelIndex < 0) levelIndex = levels.size() - 1;
						levelpath = levels[levelIndex];
           	game.loadMap(levelpath);
						break;
					case SDLK_RIGHTBRACKET:
					case SDLK_PAGEUP:
						levelIndex++;
						if(levelIndex >= levels.size()) levelIndex = 0;
						levelpath = levels[levelIndex];
           	game.loadMap(levelpath);
						break;
					case SDLK_F1:
						showHelp();
						break;
				}
			}
			// ignore bypass for esc key
			if(((SDL_KeyboardEvent&)event).keysym.sym == SDLK_ESCAPE) {
				done = true;
			}
		}

		// timer event
		if(event.type == SDL_TIMER_EVENT) {
			// update the animations
			list<Animation> notExpired;
			bypassInput = false;
		  list<Animation>::const_iterator i;
		  for(i = animations.begin(); i != animations.end(); i++) {
				Animation animation = *i;
				KrSprite * s = animation.sprite;
				
				// change frame
				s->DoStep();
				
				// move toward destination
				int dx = (animation.destination.x - s->X()) / animation.ticksRemaining;
				int dy = (animation.destination.y - s->Y()) / animation.ticksRemaining;
				s->SetPos(s->X() + dx, s->Y() + dy);
				
				// if it's the player moving, handle scrolling
				if(s == playerSprite) {
					handleScrolling(dx,dy);
				}
				
				// decrement tick
				animation.ticksRemaining--;
				
				// see if it ask to bypass anumation
				if(animation.ticksRemaining > 0) {
					bypassInput |= animation.isInputBlocking;
					notExpired.push_back(animation);
				}
				// see if it's expired
				else {
					// put at destination position
					s->SetPos(animation.destination.x, animation.destination.y);
				}
			}

			// remove expired items
			animations.clear();
		  for(i = notExpired.begin(); i != notExpired.end(); i++) {
				animations.push_back(*i);
			}

			// draw scene
			engine->Draw();
		}

	}

}

// Sokoban Listener Interface
void SokobanKyra::onSokobanMap(string map) {
	level.setLevel(map);
	
	// clear display graph
	boxSprites.clear();
	animations.clear();

	if(levelRoot) {
		engine->Tree()->DeleteNode(levelRoot);
		levelRoot = 0;
	}
	hideDialoguePane();

	levelRoot = new KrImNode();
	engine->Tree()->AddNode(0, levelRoot);

	// get dimension of level
	int w = level.getWidth();
	int h = level.getHeight();

	// assumes all tiles are 16x16
	tileSize = 16;

	int baseX = screenWidth/2 - w*tileSize/2;
	int baseY = screenHeight/2 - h*tileSize/2;
	
	// used to center boxes and targets, this is a hack (...)
	int dx = 0;
	int dy = 0;

	KrResource * resource;
	KrImage * image;

	// load background (roof, wall, floor, target)
	vector< vector<Fringe> > grid = level.getGrid();
	for(size_t r = 0; r < grid.size(); r++) {
		for(size_t c = 0; c < grid[r].size(); c++) {
			Fringe fringe = grid[r][c];

			// load the appropriate image
			switch(fringe) {
				case WALL:
					//add a floor under the fire thing first
					resource = engine->Vault()->GetTileResource("floorUL");
					image = new KrTile((KrTileResource*)resource);
					image->SetPos( baseX + c*tileSize, baseY + r*tileSize);
					engine->Tree()->AddNode(levelRoot, image);
					// add the wall/firething
					resource = engine->Vault()->GetSpriteResource("Wall");
					image = new KrSprite((KrSpriteResource*)resource);
					dx = dy = 0;
					break;
				case FLOOR:
					resource = engine->Vault()->GetTileResource("floorUL");
					image = new KrTile((KrTileResource*)resource);
					dx = dy = 0;
					break;
				case TARGET:
					// add a floor under the target first
					resource = engine->Vault()->GetTileResource("floorUL");
					image = new KrTile((KrTileResource*)resource);
					image->SetPos( baseX + c*tileSize, baseY + r*tileSize);
					engine->Tree()->AddNode(levelRoot, image);
					// get the target resource now
					resource = engine->Vault()->GetSpriteResource("Target");
					image = new KrSprite((KrSpriteResource*)resource);
					dx = dy = 1;
					break;
			}

			// add this image to the tree
			image->SetPos( baseX + c*tileSize + dx, baseY + r*tileSize + dy);
			engine->Tree()->AddNode(levelRoot, image);
		}
	}
	
	// add boxes
	dx = 2;
	dy = 1;
	list<Position> boxes = level.getBoxes();
  list<Position>::const_iterator i;
  for(i = boxes.begin(); i != boxes.end(); i++) {
		Position box = *i;

		// load image & add to tree
		resource = engine->Vault()->GetSpriteResource("Box");
		image = new KrSprite((KrSpriteResource*)resource);
		image->SetPos( baseX + box.x*tileSize + dx, baseY + box.y*tileSize + dy);
		engine->Tree()->AddNode(levelRoot, image);
		
		BoxReference reference;
		reference.box = (KrSprite*)image;
		reference.p = box;
		boxSprites.push_back(reference);
  }

	// add player
	Position player = level.getPlayer();
	dy = -4; // gives illusion that player is in the middle of it's floor cell
	dx = 0;
	// load image & add to tree
	resource = engine->Vault()->GetSpriteResource("Player");
	playerSprite = new KrSprite((KrSpriteResource*)resource);
	playerSprite->SetPos( baseX + player.x*tileSize +dx, baseY + player.y*tileSize +dy);
	playerSprite->SetAction("South");
	playerSprite->SetFrame(1);
	engine->Tree()->AddNode(levelRoot, playerSprite);
	
	// center level on player
	dx = screenWidth/2 - playerSprite->X();
	dy = screenHeight/2 - playerSprite->Y();
	levelRoot->SetPos(dx,dy);
}

void SokobanKyra::onSokobanMove(Direction direction, MoveType type) {
	// get adjacent position prior movement
	Position adj = level.getOffsetPosition(level.getPlayer(), direction, 1);
	
	if(type != FACE) level.movePlayer(direction);
	
	// change sprite direction
	switch(direction) {
		case NORTH: playerSprite->SetAction("North"); break;
		case SOUTH: playerSprite->SetAction("South"); break;
		case WEST: playerSprite->SetAction("West"); break;
		case EAST: playerSprite->SetAction("East"); break;
	}
	playerSprite->SetFrame(1);

	// move player if walk/push
	if(type == WALK || type == PUSH) {
		int x = playerSprite->X();
		int y = playerSprite->Y();
		int dx = 0;
		int dy = 0;
		switch(direction) {
			case NORTH: dy = -tileSize; break;
			case SOUTH: dy = tileSize; break;
			case WEST: dx = -tileSize; break;
			case EAST: dx = tileSize; break;
		}
		// set animation
		Animation animation;
		animation.sprite = playerSprite;
		animation.isInputBlocking = true;
		animation.destination.x = x + dx;
		animation.destination.y = y + dy;
		animation.ticksRemaining = 4;
		animations.push_back(animation);

		// move adjacent box if push
		if(type == PUSH) {
			// find sprite for this box
  		list<BoxReference>::const_iterator i;
  		BoxReference reference;
  		for(i = boxSprites.begin(); i != boxSprites.end(); i++) {
				reference = *i;
				if(reference.p == adj) {
					boxSprites.remove(reference);
					break;
				}
			}
			
			// move it
			x = reference.box->X();
			y = reference.box->Y();
			// adbruptly move box to next cell
			animation.sprite = reference.box;
			animation.isInputBlocking = true;
			animation.destination.x = x + dx;
			animation.destination.y = y + dy;
			animation.ticksRemaining = 4;
			animations.push_back(animation);
	    reference.p = level.getOffsetPosition(adj, direction, 1);

			// put it back into the reference list
			// set animation
			boxSprites.push_back(reference);
		}
	}

}

void SokobanKyra::onSokobanSolved(int numberOfSteps) {
	hideDialoguePane();
	stringstream oss;
	oss << "Solved in " << numberOfSteps << " steps";
	string s = oss.str();
	list<string> lines;
	lines.push_back(s);
	showText(lines, true, 165, 214, 165, 150, 150, 150, 200);
}

// Private methods
SDL_Surface * SokobanKyra::initSDL(bool windowed, bool software) {
	SDL_Surface * screen;

	const SDL_version * sdlVersion = SDL_Linked_Version();
	if ( sdlVersion->minor < 2 )
	{
		throw runtime_error("SDL version must be at least 1.2.0");
	}

	/* Initialize the SDL library */
	if ( SDL_Init(SDL_INIT_VIDEO|SDL_INIT_TIMER|SDL_INIT_NOPARACHUTE|SDL_INIT_AUDIO) < 0 ) {
    string code = "Couldn't initialize SDL: ";
		code += SDL_GetError();
 		throw runtime_error(code.c_str());
	}

	/* Create a display for the image */
	Uint32 flags = 0;
	if(!windowed) flags |= SDL_FULLSCREEN;
	if(!software) {
		flags |= SDL_OPENGL;
	} else {
		flags |= SDL_SWSURFACE;
	}

	// get depth
	int depth = 32;
	depth = SDL_VideoModeOK( screenWidth, screenHeight, 32, flags );
	if ( depth < 16 )
		depth = 16;


	if (!software ) {
		SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, depth);
		SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
	}
	
	// set title and icon
	SDL_WM_SetCaption("David Lareau's Sokoban", "David Lareau's Sokoban");
	SDL_WM_SetIcon(SDL_LoadBMP("resources\\icon.bmp"), NULL);
	
	// set video
	screen = SDL_SetVideoMode( screenWidth, screenHeight, depth, flags );
	if ( screen == NULL ) {
		throw runtime_error("Couldn not set video mode");
	}
	
	return screen;
}

void SokobanKyra::initKyra(SDL_Surface * screen) {
	engine = new KrEngine(screen);
	engine->Draw();
}

void SokobanKyra::initGameResources() {
	// Load the resources
	if ( !engine->Vault()->LoadDatFile( "resources\\resources.dat" ) ) {
	  throw runtime_error("Error loading resources.dat");
	}
	fontResource = engine->Vault()->GetFontResource("CONSOLE");
}

void SokobanKyra::showText(list<string> lines, bool showPortrait, int r, int g, int b, int br, int bg, int bb, int ba) {
	// assume things about font
	int w = 6;
	int h = 13;
	int lineSpacing = 2;
	
	int textWidth = 0;
	list<string>::const_iterator line;
	for(line = lines.begin(); line != lines.end(); line++) {
		int width = (*line).size()*w;
		if(textWidth < width) textWidth = width;
	}
	int textHeight = (h + lineSpacing)*lines.size();

	// create text box
	KrTextBox * box = new KrTextBox(fontResource, textWidth, textHeight, lineSpacing);
	int i = 0;
	for(line = lines.begin(); line != lines.end(); line++) {
		box->SetTextChar(*line,i++);
	}

	// adjust color
	KrColorTransform color;
	color = box->CTransform();
	color.Set(r,0,g,0,b,0,255);
	box->SetColor(color);

	// center fancy pane
	int portraitWidth = 39;
	int portraitHeight = 40;
	int margin = 10;
	int gapW = 15;

	KrSprite * portrait;
	if(showPortrait) {
		// get portrait
		KrSpriteResource * resource = engine->Vault()->GetSpriteResource("Portrait");
		portrait = new KrSprite(resource);
	} else {
		portraitWidth = 0;
		portraitHeight = 0;
		gapW = 0;
	}

	int W = textWidth + portraitWidth + gapW + margin*2;
	int H = max(textHeight, portraitHeight) + margin*2;

	// put text inside fancy pane with portrait
	KrRGBA background;
	background.Set(br,bg,bb,ba);
	KrBoxResource * boxResource = new KrBoxResource("FancyPane", W, H, &background, 1, KrBoxResource::FILL);
	KrBox * node = new KrBox(boxResource);
	engine->Tree()->AddNode(0, node);
	engine->Tree()->AddNode(node,box);
	if(showPortrait)
		engine->Tree()->AddNode(node,portrait);

	node->SetPos(screenWidth/2 - W/2, screenHeight/2 - H/2);
	box->SetPos(margin + portraitWidth + gapW, H/2 - textHeight/2);
	if(showPortrait)
		portrait->SetPos(margin, H/2 - portraitHeight/2);

	dialoguePane = node;
}

void SokobanKyra::hideDialoguePane(void) {
	if(dialoguePane) {
		engine->Tree()->DeleteNode(dialoguePane);
		dialoguePane = 0;
	}
}

void SokobanKyra::startMusic(string filename) {
	if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024)==-1) {
		string msg = "Exception in open audio: ";
		msg += Mix_GetError();
		throw runtime_error(msg);
	}
	music=Mix_LoadMUS(filename.c_str());
	if(!music) {
		string msg = "Exception in load mus: ";
		msg += Mix_GetError();
		throw runtime_error(msg);
	}
	// set volume to half
	Mix_VolumeMusic(MIX_MAX_VOLUME/2);
	if(Mix_PlayMusic(music, -1)==-1) {
		string msg = "Exception in play music: ";
		msg += Mix_GetError();
		throw runtime_error(msg);
	}
}

void SokobanKyra::handleScrolling(int dx, int dy) {
	// strategy: always leave 5 tiles ahead
	int threshold = tileSize * 5;
	int x = playerSprite->X() + levelRoot->X();
	int y = playerSprite->Y() + levelRoot->Y();

	if(dx > 0) if(screenWidth - x > threshold) dx = 0;
	if(dx < 0) if(x > threshold) dx = 0;
	if(dy > 0) if(screenHeight - y > threshold) dy = 0;
	if(dy < 0) if(y > threshold) dy = 0;

	levelRoot->SetPos(levelRoot->X() - dx, levelRoot->Y() - dy);
}

void SokobanKyra::showHelp(void) {
  hideDialoguePane();
	list<string> lines;
	lines.push_back("arrows to move/push");
	lines.push_back("[ ] pgup pgdn to change level");
	lines.push_back("r to reset level");
	lines.push_back("q or esc to quit");
	lines.push_back("+ - to change volume");
	lines.push_back("= to reset volume");
	lines.push_back("m to mute volume");
	lines.push_back("space or return to get rid of window");
	lines.push_back("F1 shows this help");
	lines.push_back("");
	lines.push_back("Made by David Lareau");
	lines.push_back("October 2005");
	showText(lines, false, 165, 214, 165, 150, 150, 150, 200);
}

// Level methods
void SokobanKyra::initializeLevelList(string directory) {
	levelIndex = 0;

	// get all subdirectories & itself of directory
	list<FILELIST> directories;
	TransverseDirectory(directory,directories);

	// for each directory
	list<FILELIST>::iterator dir;
	for(dir = directories.begin(); dir != directories.end(); dir++) {
		// for each files inside this dorectory
		vector<string>::iterator files;
		for(files = (*dir).theList.begin(); files != (*dir).theList.end(); files++) {
			string path = (*dir).path + "\\" + (*files);
			levels.push_back(path);
		}
	}

	levelpath = levels[levelIndex];
}

// BoxReference methods
bool BoxReference::operator==(BoxReference r) {
	return r.box == this->box;
}

// Animation methods
bool Animation::operator==(Animation a) {
	return a.sprite == this->sprite;
}
