#ifndef FRINGE_H
#define FRINGE_H

/*
 * Written by David Lareau
 * on October 22, 2005
 */

enum Fringe { WALL, FLOOR, TARGET };

#endif
