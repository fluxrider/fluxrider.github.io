/*
 * Code copied from http://www.daniweb.com/techtalkforums/thread31081.html
 */

#include <io.h>
#include <string>
#include <vector>
#include <list>
#include <iostream>

#include "directory.h"

using namespace std;


void TransverseDirectory(string path, list<FILELIST>& theList)
{
	struct _finddatai64_t data;
	string fname = path + "\\*.*";
	long h = _findfirsti64(fname.c_str(),&data);
	if(h >= 0)
	{
		FILELIST thisList;
		theList.push_back(thisList);
		list<FILELIST>::iterator it = theList.end();
		it--;
		(*it).path = path;
		do {
			if( (data.attrib & _A_SUBDIR) )
			{
				if( strcmp(data.name,".") != 0 &&strcmp(data.name,"..") != 0)
				{
					fname = path + "\\" + data.name;
					TransverseDirectory(fname,theList);
				}
			}
			else
			{
				(*it).theList.push_back(data.name);
			}
		}while( _findnexti64(h,&data) == 0);
		_findclose(h);
	}
}

/*
int main(int argc, char* argv[])
{
	list<FILELIST> MyList;
	string path;
	cout << "Enter starting path ... ";
	getline(cin,path);
	TransverseDirectory(path,MyList);
	list<FILELIST>::iterator it;
	// now just display all the files
	for(it = MyList.begin(); it != MyList.end(); it++)
	{
		vector<string>::iterator its;
		for(its = (*it).theList.begin(); its != (*it).theList.end(); its++)
		{
			cout << (*it).path + "\\" + (*its) << endl;
		}
	}
	cin.ignore();

	system("PAUSE");
	return EXIT_SUCCESS;
}
*/


/*
	list<FILELIST> directories;
	TransverseDirectory(".",directories);

	list<FILELIST>::iterator i;
	for(i = directories.begin(); i != directories.end(); i++) {

		vector<string>::iterator files;
		for(files = (*i).theList.begin(); files != (*i).theList.end(); files++) {
			cout << (*i).path + "\\" + (*files) << endl;
		}
	}
*/
