#ifndef LEVEL_H
#define LEVEL_H

/*
 * Written by David Lareau
 * on October 22, 2005
 */

#include <vector>
#include <list>
#include <string>

#include "Direction.h"
#include "Fringe.h"
#include "Position.h"
#include "MoveType.h"

using namespace std;

class Level {

	// Attributes
	private:
		// game representation
		vector< vector<Fringe> > grid;
		list<Position> boxes;
		Position player;

	// Construct
	public:
		Level(void);
		~Level(void);

	// Methods
	public:
		void setLevel(string level);
		MoveType movePlayer(Direction direction);
		string toString();

		bool hasBox(Position p);
		Fringe getFloorType(Position p);
		Position getOffsetPosition(Position p, Direction d, int steps);
		bool fitsInGrid(Position p);
		
    bool isSolved(void);

		Position getPlayer();
		vector< vector<Fringe> > & getGrid(void);
		list<Position> & getBoxes(void);
		
		int getWidth();
		int getHeight();
};

#endif
