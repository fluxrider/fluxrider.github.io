#ifndef SOKOBAN_LISTENER_H
#define SOKOBAN_LISTENER_H

/*
 * Written by David Lareau
 * on October 15, 2005
 */

#include <string>

#include "Direction.h"
#include "MoveType.h"

using namespace std;

/*
 * The interface sokoban listener must follow to receive the Sokoban events
 */
class SokobanListener {

	// Construct
	public:
		SokobanListener(void);
		virtual ~SokobanListener(void);
	
	// Methods
	public:
		virtual void onSokobanMap(string map); // on start, or reset of a puzzle
		virtual void onSokobanMove(Direction direction, MoveType type); // received when player moves/illegal move/push
		virtual void onSokobanSolved(int numberOfSteps); // received when all box are on targets

};

#endif
