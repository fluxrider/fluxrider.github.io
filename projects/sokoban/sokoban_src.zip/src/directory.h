#ifndef DIRECTORY_F_H
#define DIRECTORY_F_H

#include <string>
#include <list>

using namespace std;

// structure to hold a directory and all its filenames.
struct FILELIST
{
	string path;
	vector<string> theList;
};

void TransverseDirectory(string path, list<FILELIST>& theList);

#endif
