#ifndef POSITION_H
#define POSITION_H

/*
 * Written by David Lareau
 * on October 22, 2005
 */

/**
 * A 2-d position
 */
struct Position {
	int x;
	int y;
	
	bool operator ==(Position p);
};

#endif
