/*
 * Written by David Lareau
 * on October 15, 2005
 */

#include "SokobanListener.h"

// Construct
SokobanListener::SokobanListener(void) {
}
SokobanListener::~SokobanListener(void) {
}

// Methods
void SokobanListener::onSokobanMap(string map) {
}
void SokobanListener::onSokobanMove(Direction direction, MoveType type) {
}
void SokobanListener::onSokobanSolved(int numberOfSteps) {
}
