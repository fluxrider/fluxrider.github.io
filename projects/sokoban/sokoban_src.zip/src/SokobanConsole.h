#ifndef SOKOBAN_CONSOLE_H
#define SOKOBAN_CONSOLE_H

/*
 * Written by David Lareau
 * on October 22, 2005
 */

#include "SokobanListener.h"
#include "Sokoban.h"
#include "Level.h"

/*
 * Win32 Console view/controller of a Sokoban Game
 */
class SokobanConsole : public SokobanListener {

	// Attributes
	private:
		Level level;

	// Construct
	public:
		SokobanConsole(void);
		~SokobanConsole(void);

	// Methods
	public:
		void start(Sokoban & game);

	// Sokoban Listener Interface
	public:
		void onSokobanMap(string map);
		void onSokobanMove(Direction direction, MoveType type);
		void onSokobanSolved(int numberOfSteps);

	// Private methods
	private:
		void drawMap();
		// gui functions
		void clearScreen();
		void gotoxy(int x, int y);
};

#endif
