#ifndef SOKOBAN_KYRA_H
#define SOKOBAN_KYRA_H

/*
 * Written by David Lareau
 * on October 22, 2005
 */

#include <string>

#include "SokobanListener.h"
#include "Sokoban.h"
#include "Level.h"

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <kyra/engine/kyra.h>

#include <list>

using namespace std;

/*
 * SDL/Kyra view/controller of a Sokoban Game
 */
 
struct BoxReference {
  KrSprite * box;
  Position p;
  
  bool operator==(BoxReference r);
};

struct Animation {
	KrSprite * sprite;
	Position destination;
	int ticksRemaining;
	bool isInputBlocking;
	
	bool operator==(Animation a);
};

class SokobanKyra : public SokobanListener {

	// Attributes
	private:
		Level level;
		
		// level attributes
		string levelpath;
		vector<string> levels;
		int levelIndex;

		// gui attributes
		int screenWidth;
		int screenHeight;
		int tileSize;
		KrEngine * engine;
		KrSprite * playerSprite;
		list<BoxReference> boxSprites;
		KrImNode * levelRoot;
		KrFontResource * fontResource;
		list<Animation> animations;
		KrImNode * dialoguePane;
		Mix_Music * music;
		bool nosound;

	// Construct
	public:
		SokobanKyra(bool windowed, bool software, int w, int h, bool nosound);
		~SokobanKyra(void);

	// Methods
	public:
		void start(Sokoban & game);

	// Sokoban Listener Interface
	public:
		void onSokobanMap(string map);
		void onSokobanMove(Direction direction, MoveType type);
		void onSokobanSolved(int numberOfSteps);

	// Private methods
	private:
		// gui methods
		SDL_Surface * initSDL(bool windowed, bool software);
		void initKyra(SDL_Surface * surface);
		void initGameResources();
		void showText(list<string> lines, bool showPortrait, int r, int g, int b, int br, int bg, int bb, int ba);
		void hideDialoguePane(void);
		void startMusic(string filename);
		void handleScrolling(int dx, int dy);
		void showHelp(void);
		
		// level methods
		void initializeLevelList(string directory);
};

#endif
