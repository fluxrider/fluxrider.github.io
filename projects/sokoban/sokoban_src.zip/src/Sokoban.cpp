/*
 * Written by David Lareau
 * on October 16, 2005
 */

#include "Sokoban.h"

#include <fstream>
#include <iostream>

using namespace std;

// Construct
Sokoban::Sokoban(void)
: initialized(false), numberOfSteps(0)
{
	// do nothing
}

Sokoban::~Sokoban(void) {
	// do nothing (since all is allocated on the stack)
}

// Methods

// listener management
void Sokoban::addSokobanListener(SokobanListener * listener) {
	listeners.push_back(listener);
}

void Sokoban::removeSokobanListener(SokobanListener * listener) {
	listeners.remove(listener);
}

// game initialization
void Sokoban::loadMap(string filename) {
	// cleanup previous game if any
	cleanupMap();

	// set initialized ready
	initialized = true;

	// open the file
	ifstream map(filename.c_str());
	
	// read the map
	char c;
	vector<Fringe> row;
	while(!map.eof()){
		c = map.get();
		originalMap += c;
	}
	map.close();

	// build level representation & warn listeners
	reset();
}

// game input
void Sokoban::move(Direction direction) {
	// filter uninitialized
	if(!initialized) return;

	Position player = level.getPlayer();
	Position adjacent = level.getOffsetPosition(player, direction, 1);
	Position jump = level.getOffsetPosition(player, direction, 2);
	MoveType moveType = level.movePlayer(direction);

  // keep statitics up
	if(moveType == WALK || moveType == PUSH) {
		numberOfSteps++;
	}
	
	// warn listeners about move/face/push event
  list<SokobanListener *>::const_iterator i;
  for(i = listeners.begin(); i != listeners.end(); i++) {
		(*i)->onSokobanMove(direction, moveType);
  }

	// check if the puzzle is solved
	if(moveType == PUSH) {
		if(level.isSolved()) {
		  list<SokobanListener *>::const_iterator i;
		  for(i = listeners.begin(); i != listeners.end(); i++) {
				(*i)->onSokobanSolved(numberOfSteps);
		  }
		}
	}
}

void Sokoban::reset(void) {
	// filter uninitialized
	if(!initialized) return;
	
	numberOfSteps = 0;

	// place boxes
	level.setLevel(originalMap);
	
	// send back the original puzzle to the listeners
  list<SokobanListener *>::const_iterator i;
  for(i = listeners.begin(); i != listeners.end(); i++) {
		(*i)->onSokobanMap(originalMap);
  }
}

// Private Methods

/**
 * cleanup previous game if already initialized
*/
void Sokoban::cleanupMap(void) {
  // do nothing if already clean
  if(!initialized) return;
  
  numberOfSteps = 0;
  
  // set to uninitialized
  initialized = false;
  
  // remove original map
  originalMap = "";
}

