/*
 * Written by David Lareau
 * on October 15, 2005
 */

#include <iostream>
#include <conio.h>

#include "Sokoban.h"
// #include "SokobanConsole.h"
#include "SokobanKyra.h"

using namespace std;

/*
 * Main
 */
int main(int argc, char ** argv) {
	try {
		// read command line attributes
		bool nosound = false;
		bool windowed = false;
		bool software = true;
		int w = 320;
		int h = 240;
		if(argc >= 6) {
			w = atoi(argv[1]);
			h = atoi(argv[2]);
			windowed = atoi(argv[3]);
			software = atoi(argv[4]);
			nosound = atoi(argv[5]);
		}

		Sokoban sokoban;
		// SokobanConsole view;
		SokobanKyra view(windowed, software, w, h, nosound);
		sokoban.addSokobanListener(&view);
		view.start(sokoban);
	} catch(exception & e) {
		cout << "Exception: " << e.what() << endl;
	} catch(...) {
		cout << "Exception! ..." << endl;
	}
	
	// exit
	return 0;
}
