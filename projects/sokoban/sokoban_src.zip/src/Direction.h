#ifndef DIRECTION_H
#define DIRECTION_H

/*
 * Written by David Lareau
 * on October 16, 2005
 */
 
enum Direction { NORTH, SOUTH, EAST, WEST };

#endif
