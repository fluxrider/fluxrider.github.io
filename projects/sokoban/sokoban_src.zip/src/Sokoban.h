#ifndef SOKOBAN_H
#define SOKOBAN_H

/*
 * Written by David Lareau
 * on October 15, 2005
 */

#include <list>
#include <vector>
#include <string>

#include "SokobanListener.h"
#include "Direction.h"
#include "Fringe.h"
#include "Position.h"
#include "Level.h"

using namespace std;

/*
 * The event driven internal logic of a Sokoban Game
 */
class Sokoban {

	// Attributes
	private:
		// event management
		list<SokobanListener *> listeners;
		bool initialized;
		
		// game representation
		string originalMap;
		Level level;
		
		// statistics
		int numberOfSteps;

	// Construct
	public:
		Sokoban(void);
		~Sokoban(void);

	// Methods
	public:
		// listener management
		void addSokobanListener(SokobanListener * listener);
		void removeSokobanListener(SokobanListener * listener);
		
		// game initialization
		void loadMap(string filename);
		
		// game input
		void move(Direction direction);
		void reset(void);

	// Private methods
	private:
		void cleanupMap(void);
		
};

#endif
