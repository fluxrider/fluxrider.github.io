/*
 * Written by David Lareau
 * on October 22, 2005
 */

#include "SokobanConsole.h"

#include <windows.h>

#include <iostream>
#include <conio.h>

using namespace std;

// Construct
SokobanConsole::SokobanConsole(void) {
	// do nothing
}

SokobanConsole::~SokobanConsole(void) {
	// do nothing
}

// Methods
void SokobanConsole::start(Sokoban & game) {
	// load map
	game.loadMap("resources\\level00.txt");
	
	// game loop
	while(char c = getch()) {
		switch(c) {
			// reset
			case 'r':
				game.reset();
				break;
			// quit
			case 27:
			case 'q':
				cout << "Quit" << endl;
				return;
			// arrows
			case -32:
				// ignore
				break;
			case 72:
				game.move(NORTH);
				break;
			case 80:
				game.move(SOUTH);
				break;
			case 75:
				game.move(WEST);
				break;
			case 77:
				game.move(EAST);
				break;
			default:
				cout << "Unknown command: " << (int)c << endl;
		}
	}
}

// Sokoban Listener Interface
void SokobanConsole::onSokobanMap(string map) {
	level.setLevel(map);
	drawMap();
}

void SokobanConsole::onSokobanMove(Direction direction, MoveType type) {
	if(type != FACE) level.movePlayer(direction);
	drawMap();
}

void SokobanConsole::onSokobanSolved(int numberOfSteps) {
	cout << "Solved" << endl;
}

// Private methods
void SokobanConsole::drawMap() {
	clearScreen();
	cout << level.toString() << endl;
}

// Private methods for gui
void SokobanConsole::clearScreen() {
	gotoxy(0,0);
	for(int i = 0; i < 25; i++) {
		for( int i = 0; i < 80; i++) {
			cout << " ";
		}
	}
	gotoxy(0,0);
	cout << flush;
}

void SokobanConsole::gotoxy(int x, int y) {
  COORD coord;
  coord.X = x;
  coord.Y = y;
  SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
}
