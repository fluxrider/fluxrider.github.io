#ifndef MOVE_TYPE_H
#define MOVE_TYPE_H

/*
 * Written by David Lareau
 * on October 22, 2005
 */

enum MoveType  { WALK, PUSH, FACE };

#endif
