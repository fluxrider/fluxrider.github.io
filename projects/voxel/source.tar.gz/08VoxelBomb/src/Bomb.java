/*
 * Written by David Lareau on September 17, 2011.
 * 
 * Voxel based Tank Wars clone. 
 */

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.jogamp.newt.opengl.GLWindow;

import flux.geo3D.G;
import flux.geo3D.Line3D;
import flux.geo3D.Point3D;
import flux.gfx.voxel.VoxelModel;
import flux.math.M;
import flux.mem.V;
import flux.opengl.PolledInput;
import flux.opengl.voxel.VoxelEngine;
import flux.random.Perlin;
import flux.random.R;
import flux.time.T;
import flux.time.Timer;
import flux.util.C;

public class Bomb extends VoxelEngine {

	// Attributes
	private int W;
	private int H;
	private int D;
	private int empty = 0;

	private class Player {
		int hp;
		int angle; // cannon y rotation angle
		int direction; // cannon x-z rotation angle
		int power;
		Point3D p = new Point3D(); // centered on x-z, but bottom on y
		int color;
		int cannonColor;

		boolean isDead() {
			return hp <= 0;
		}

		Point3D corner_() {
			Point3D corner = V.Point3D(p);
			corner.x -= tank.getWidth() / 2;
			corner.z -= tank.getDepth() / 2;
			return corner;
		}

	}

	private Player players[];
	private VoxelModel tank;
	private int currentPlayer;

	private Timer inputTick;
	private Timer gravityTick;

	// Construct
	public Bomb(int W, int H, int D, boolean fsaa) {
		super(W, H, D, fsaa);
		this.W = model.getWidth();
		this.H = model.getHeight();
		this.D = model.getDepth();

		try {
			tank = VoxelModel.read(ImageIO.read(new File("res/tank.png")), 1, 7);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

		int n = 3;
		players = new Player[n];
		for (int i = 0; i < n; i++) {
			players[i] = new Player();
		}
		// player color
		players[0].color = C.rgba(196, 64, 64, 255);
		players[0].cannonColor = C.rgba(255, 255, 255, 255);
		players[1].color = C.rgba(64, 196, 64, 255);
		players[1].cannonColor = C.rgba(255, 255, 255, 255);
		players[2].color = C.rgba(64, 64, 196, 255);
		players[2].cannonColor = C.rgba(255, 255, 255, 255);

		reset();

		/*
		model.setRGBA(0, 0, 0, C.rgba(255, 255, 255, 255));
		model.setRGBA(W - 1, 0, 0, C.rgba(255, 255, 255, 255));
		model.setRGBA(0, H - 1, 0, C.rgba(255, 255, 255, 255));
		model.setRGBA(0, 0, D - 1, C.rgba(255, 255, 255, 255));
		*/

		useFakeLight = true;
		//textureOffsetX.y = .001;
		//textureOffsetZ.y = .001;
		// initialize camera
		/*
		usingOrtho = true;
		orthoLeft = -W/2;
		orthoRight = W/2;
		orthoBottom = -100;
		orthoTop = 100;
		orthoNear = 0;
		orthoFar = 2*D;
		*/
		rotx = 35;
		roty = -110;

		inputTick = new Timer();
		gravityTick = new Timer();
	}

	// Tick
	public void reset() {
		clear();
		genTerrain();
		for (Player player : players) {
			// find a place for the tank (x,z denote center of tank)
			int w = tank.getWidth();
			int d = tank.getDepth();
			int hw = (int) Math.ceil(w / 2.0); // half width
			int hd = (int) Math.ceil(d / 2.0); // half depth
			hw = (int) Math.max(hw, getCannonLength());
			hd = (int) Math.max(hd, getCannonLength());
			player.p.x = R.uniform_inclusive_s32(hw, W - 1 - hw);
			player.p.z = R.uniform_inclusive_s32(hd, D - 1 - hd);
			// drop tank there
			player.p.y = H - 1 - getCannonLength();
		}
	}

	public void tick() {
		// Erase Tank and Cannon
		for (Player player : players) {
			draw(player, true);
		}

		// Input
		//if (input.typed(PolledInput.FK_C)) clear();
		//if (input.typed(PolledInput.FK_G)) genTerrain();
		/*
		if (input.typed(PolledInput.FK_LEFT)) roty -= 5;
		if (input.typed(PolledInput.FK_RIGHT)) roty += 5;
		if (input.typed(PolledInput.FK_UP)) rotx -= 5;
		if (input.typed(PolledInput.FK_DOWN)) rotx += 5;
		System.out.println(rotx + " " + roty);
		*/
		if (input.held(PolledInput.FK_ESCAPE)) isRunningMainLoop = false;
		if (input.typed(PolledInput.FK_R)) reset();
		// TODO input repeat rate in ms
		if (inputTick.lastCheck(10)) {
			if (input.held(PolledInput.FK_LEFT)) players[currentPlayer].angle = (players[currentPlayer].angle + 1) % 180;
			if (input.held(PolledInput.FK_RIGHT)) players[currentPlayer].angle = (players[currentPlayer].angle + 179) % 180;
			if (input.held(PolledInput.FK_UP)) players[currentPlayer].power = Math.min(100, players[currentPlayer].power + 1);
			if (input.held(PolledInput.FK_DOWN)) players[currentPlayer].power = Math.max(0, players[currentPlayer].power - 1);
			if (input.held(PolledInput.FK_A)) players[currentPlayer].direction = (players[currentPlayer].direction + 359) % 360;
			if (input.held(PolledInput.FK_S)) players[currentPlayer].direction = (players[currentPlayer].direction + 1) % 360;
		}
		if (input.typed(PolledInput.FK_SPACE)) currentPlayer = (currentPlayer + 1) % players.length;
		if (input.typed(PolledInput.FK_E)) explode(new Point3D(10, 10, 10), 100);
		if (input.typed(PolledInput.FK_C)) clear();

		input.polled();

		gravity(true);

		// Draw Tank and Cannon
		for (Player player : players) {
			draw(player, false);
		}

		// Report FPS
		if (T.lastCheck(1000)) System.out.println(String.format("FPS: %.2f", fps.get()));
	}

	private void gravity(boolean harmless) {
		if (gravityTick.lastCheck(20)) {
			// check under let of player for holes, and fall until completly flat ground (thats the new map case)
			for (Player player : players) {
				boolean falling;
				//do {
				falling = false;
				int y = (int) player.p.y - 1;
				if (y >= 0) {
					Point3D corner = player.corner_();
					for (int z = 0; z < tank.getDepth() && !falling; z++) {
						for (int x = 0; x < tank.getWidth() && !falling; x++) {
							if (tank.has(x, 0, z)) {
								falling |= !model.has((int) (x + corner.x), y, (int) (z + corner.z));
							}
						}
					}
				}
				if (falling) {
					player.p.y--;
				}
				//} while (falling);
			}
		}
	}

	// Methods
	public void draw(VoxelModel image, int x, int y, int z, int color) {
		int w = tank.getWidth();
		int h = tank.getHeight();
		int d = tank.getDepth();
		for (int s = 0; s < d; s++) {
			for (int r = 0; r < h; r++) {
				for (int c = 0; c < w; c++) {
					if (image.has(c, r, s)) {
						model.setRGBA(x + c, y + r, z + s, color);
					}
				}
			}
		}
	}

	public void draw(Player player, boolean clear) {
		draw(tank, (int) player.p.x - tank.getWidth() / 2, (int) player.p.y, (int) player.p.z - tank.getDepth() / 2, clear ? empty : player.color);
		drawCannon(player.p, getCannonLength(), player.direction, player.angle, clear ? empty : player.cannonColor);
	}

	public void drawCannon(Point3D origin, double length, double direction, double angle, int color) {
		//double length = 7;
		//Point3D origin = V.Point3D(10 + tank.getWidth() / 2, 10, 10 + tank.getDepth() / 2);
		// x-z direction
		double dx = Math.cos(Math.toRadians(direction));
		double dz = Math.sin(Math.toRadians(direction));
		// y angle
		double dy = Math.sin(Math.toRadians(angle));
		double factor = Math.cos(Math.toRadians(angle));
		dx *= factor;
		dz *= factor;
		Point3D tip = G.add_(origin, G.mul_(V.Point3D(dx, dy, dz), length));
		// rasterize line
		Draw.draw(V.Line3D(origin, tip), color, model);
	}

	public void genTerrain() {
		int p[] = Perlin.genPermutationTable();
		for (int z = 0; z < D; z++) {
			for (int x = 0; x < W; x++) {
				double noise = Perlin.noise(x / (double) (W - 1), 0, z / (double) (D - 1), p);
				// seems to be within -1 to 1, normalize it from 0 to 1
				noise = (noise + 1) / 2;
				int h = (int) (noise * H);
				for (int y = 0; y < h; y++) {
					// decide on color
					double depth = 1 - (y / (double) (h - 1));
					int color;
					if (depth < .1) color = 176;
					else if (depth > .5) color = 63;
					else color = (int) M.lerp((depth - .1) / .4, 176, 63);
					// draw voxel
					model.setRGBA(x, y, z, C.rgba(73, color, 47, 255));
				}
			}
		}
	}

	public void clear() {
		for (int z = 0; z < D; z++) {
			for (int y = 0; y < H; y++) {
				for (int x = 0; x < W; x++) {
					model.setRGBA(x, y, z, 0);
				}
			}
		}
	}

	public double getCannonLength() {
		return M.max(tank.getWidth(), tank.getHeight(), tank.getDepth());
	}

	private void explode(Point3D p, double radius) {
		// fire growth
		double r2 = radius * radius;
		int fire = C.rgba(255, 0, 0, 255);
		for (int r = 0; r < radius + 1; r++) {
			for (int z = -1; z <= 1; z++) {
				for (int x = -1; x <= 1; x++) {
					for (int y = -1; y <= 1; y++) {
						Point3D q = G.add_(p, V.Point3D(x * r, y * r, z * r));
						System.out.println(q);
						//if (G.sub_(p, q).length2() < r2) {
							if (model.inBounds(q)) model.setRGBA(q, fire);
						//}
					}
				}
			}
		}

		// clear growth
		// death consequence
		// gravity
	}

	// Main
	public static void main(String[] args) {
		VoxelEngine app = new Bomb(200, 128, 200, false);
		//VoxelEngine app = new Bomb(64, 64, 64, false);
		GLWindow window = app.window;
		window.setTitle("VoxelBomb");
		window.setPosition(100, 100);
		window.setSize(800, 600);
		window.setVisible(true);
		window.setUndecorated(true);
		window.setFullscreen(false);
		app.mainLoop();
		window.destroy();
	}
}
