/*
 * Written by David Lareau on September 16, 2011.
 * 
 * Jet Slalom spinoff voxel based logic. 
 */
package flux.tron;

import com.jogamp.newt.opengl.GLWindow;

import flux.geo3D.Point3D;
import flux.opengl.PolledInput;
import flux.opengl.voxel.VoxelEngine;
import flux.random.R;
import flux.time.T;
import flux.time.Timer;
import flux.util.C;

public class Jet extends VoxelEngine {

	// Attributes
	private Timer gameTick;
	private long gameTickDuration; // ms per tick

	private boolean paused;
	private boolean dead;
	private Point3D position;

	// Colors
	private int empty;
	private int ground;
	private int jet;
	private int crash;
	private int wall;
	private int shadow;

	private int W;
	private int H;
	private int D;

	private int requestDeltaY;

	private boolean debug;

	// Construct
	public Jet(int W, int H, int D, long tickDuration, boolean fsaa) {
		super(W, H, D, fsaa);
		this.W = model.getWidth();
		this.H = model.getHeight();
		this.D = model.getDepth();

		// decide on colors
		empty = C.rgba(0, 0, 0, 0);
		ground = C.rgba(64, 128, 64, 255);
		shadow = C.rgba(32, 96, 32, 255);
		wall = C.rgba(128, 128, 128, 255);
		jet = C.rgba(128, 128, 255, 255);
		crash = C.rgba(255, 0, 0, 255);

		// Game parameter
		gameTick = new Timer();
		gameTickDuration = tickDuration;
		position = new Point3D();
		reset();

		// initialize camera
		/*
		usingOrtho = true;
		orthoLeft = -W/2;
		orthoRight = W/2;
		orthoBottom = -100;
		orthoTop = 100;
		orthoNear = 0;
		orthoFar = 2*D;
		*/
		from.z = D;
		rotx = 10;
		roty = 0;
		scale = 1.5;
		fov = 60;
		useFakeLight = true;
		// fix depth buffer aterfact at intersections for this specific view point 
		textureOffsetX.y = -.001;
		textureOffsetZ.y = -.001;
		/*
		from.z = D;
		rotx = 0;
		roty = 0;
		scale = 1.92;
		fov = 95;
		useFakeLight = true;
		// fix depth buffer aterfact at intersections for this specific view point 
		textureOffsetX.y = -.001;
		textureOffsetZ.y = -.001;
		*/
	}

	public void reset() {
		// set ground
		for (int z = 0; z < D; z++) {
			for (int x = 0; x < W; x++) {
				model.setRGBA(x, 0, z, ground);
			}
		}

		// set limit walls
		for (int z = 0; z < D; z++) {
			for (int y = 1; y < H; y++) {
				model.setRGBA(0, y, z, wall);
				model.setRGBA(W - 1, y, z, wall);
			}
		}

		// clear above ground
		for (int z = 0; z < D; z++) {
			for (int y = 1; y < H; y++) {
				for (int x = 1; x < W - 1; x++) {
					model.setRGBA(x, y, z, empty);
				}
			}
		}

		// reset player position
		position.set(W / 2, 1, 1);
		model.setRGBA((int) position.x, (int) position.y, (int) position.z, jet);
		dead = false;
		requestDeltaY = 0;
	}

	// Tick
	public void tick() {
		// Input
		if (input.held(PolledInput.FK_ESCAPE)) isRunningMainLoop = false;

		if (!debug) {
			if (input.typed(PolledInput.FK_R)) reset();
			if (input.typed(PolledInput.FK_P)) paused = !paused;
			if (!dead) {
				if (input.typed(PolledInput.FK_UP)) requestDeltaY++;
				if (input.typed(PolledInput.FK_DOWN)) requestDeltaY--;
			}
		}

		if (debug) {
			if (input.typed(PolledInput.FK_LEFT)) roty -= 5;
			if (input.typed(PolledInput.FK_RIGHT)) roty += 5;
			if (input.typed(PolledInput.FK_UP)) rotx -= 5;
			if (input.typed(PolledInput.FK_DOWN)) rotx += 5;
			if (input.typed(PolledInput.FK_NUMPAD_ADD)) scale *= 1.01;
			if (input.typed(PolledInput.FK_NUMPAD_SUBTRACT)) scale /= 1.01;
			if (input.typed(PolledInput.FK_O)) fov += 1;
			if (input.typed(PolledInput.FK_P)) fov -= 1;
			if (input.typed(PolledInput.FK_K)) near += .1;
			if (input.typed(PolledInput.FK_L)) near -= .1;
			System.out.println(rotx + " " + roty + " " + scale + " " + fov + " " + near);
		}

		// Game Tick
		if (gameTick.lastCheck(gameTickDuration)) {
			if (!paused) {
				// erase jet temporarely
				model.setRGBA((int) position.x, (int) position.y, (int) position.z, empty);
				model.setRGBA((int) position.x, 0, (int) position.z, ground); // erase shadow

				// shift all obstable forward
				shift();
				// generate obstacles
				gen();
				// move jet on input
				if (!debug && !dead) {
					if (input.held(PolledInput.FK_LEFT)) position.x--;
					if (input.held(PolledInput.FK_RIGHT)) position.x++;
				}
				position.y += requestDeltaY;
				requestDeltaY = 0;
				if (position.x <= 0) position.x = 1;
				if (position.x >= W - 1) position.x = W - 2;
				if (position.y <= 0) position.y = 1;
				if (position.y >= H) position.y = H - 1;
				// collision detection
				dead |= model.getRGBA((int) position.x, (int) position.y, (int) position.z) != empty;
				// draw jet
				model.setRGBA((int) position.x, (int) position.y, (int) position.z, dead ? crash : jet);
				model.setRGBA((int) position.x, 0, (int) position.z, shadow);
			}
		}

		// Translate to jet (slow transition)
		translate.x += ((-position.x + W / 2) - translate.x) * .002; // warning: not time based
		//translate.y += ((-position.y + H / 2 - 3) - translate.y) * .005;

		// Misc
		if (T.lastCheck(1000)) {
			System.out.println(String.format("FPS: %.2f", fps.get()));
		}

		if (input.typed(PolledInput.FK_TILDE)) debug = !debug;
		input.polled();
	}

	// Methods
	public void shift() {
		// shift all by one
		for (int z = 0; z < D - 1; z++) {
			for (int y = 0; y < H; y++) {
				for (int x = 1; x < W - 1; x++) {
					int ahead = model.getRGBA(x, y, z + 1);
					model.setRGBA(x, y, z, ahead);
				}
			}
		}

		// clear new row
		int z = D - 1;
		for (int y = 1; y < H; y++) {
			for (int x = 1; x < W - 1; x++) {
				model.setRGBA(x, y, z, empty);
			}
		}
		for (int x = 1; x < W - 1; x++) {
			model.setRGBA(x, 0, z, ground);
		}
	}

	public void gen() {
		int z = D - 1;
		for (int y = 1; y < H; y++) {
			for (int x = 0; x < W; x++) {
				double roll = Math.random();
				// Obstacle
				if (roll > .99) {
					// Bar
					boolean vertical = Math.random() > .5;
					int length = R.d4();
					if (vertical) {
						for (int i = 0; i < length; i++) {
							if (y + i < H) {
								model.setRGBA(x, y + i, z, wall);
							}
						}
						model.setRGBA(x, 0, z, shadow);
					} else {
						for (int i = 0; i < length; i++) {
							if (x + i <= W - 2) {
								model.setRGBA(x + i, y, z, wall);
								model.setRGBA(x + i, 0, z, shadow);
							}
						}
					}
				}
			}
		}
	}

	// Main
	public static void main(String[] args) {
		VoxelEngine app = new Jet(64, 3, 128, 50, false);
		GLWindow window = app.window;
		window.setTitle("Voxel Jet");
		window.setPosition(100, 100);
		window.setSize(800, 600);
		window.setVisible(true);
		window.setUndecorated(true);
		window.setFullscreen(true);
		app.mainLoop();
		window.destroy();
	}
}
