/*
 * A 2D Tron game using a voxel model for logic and rendering
 */
package flux.tron;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.jogamp.newt.opengl.GLWindow;

import flux.geo3D.Point3D;
import flux.opengl.PolledInput;
import flux.opengl.voxel.VoxelEngine;
import flux.time.T;
import flux.time.Timer;
import flux.ui.UI;
import flux.util.C;
import flux.util.E;

public class Tron extends VoxelEngine {

	// Attributes
	private Timer gameTick;
	private long gameTickDuration; // ms per tick
	private Point3D player;
	private int direction;
	private boolean dead;

	private int empty;
	private int wall;
	private int p1, p1tail, blood;
	private int floorY;

	private BufferedImage background;

	private boolean debug;

	// Construct
	public Tron(int W, int H, int D, long tickDuration, boolean fsaa) {
		super(W, H, D, fsaa);

		// decide on colors
		empty = C.rgba(0, 0, 0, 0);
		wall = C.rgba(128, 128, 128, 255);
		p1 = C.rgba(128, 128, 255, 255);
		p1tail = C.rgba(64, 64, 255, 255);
		blood = C.rgba(255, 64, 64, 255);

		// load background image
		try {
			BufferedImage buffer = ImageIO.read(new File("res/s3.bmp"));
			background = new BufferedImage(W, D, BufferedImage.TYPE_INT_RGB);
			Graphics g = background.getGraphics();
			g.setColor(Color.LIGHT_GRAY);
			g.fillRect(0, 0, W, D);
			UI.drawScaledImage(g, buffer, 0, 0, W, D);
		} catch (IOException e) {
			e.printStackTrace();
		}
		floorY = 1;

		// Game parameter
		gameTick = new Timer();
		gameTickDuration = tickDuration;
		player = new Point3D(W / 2, floorY, D / 2);

		reset();

		// initialize camera
		/*
		usingOrtho = true;
		orthoLeft = -W/2;
		orthoRight = W/2;
		orthoBottom = -100;
		orthoTop = 100;
		orthoNear = 0;
		orthoFar = 2*D;
		*/
		from.z = D;
		rotx = 45;
		roty = -15;
		scale = .83;
		useFakeLight = true;
		// fix depth buffer aterfact at intersections for this specific view point 
		textureOffsetX.y = -.01;
		textureOffsetZ.y = -.01;
	}

	public void reset() {
		int W = model.getWidth();
		int H = model.getHeight();
		int D = model.getDepth();

		// floor image
		for (int z = 0; z < D; z++) {
			for (int x = 0; x < W; x++) {
				model.setRGBA(x, 0, z, background.getRGB(x, D - z - 1));
				//model.setRGBA(x, 0, z, p1);
			}
		}

		// clear map
		for (int z = 0; z < D; z++) {
			for (int y = floorY; y < H; y++) {
				for (int x = 0; x < W; x++) {
					model.setRGBA(x, y, z, empty);
				}
			}
		}

		// build limit walls
		for (int z = 0; z < D; z++) {
			for (int y = floorY; y < H; y++) {
				model.setRGBA(0, y, z, wall);
				model.setRGBA(W - 1, y, z, wall);
			}
		}
		for (int x = 0; x < W; x++) {
			for (int y = floorY; y < H; y++) {
				model.setRGBA(x, y, 0, wall);
				model.setRGBA(x, y, D - 1, wall);
			}
		}

		// initialize player position
		model.setRGBA((int) player.x, (int) player.y, (int) player.z, p1);

		// initialize direction
		direction = E.EAST;
		dead = false;
	}

	// Tick
	public void tick() {
		// Input
		if (input.held(PolledInput.FK_ESCAPE)) isRunningMainLoop = false;

		if (!debug) {
			if (input.typed(PolledInput.FK_R)) {
				player.set(model.getWidth() / 2, floorY, model.getDepth() / 2);
				reset();
			}
			if (!dead) {
				if (input.typed(PolledInput.FK_LEFT)) direction = E.leftOf(direction);
				if (input.typed(PolledInput.FK_RIGHT)) direction = E.rightOf(direction);
			}
		}

		if (debug) {
			if (input.typed(PolledInput.FK_LEFT)) roty -= 5;
			if (input.typed(PolledInput.FK_RIGHT)) roty += 5;
			if (input.typed(PolledInput.FK_UP)) rotx -= 5;
			if (input.typed(PolledInput.FK_DOWN)) rotx += 5;
			if (input.typed(PolledInput.FK_R)) {
				//rotx = roty = 0;
				//scale = 1;
				textureOffsetX.set(0, 0, 0);
				textureOffsetY.set(0, 0, 0);
				textureOffsetZ.set(0, 0, 0);
			}
			/*
			if (input.typed(PolledInput.FK_O)) near /= 2;
			if (input.typed(PolledInput.FK_P)) near *= 2;
			if (input.typed(PolledInput.FK_K)) far /= 2;
			if (input.typed(PolledInput.FK_L)) far *= 2;
			if (input.typed(PolledInput.FK_F)) useFakeLight = !useFakeLight;
			if (input.typed(PolledInput.FK_G)) useGLLight = !useGLLight;
			*/
			if (input.typed(PolledInput.FK_I)) textureOffsetX.x -= 0.1;
			if (input.typed(PolledInput.FK_O)) textureOffsetX.y -= 0.1;
			if (input.typed(PolledInput.FK_P)) textureOffsetX.z -= 0.1;
			if (input.typed(PolledInput.FK_J)) textureOffsetY.x -= 0.1;
			if (input.typed(PolledInput.FK_K)) textureOffsetY.y -= 0.1;
			if (input.typed(PolledInput.FK_L)) textureOffsetY.z -= 0.1;
			if (input.typed(PolledInput.FK_B)) textureOffsetZ.x -= 0.1;
			if (input.typed(PolledInput.FK_N)) textureOffsetZ.y -= 0.1;
			if (input.typed(PolledInput.FK_M)) textureOffsetZ.z -= 0.1;
			System.out.println(textureOffsetX + " " + textureOffsetY + " " + textureOffsetZ);

			if (input.typed(PolledInput.FK_NUMPAD_ADD)) scale *= 2;
			if (input.typed(PolledInput.FK_NUMPAD_SUBTRACT)) scale /= 2;
			//System.out.println(near + " " + far);
		}

		if (input.held(PolledInput.FK_TILDE)) debug = !debug;

		input.polled();

		// Game Tick
		if (gameTick.lastCheck(gameTickDuration)) {
			if (!dead) {
				// dim player tail
				model.setRGBA((int) player.x, (int) player.y, (int) player.z, p1tail);
				// move player
				int dx = 0;
				int dz = 0;
				if (direction == E.EAST) dx++;
				else if (direction == E.WEST) dx--;
				else if (direction == E.SOUTH) dz--;
				else if (direction == E.NORTH) dz++;
				// test for collision
				int destination = model.getRGBA((int) player.x + dx, (int) player.y, (int) player.z + dz);
				if (destination == empty) {
					player.x += dx;
					player.z += dz;
				} else {
					// explode
					dead = true;
				}
				// draw player
				model.setRGBA((int) player.x, (int) player.y, (int) player.z, p1);
			} else {
				model.setRGBA((int) player.x, (int) player.y, (int) player.z, blood);
			}
		}

		// Misc
		if (T.lastCheck(1000)) {
			System.out.println(String.format("FPS: %.2f", fps.get()));
		}
	}

	// Methods

	// Main
	public static void main(String[] args) {
		System.out.println("Engage Tron");

		//VoxelEngine app = new Tron(64, 5, 64, 100);
		VoxelEngine app = new Tron(128, 2, 128, 10, false);
		GLWindow window = app.window;
		window.setTitle("Voxel Tron");
		window.setPosition(100, 100);
		window.setSize(800, 600);
		window.setVisible(true);
		window.setUndecorated(true);

		app.mainLoop();
		window.destroy();

		System.out.println("Tron is over and out");
	}
}
