/*
 * Test the VoxelEngine
 */
package flux.tron;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.jogamp.newt.opengl.GLWindow;

import flux.opengl.PolledInput;
import flux.opengl.voxel.VoxelEngine;
import flux.time.T;
import flux.ui.UI;
import flux.util.C;
import flux.util.E;

public class Test extends VoxelEngine {

	// Attributes
	BufferedImage image;

	// Construct
	public Test(int W, int H, int D) {
		super(W, H, D, false);

		try {
			BufferedImage buffer = ImageIO.read(new File("res/s3.bmp"));
			image = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
			Graphics g = image.getGraphics();
			UI.drawScaledImage(g, buffer, 0, 0, W, H);
		} catch (IOException e) {
			e.printStackTrace();
		}

		reset();

		// initialize camera
		from.z = D;
		rotx = 45;
		roty = -15;
		scale = .83;

		this.useFakeLight = true;
		this.fakeLight[E.TOP] = 1;
		this.fakeLight[E.BOTTOM] = .25;
		this.fakeLight[E.FRONT] = .85;
		this.fakeLight[E.REAR] = .40;
		this.fakeLight[E.RIGHT] = .70;
		this.fakeLight[E.LEFT] = .55;
		this.useGLLight = false;
	}

	public void reset() {
		int W = model.getWidth();
		int H = model.getHeight();
		int D = model.getDepth();

		for (int z = 0; z < D; z++) {
			for (int y = 0; y < H; y++) {
				for (int x = 0; x < W; x++) {
					int c = C.random();
					if (Math.random() < .2) c &= 0x00FFFFFF; // set transparent
					else c |= 0xFF000000; // set opaque
					model.setRGBA(x, y, z, c);
				}
			}
		}

		// draw image on z=0 plane
		if (image != null) {
			for (int y = 0; y < H; y++) {
				for (int x = 0; x < W; x++) {
					int rgb = image.getRGB(x, y);
					if (C.gray(rgb) > 10) rgb |= 0xFF000000; // set opaque
					else rgb &= 0x00FFFFFF; // set transparent
					model.setRGBA(x, H - 1 - y, 0, rgb);
				}
			}
		}
	}

	// Tick
	public void tick() {
		// Input
		if (input.held(PolledInput.FK_ESCAPE)) isRunningMainLoop = false;
		if (input.typed(PolledInput.FK_R)) reset();

		if (input.typed(PolledInput.FK_LEFT)) roty -= 5;
		if (input.typed(PolledInput.FK_RIGHT)) roty += 5;
		if (input.typed(PolledInput.FK_UP)) rotx -= 5;
		if (input.typed(PolledInput.FK_DOWN)) rotx += 5;
		if (input.typed(PolledInput.FK_R)) {
			//rotx = roty = 0;
			//scale = 1;
			textureOffsetX.set(0,0,0);
			textureOffsetY.set(0,0,0);
			textureOffsetZ.set(0,0,0);			
		}
		/*
		if (input.typed(PolledInput.FK_O)) near /= 2;
		if (input.typed(PolledInput.FK_P)) near *= 2;
		if (input.typed(PolledInput.FK_K)) far /= 2;
		if (input.typed(PolledInput.FK_L)) far *= 2;
		if (input.typed(PolledInput.FK_F)) useFakeLight = !useFakeLight;
		if (input.typed(PolledInput.FK_G)) useGLLight = !useGLLight;
		*/
		if (input.typed(PolledInput.FK_I)) textureOffsetX.x -= 0.01;
		if (input.typed(PolledInput.FK_O)) textureOffsetX.y -= 0.01;
		if (input.typed(PolledInput.FK_P)) textureOffsetX.z -= 0.01;
		if (input.typed(PolledInput.FK_J)) textureOffsetY.x -= 0.01;
		if (input.typed(PolledInput.FK_K)) textureOffsetY.y -= 0.01;
		if (input.typed(PolledInput.FK_L)) textureOffsetY.z -= 0.01;
		if (input.typed(PolledInput.FK_B)) textureOffsetZ.x -= 0.01;
		if (input.typed(PolledInput.FK_N)) textureOffsetZ.y -= 0.01;
		if (input.typed(PolledInput.FK_M)) textureOffsetZ.z -= 0.01;
		//System.out.println(textureOffsetX + " " + textureOffsetY + " " + textureOffsetZ);		

		if (input.typed(PolledInput.FK_S)) smoothShading = !smoothShading;

		if (input.typed(PolledInput.FK_NUMPAD_ADD)) scale *= 2;
		if (input.typed(PolledInput.FK_NUMPAD_SUBTRACT)) scale /= 2;

		input.polled();

		// Misc
		if (T.lastCheck(1000)) {
			System.out.println(String.format("FPS: %.2f", fps.get()));
		}
	}

	// Methods

	// Main
	public static void main(String[] args) {
		System.out.println("Engage Test");

		//VoxelEngine app = new Test(96, 96, 96);
		VoxelEngine app = new Test(200, 128, 200);
		GLWindow window = app.window;
		window.setTitle("Text Voxel Engine");
		window.setPosition(100, 100);
		window.setSize(800, 600);
		window.setVisible(true);
		window.setUndecorated(true);

		app.mainLoop();
		window.destroy();

		System.out.println("Test is over and out");
	}
}
