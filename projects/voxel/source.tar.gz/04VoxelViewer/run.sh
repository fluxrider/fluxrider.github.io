#!/bin/sh
java -Xms1024M -cp bin_java6sun VoxelViewer
