#!/bin/sh
mkdir bin_java6sun
javac -d bin_java6sun -sourcepath src:../fluxlib/src src/VoxelViewer.java

