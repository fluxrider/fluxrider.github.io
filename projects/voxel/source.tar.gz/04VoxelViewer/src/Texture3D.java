/*
 * Written by David Lareau on September 5, 2011.
 * 
 * 3D Texture utility
 */

import java.nio.ByteBuffer;

import javax.media.opengl.GL;
import javax.media.opengl.GL2;

import flux.gfx.voxel.VoxelModel;
import flux.opengl.voxel.VoxelModelByteBuffer;
import flux.util.C;

public class Texture3D {

	public static int loadTexture(GL2 gl, VoxelModel img, boolean enableLinearInterpolation, int pixelType) {
		int id = genOneTextureID(gl);
		loadTexture(gl, id, img, enableLinearInterpolation, pixelType);
		return id;
	}

	public static int loadTexture(GL2 gl, VoxelModelByteBuffer img, boolean enableLinearInterpolation, int pixelType) {
		int id = genOneTextureID(gl);
		loadTexture(gl, id, img, enableLinearInterpolation, pixelType);
		return id;
	}

	public static void loadTexture(GL2 gl, int textureID, VoxelModel img, boolean enableLinearInterpolation, int pixelType) {
		gl.glActiveTexture(GL2.GL_TEXTURE0);
		gl.glBindTexture(GL2.GL_TEXTURE_3D, textureID);
		loadTexture(gl, img, pixelType);
		gl.glTexParameterf(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_WRAP_S, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameterf(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_WRAP_T, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameteri(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_MIN_FILTER, enableLinearInterpolation ? GL2.GL_LINEAR : GL2.GL_NEAREST);
		gl.glTexParameteri(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_MAG_FILTER, enableLinearInterpolation ? GL2.GL_LINEAR : GL2.GL_NEAREST);
	}

	public static void loadTexture(GL2 gl, int textureID, VoxelModelByteBuffer img, boolean enableLinearInterpolation, int pixelType) {
		gl.glActiveTexture(GL2.GL_TEXTURE0);
		gl.glBindTexture(GL2.GL_TEXTURE_3D, textureID);
		loadTexture(gl, img, pixelType);
		gl.glTexParameterf(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_WRAP_S, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameterf(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_WRAP_T, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameteri(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_MIN_FILTER, enableLinearInterpolation ? GL2.GL_LINEAR : GL2.GL_NEAREST);
		gl.glTexParameteri(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_MAG_FILTER, enableLinearInterpolation ? GL2.GL_LINEAR : GL2.GL_NEAREST);
	}

	public static void loadTexture(GL2 gl, VoxelModel img, int pixelType) {
		// waste memory at the sake of simplicity: make any loaded image full rgba texture
		int W = img.getWidth();
		int H = img.getHeight();
		int D = img.getDepth();
		ByteBuffer data = ByteBuffer.allocateDirect(W * H * D * getPixelDataSize(pixelType));
		loadTexture(img, data, pixelType);
		gl.glTexImage3D(GL2.GL_TEXTURE_3D, 0, getInternalFormat(pixelType), W, H, D, 0, getPixelDataFormat(pixelType), getPixelDataType(pixelType), data);
	}

	public static void loadTexture(GL2 gl, VoxelModelByteBuffer img, int pixelType) {
		// waste memory at the sake of simplicity: make any loaded image full rgba texture
		int W = img.getWidth();
		int H = img.getHeight();
		int D = img.getDepth();
		gl.glTexImage3D(GL2.GL_TEXTURE_3D, 0, getInternalFormat(pixelType), W, H, D, 0, getPixelDataFormat(pixelType), getPixelDataType(pixelType), img.getBuffer());
	}

	public static int genOneTextureID(GL2 gl) {
		final int[] tmp = new int[1];
		gl.glGenTextures(1, tmp, 0);
		return tmp[0];
	}

	public static void delete(GL2 gl, int id) {
		final int[] tmp = new int[1];
		tmp[0] = id;
		gl.glDeleteTextures(1, tmp, 0);
	}

	public static void loadTexture(VoxelModel img, ByteBuffer ptr, int pixelType) {
		switch (pixelType) {
			case GL.GL_RGBA:
				loadRGBATexture(img, ptr);
				break;
			case GL.GL_RGB5_A1:
				loadRGBA5551Texture(img, ptr);
				break;
			default:
				throw new RuntimeException("Unsupported pixel type: " + pixelType);
		}
	}

	public static int getInternalFormat(int pixelType) {
		switch (pixelType) {
			case GL.GL_RGBA:
				return GL.GL_RGBA;
			case GL.GL_RGB5_A1:
				return GL.GL_RGB5_A1;
			default:
				throw new RuntimeException("Unsupported pixel type: " + pixelType);
		}
	}

	public static int getPixelDataFormat(int pixelType) {
		switch (pixelType) {
			case GL.GL_RGBA:
				return GL2.GL_RGBA;
			case GL.GL_RGB5_A1:
				return GL2.GL_RGBA;
			default:
				throw new RuntimeException("Unsupported pixel type: " + pixelType);
		}
	}

	public static int getPixelDataType(int pixelType) {
		switch (pixelType) {
			case GL.GL_RGBA:
				return GL2.GL_UNSIGNED_BYTE;
			case GL.GL_RGB5_A1:
				return GL2.GL_UNSIGNED_SHORT_5_5_5_1;
			default:
				throw new RuntimeException("Unsupported pixel type: " + pixelType);
		}
	}

	public static int getPixelDataSize(int pixelType) {
		switch (pixelType) {
			case GL.GL_RGBA:
				return 4;
			case GL.GL_RGB5_A1:
				return 2;
			default:
				throw new RuntimeException("Unsupported pixel type: " + pixelType);
		}
	}

	public static void loadRGBATexture(VoxelModel img, ByteBuffer ptr) {
		int W = img.getWidth();
		int H = img.getHeight();
		int D = img.getDepth();
		ByteBuffer pixels = ptr; //ByteBuffer.allocateDirect(W * H * D * 4);

		// About the order: Documentation for glTexImage2D says: The first element corresponds to the lower left corner of the texture image. Subsequent elements progress left-to-right through the remaining texels in the lowest row of the texture image, and then in successively higher rows of the texture image. The final element corresponds to the upper right corner of the texture image.
		for (int z = 0; z < D; z++) {
			for (int y = H - 1; y >= 0; y--) {
				for (int x = 0; x < W; x++) {
					int rgb = img.get(x, y, z);
					//pixels.putInt(rgb); // for some reason, the colors is wrong if I go this way (must be a sign or byte order thing)
					pixels.put((byte) C.r(rgb));
					pixels.put((byte) C.g(rgb));
					pixels.put((byte) C.b(rgb));
					pixels.put((byte) C.a(rgb)); // alpha
				}
			}
		}
		pixels.flip();
	}

	public static void loadRGBA5551Texture(VoxelModel img, ByteBuffer ptr) {
		//System.out.println("Begin Load");
		int W = img.getWidth();
		int H = img.getHeight();
		int D = img.getDepth();
		for (int z = 0; z < D; z++) {
			for (int y = H - 1; y >= 0; y--) {
				for (int x = 0; x < W; x++) {
					int rgb = img.get(x, y, z);
					int r = C.r(rgb) / 8;
					int g = C.g(rgb) / 8;
					int b = C.b(rgb) / 8;
					int a = C.isFullyTransparent(rgb) ? 0 : 1;

					int high = (r << 3) | (g >>> 2);
					g &= 3; // keep lower two bytes only (uncessessary)
					int low = (g << 6) | (b << 1) | a;

					//System.out.println(String.format("%dx%dx%d: r%d g%d b%d a%d : r%d g%d b%d a%d : H%s L%s", x, y, z, C.r(rgb), C.g(rgb), C.b(rgb), C.a(rgb), r, C.g(rgb) / 8, b, a, Text.toBinary(high), Text.toBinary(low)));
					//ptr.putShort((short) ((high << 8) | low));
					//ptr.put((byte) high);
					//ptr.put((byte) low);
					ptr.put((byte) low);
					ptr.put((byte) high);
				}
			}
		}
		ptr.flip();
		//System.out.println("End Load");
	}

}
