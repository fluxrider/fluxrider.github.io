/*
 * Written by David Lareau on Septermb 5, 2011.
 * 
 * Viewer of voxel space that changes all the time using opengl using PBO.
 * 
 * Note: Voxatron uses 128x128x64 space
 * TODO: newt, color rgb5551, dxt1 compression (if lossless, don't bother if lossy), voxel model as bytebuffer, GL3 no fixed pipeline
 * 
 * Current benchmark: 96x96x96 gives 50fps (when window size remains default)
 */
import java.awt.BorderLayout;
import java.awt.KeyEventPostProcessor;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;

import javax.imageio.ImageIO;
import javax.media.opengl.GL;
import javax.media.opengl.GL2;
import javax.media.opengl.GL3;
import javax.media.opengl.awt.GLJPanel;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import flux.gfx.voxel.VoxelModel;
import flux.time.T;
import flux.ui.ImageFileFilter;
import flux.ui.Layout;
import flux.ui.UI;
import flux.util.C;
import flux.util.K;
import flux.util.MovingAverage;

public class GLVoxelPBO extends JFrame implements ActionListener, ChangeListener {

	// Attributes
	private K config;
	private final String CONFIG_OPEN_PATH = "open_path";

	private VoxelModel model;
	private int modelTexture;

	private GLJPanel glPanel;
	private GLView glListener;

	private JButton load, gen;
	private JSlider mode;

	private Thread thread;

	private int pboIds[];

	private MovingAverage loadTime;
	private int loadCount;

	private MovingAverage pixelTime;
	private boolean deletePbos;

	// Construct
	public GLVoxelPBO() {
		// Config
		config = new K("config.txt", true, String.format("%s=%s", CONFIG_OPEN_PATH, "."));
		loadTime = new MovingAverage(150);
		pixelTime = new MovingAverage(150);

		// Widget
		glPanel = Geo3DFramework.createPanel();
		glListener = new GLView(glPanel);
		load = new JButton("Load...");
		gen = new JButton("Gen...");
		mode = UI.createHSlider(1, 4, 2, this);
		mode.setMajorTickSpacing(1);

		// Events
		KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventPostProcessor(new KeyEventPostProcessor() {
			public boolean postProcessKeyEvent(KeyEvent e) {
				if (e.getID() == KeyEvent.KEY_PRESSED) {
					Object s = e.getComponent();
					if (!(s instanceof JTextField) && !(s instanceof JTable && ((JTable) s).isEditing())) {
						// do my thing
						glListener.keyPressed(e);
					}
				}
				return true;
			}
		});
		load.addActionListener(this);
		gen.addActionListener(this);

		// Layout
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(glPanel, BorderLayout.CENTER);
		panel.add(Layout.box(BoxLayout.X_AXIS, load, gen), BorderLayout.SOUTH);
		panel.add(mode, BorderLayout.NORTH);
		this.setContentPane(panel);

		// Thread
		thread = new Thread(glListener);
		thread.start();
	}

	// Methods
	public void onLoad() {
		try {
			File file = UI.selectFile(this, new ImageFileFilter(true), true, config, CONFIG_OPEN_PATH);
			if (file != null) {
				BufferedImage image = ImageIO.read(file);
				this.model = VoxelModel.read(image, 1, 2);
				this.modelTexture = -1;
				this.deletePbos = true;
				dirty();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void onGen() {
		int W = Integer.parseInt(JOptionPane.showInputDialog("Width", "10"));
		int H = Integer.parseInt(JOptionPane.showInputDialog("Height", "10"));
		int D = Integer.parseInt(JOptionPane.showInputDialog("Depth", "10"));
		this.model = new VoxelModel(W, H, D);
		for (int z = 0; z < D; z++) {
			for (int y = 0; y < H; y++) {
				for (int x = 0; x < W; x++) {
					int c = C.random();
					if (Math.random() < .2) c &= 0x00FFFFFF; // set transparent
					else c |= 0xFF000000; // set opaque
					model.set(x, y, z, c);
				}
			}
		}
		this.modelTexture = -1;
		this.deletePbos = true;
		dirty();
	}

	public void dirty() {
		glPanel.display();
	}

	// ActionListener
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		if (o == load) onLoad();
		if (o == gen) onGen();
	}

	// ChangeListener
	public void stateChanged(ChangeEvent e) {
	}

	// GL
	private int index = 0;

	private class GLView extends Geo3DFramework implements Runnable {
		public GLView(GLJPanel panel) {
			super(panel, true);
			scale = .1;
			//rotx = 180;
		}

		public void loadModel(GL2 gl) {
			// Load Mode 
			if (deletePbos) {
				if (pboIds != null) gl.glDeleteBuffers(2, pboIds, 0);
				pboIds = null;
				deletePbos = false;
			}
			long t0 = System.nanoTime();
			switch (mode.getValue()) {
				// Fully load every frame, even redo the bytebuffer!
				case 1:
					if (modelTexture != -1) Texture3D.delete(gl, modelTexture);
					modelTexture = Texture3D.loadTexture(gl, model, false, GL.GL_RGBA);
					pixelTime.add(0);
					// on quit I should call Texture3D.delete(gl, modelTexture);
					break;
				// Update using two PBO (1 for application to PBO, and another for PBO to texture object)
				case 2:
					long byteCount = model.getWidth() * model.getHeight() * model.getDepth() * 4;
					if (pboIds == null) {
						pboIds = new int[2];
						gl.glGenBuffers(2, pboIds, 0);
						gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[0]);
						gl.glBufferData(GL2.GL_PIXEL_UNPACK_BUFFER, byteCount, null, GL2.GL_STREAM_DRAW);
						gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[1]);
						gl.glBufferData(GL2.GL_PIXEL_UNPACK_BUFFER, byteCount, null, GL2.GL_STREAM_DRAW);
						gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, 0);
						// on quit you should call glDeleteBuffersARB(2, pboIds, 0);
						// I'm also loading the texture once, but really I just need a texture3D id of the good size allocated
						if (modelTexture != -1) Texture3D.delete(gl, modelTexture);
						modelTexture = Texture3D.loadTexture(gl, model, false, GL.GL_RGBA);
					}

					index = (index + 1) % 2;
					int nextIndex = (index + 1) % 2;

					// bind the texture and PBO
					gl.glBindTexture(GL2.GL_TEXTURE_3D, modelTexture);
					gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[index]);

					// copy pixels from PBO to texture object
					// Use offset instead of ponter.
					gl.glTexSubImage3D(GL2.GL_TEXTURE_3D, 0, 0, 0, 0, model.getWidth(), model.getHeight(), model.getDepth(), GL2.GL_RGBA, GL2.GL_UNSIGNED_BYTE, 0);

					// bind PBO to update pixel values
					gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[nextIndex]);

					// map the buffer object into client's memory
					// Note that glMapBufferARB() causes sync issue.
					// If GPU is working with this buffer, glMapBufferARB() will wait(stall)
					// for GPU to finish its job. To avoid waiting (stall), you can call
					// first glBufferDataARB() with NULL pointer before glMapBufferARB().
					// If you do that, the previous data in PBO will be discarded and
					// glMapBufferARB() returns a new allocated pointer immediately
					// even if GPU is still working with the previous data.
					gl.glBufferData(GL2.GL_PIXEL_UNPACK_BUFFER, byteCount, null, GL2.GL_STREAM_DRAW);
					ByteBuffer ptr = gl.glMapBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, GL2.GL_WRITE_ONLY);
					if (ptr != null) {
						// update data directly on the mapped buffer
						long tp0 = System.nanoTime();
						Texture3D.loadTexture(model, ptr, GL.GL_RGBA);
						pixelTime.add(System.nanoTime() - tp0);
						gl.glUnmapBuffer(GL2.GL_PIXEL_UNPACK_BUFFER); // release pointer to mapping buffer
					}

					// it is good idea to release PBOs with ID 0 after use.
					// Once bound with 0, all pixel operations behave normal ways.
					gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, 0);

					break;
			}
			long t = System.nanoTime() - t0;
			loadTime.add(t);
			loadCount++;
		}

		public void render(GL2 gl) {
			//int buffer[] = new int[10];
			//gl.glGetIntegerv(GL2.GL_MAX_3D_TEXTURE_SIZE, buffer, 0);
			//System.out.println("GL: + " + Arrays.toString(buffer));

			if (model != null) {
				// Note: origin is top left corner of voxel model, positive y going down
				int W = model.getWidth();
				int H = model.getHeight();
				int D = model.getDepth();

				loadModel(gl);

				// draw
				gl.glEnable(GL2.GL_TEXTURE_3D);
				gl.glBindTexture(GL2.GL_TEXTURE_3D, modelTexture);
				gl.glColor4d(1, 1, 1, 1);
				double dx = 1;
				double dy = 1;
				double dz = 1;
				gl.glBegin(GL2.GL_QUADS);
				// draw the z-quads
				for (int reverse = 0; reverse < 2; reverse++) {
					boolean reverseZ = reverse == 1;
					for (int z = 0; z < D; z++) {
						double r = (z / (double) (D - 1));
						if (r == 1) r = .99; // I can't use exactly 1, for me it draws a mix of 0 and 1 if I do.
						gl.glNormal3d(0, 0, reverseZ ? -1 : 1);
						if (reverseZ) {
							gl.glTexCoord3d(0, 0, r);
							gl.glVertex3d(0, 0, -(z + 1) * dz);
							gl.glTexCoord3d(0, 1, r);
							gl.glVertex3d(0, dy * H, -(z + 1) * dz);
							gl.glTexCoord3d(1, 1, r);
							gl.glVertex3d(dx * W, dy * H, -(z + 1) * dz);
							gl.glTexCoord3d(1, 0, r);
							gl.glVertex3d(dx * W, 0, -(z + 1) * dz);
						} else {
							gl.glTexCoord3d(0, 0, r);
							gl.glVertex3d(0, 0, -z * dz);
							gl.glTexCoord3d(1, 0, r);
							gl.glVertex3d(dx * W, 0, -z * dz);
							gl.glTexCoord3d(1, 1, r);
							gl.glVertex3d(dx * W, dy * H, -z * dz);
							gl.glTexCoord3d(0, 1, r);
							gl.glVertex3d(0, dy * H, -z * dz);
						}
					}
				}
				// draw the x-quads
				for (int reverse = 0; reverse < 2; reverse++) {
					boolean reverseX = reverse == 1;
					for (int x = 0; x < W; x++) {
						double s = (x / (double) (W - 1));
						if (s == 1) s = .99;
						gl.glNormal3d(reverseX ? -1 : 1, 0, 0);
						if (reverseX) {
							gl.glTexCoord3d(s, 0, 0);
							gl.glVertex3d(x * dz, 0, 0);
							gl.glTexCoord3d(s, 1, 0);
							gl.glVertex3d(x * dz, dy * H, 0);
							gl.glTexCoord3d(s, 1, 1);
							gl.glVertex3d(x * dz, dy * H, dz * -D);
							gl.glTexCoord3d(s, 0, 1);
							gl.glVertex3d(x * dz, 0, dz * -D);
						} else {
							gl.glTexCoord3d(s, 0, 0);
							gl.glVertex3d((x + 1) * dz, 0, 0);
							gl.glTexCoord3d(s, 0, 1);
							gl.glVertex3d((x + 1) * dz, 0, dz * -D);
							gl.glTexCoord3d(s, 1, 1);
							gl.glVertex3d((x + 1) * dz, dy * H, dz * -D);
							gl.glTexCoord3d(s, 1, 0);
							gl.glVertex3d((x + 1) * dz, dy * H, 0);
						}
					}
				}
				// draw the y-quads
				for (int reverse = 0; reverse < 2; reverse++) {
					boolean reverseY = reverse == 1;
					for (int y = 0; y < H; y++) {
						double t = (y / (double) (H - 1));
						if (t == 1) t = .99;
						gl.glNormal3d(0, reverseY ? -1 : 1, 0);
						if (reverseY) {
							gl.glTexCoord3d(0, t, 0);
							gl.glVertex3d(0, y * dy, 0);
							gl.glTexCoord3d(0, t, 1);
							gl.glVertex3d(0, y * dy, dz * -D);
							gl.glTexCoord3d(1, t, 1);
							gl.glVertex3d(dx * W, y * dy, dz * -D);
							gl.glTexCoord3d(1, t, 0);
							gl.glVertex3d(dx * W, y * dy, 0);
						} else {
							gl.glTexCoord3d(0, t, 0);
							gl.glVertex3d(0, (y + 1) * dy, 0);
							gl.glTexCoord3d(1, t, 0);
							gl.glVertex3d(dx * W, (y + 1) * dy, 0);
							gl.glTexCoord3d(1, t, 1);
							gl.glVertex3d(dx * W, (y + 1) * dy, dz * -D);
							gl.glTexCoord3d(0, t, 1);
							gl.glVertex3d(0, (y + 1) * dy, dz * -D);
						}
					}
				}

				gl.glEnd();
				gl.glBindTexture(GL3.GL_TEXTURE_3D, 0);
				gl.glDisable(GL2.GL_TEXTURE_3D);

			}
		}

		// Runnable
		public void run() {
			T.reset();
			while (thread == Thread.currentThread()) {
				// update model once in while
				if (T.lastCheck(1000)) {
					double t = loadTime.get();
					System.out.println(String.format("FPS: %.2f timer: %.2f  %d   pixel work:%.2f", fps.get(), t, loadCount, 1 - ((t - pixelTime.get()) / t)));
					loadCount = 0;
					if (model != null) rshift(model);
				}
				// repaint as often as you can
				dirty();
				// wait
				T.sleep(1);
			}
		}

		// shift the model to the right (cyclic)
		private void rshift(VoxelModel model) {
			int W = model.getWidth();
			int H = model.getHeight();
			int D = model.getDepth();
			for (int z = 0; z < D; z++) {
				for (int y = 0; y < H; y++) {
					int buffer = model.get(W - 1, y, z);
					for (int x = W - 1; x > 0; x--) {
						model.set(x, y, z, model.get(x - 1, y, z));
					}
					model.set(0, y, z, buffer);
				}
			}
		}
	}

	// Main
	public static void main(String[] args) {
		UI.usualFrameInit(new GLVoxelPBO(), null, true);
	}

}
