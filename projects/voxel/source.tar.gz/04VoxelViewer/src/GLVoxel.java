/*
 * Written by David Lareau on Septermb 5, 2011.
 * 
 * Viewer of voxel space using opengl.
 */
import java.awt.BorderLayout;
import java.awt.KeyEventPostProcessor;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;

import javax.imageio.ImageIO;
import javax.media.opengl.GL;
import javax.media.opengl.GL2;
import javax.media.opengl.GL3;
import javax.media.opengl.awt.GLJPanel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.jogamp.opengl.util.GLBuffers;

import flux.geo3D.Point3D;
import flux.gfx.voxel.VoxelModel;
import flux.mem.V;
import flux.time.T;
import flux.ui.ImageFileFilter;
import flux.ui.UI;
import flux.util.K;
import flux.util.jogl.Axis;
import flux.util.jogl.Matrix4x4;

public class GLVoxel extends JFrame implements ActionListener, ChangeListener {

	// Attributes
	private K config;
	private final String CONFIG_OPEN_PATH = "open_path";

	private VoxelModel model;
	private int modelTexture;
	private int testTexture;

	private GLJPanel glPanel;
	private GLView glListener;

	private JButton load;
	private JSlider mode;

	private Thread thread;

	// Construct
	public GLVoxel() {
		// Config
		config = new K("config.txt", true, String.format("%s=%s", CONFIG_OPEN_PATH, "."));

		// Widget
		glPanel = Geo3DFramework.createPanel();
		glListener = new GLView(glPanel);
		load = new JButton("Load...");
		mode = UI.createHSlider(1, 4, 4, this);

		// Events
		KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventPostProcessor(new KeyEventPostProcessor() {
			public boolean postProcessKeyEvent(KeyEvent e) {
				if (e.getID() == KeyEvent.KEY_PRESSED) {
					Object s = e.getComponent();
					if (!(s instanceof JTextField) && !(s instanceof JTable && ((JTable) s).isEditing())) {
						// do my thing
						glListener.keyPressed(e);
					}
				}
				return true;
			}
		});
		load.addActionListener(this);

		// Layout
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(glPanel, BorderLayout.CENTER);
		panel.add(load, BorderLayout.SOUTH);
		panel.add(mode, BorderLayout.NORTH);
		this.setContentPane(panel);

		// Thread
		thread = new Thread(glListener);
		thread.start();
	}

	// Methods
	public void onLoad() {
		try {
			File file = UI.selectFile(this, new ImageFileFilter(true), true, config, CONFIG_OPEN_PATH);
			if (file != null) {
				BufferedImage image = ImageIO.read(file);
				this.model = VoxelModel.read(image, 1, 2);
				this.modelTexture = -1;
				this.testTexture = -1;
				dirty();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void dirty() {
		glPanel.display();
	}

	// ActionListener
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		if (o == load) onLoad();
	}

	// ChangeListener
	public void stateChanged(ChangeEvent e) {
	}

	// GL
	private class GLView extends Geo3DFramework implements Runnable {
		public GLView(GLJPanel panel) {
			super(panel, true);
			scale = .1;
			//rotx = 180;
		}

		public void render(GL2 gl) {
			//int buffer[] = new int[10];
			//gl.glGetIntegerv(GL2.GL_MAX_3D_TEXTURE_SIZE, buffer, 0);
			//System.out.println("GL: + " + Arrays.toString(buffer));

			if (model != null) {
				// Note: origin is top left corner of voxel model, positive y going down
				int W = model.getWidth();
				int H = model.getHeight();
				int D = model.getDepth();

				// Draw model (immediate mode)
				if (mode.getValue() == 1) {
					for (int z = 0; z < D; z++) {
						for (int y = 0; y < H; y++) {
							for (int x = 0; x < W; x++) {
								if (model.has(x, y, z)) {
									cube(gl, V.Point3D(x + .5, y + .5, z + .5), model.get(x, y, z), 1);
								}
							}
						}
					}
				}

				// Draw mode (nothing)
				if (mode.getValue() == 2) {
				}

				// Draw mode (drawElements text cube, this would be impractical)
				if (mode.getValue() == 3) {
					FloatBuffer vertices = GLBuffers.newDirectFloatBuffer(new float[] { 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0 });
					FloatBuffer colors = GLBuffers.newDirectFloatBuffer(new float[] { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 });
					ByteBuffer indices = GLBuffers.newDirectByteBuffer(new byte[] { 0, 1, 2, 3, 0, 3, 4, 5, 0, 5, 6, 1, 1, 6, 7, 2, 7, 4, 3, 2, 4, 7, 6, 5 });

					gl.glEnableClientState(GL2.GL_VERTEX_ARRAY);
					gl.glEnableClientState(GL2.GL_COLOR_ARRAY);
					gl.glVertexPointer(3, GL2.GL_FLOAT, 0, vertices);
					gl.glColorPointer(3, GL2.GL_FLOAT, 0, colors);
					gl.glDrawElements(GL2.GL_QUADS, 24, GL2.GL_UNSIGNED_BYTE, indices);
					gl.glDisableClientState(GL2.GL_COLOR_ARRAY);
					gl.glDisableClientState(GL2.GL_VERTEX_ARRAY);
				}

				// Draw mode (3d texture on 3 orthogonal quad planes)
				if (mode.getValue() == 4) {
					//gl.glEnable(GL2.GL_BLEND);
					//gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
					//gl.glBlendFunc(GL2.GL_ONE, GL2.GL_ONE);
					//gl.glEnable(GL2.GL_DEPTH_TEST);
					//gl.glDepthFunc(GL2.GL_LEQUAL);

					// test image
					/*
					try {
						if (testTexture == -1) testTexture = Texture2D.loadTexture(gl, ImageIO.read(new File("res/test.png")), false);
					} catch (IOException e) {
						System.err.println(e);
					}
					gl.glEnable(GL2.GL_TEXTURE_2D);
					gl.glBindTexture(GL2.GL_TEXTURE_2D, testTexture);
					gl.glColor4d(1, 1, 1, 1);
					double u = 10;
					gl.glBegin(GL2.GL_QUADS);
					gl.glNormal3d(0, 0, 1);
					gl.glTexCoord2d(0, 0);
					gl.glVertex3d(-u, -u, u);
					gl.glTexCoord2d(1, 0);
					gl.glVertex3d(u, -u, u);
					gl.glTexCoord2d(1, 1);
					gl.glVertex3d(u, u, u);
					gl.glTexCoord2d(0, 1);
					gl.glVertex3d(-u, u, u);
					gl.glEnd();
					gl.glBindTexture(GL3.GL_TEXTURE_2D, 0);
					gl.glDisable(GL2.GL_TEXTURE_2D);
					*/

					// load texture
					if (modelTexture == -1) modelTexture = Texture3D.loadTexture(gl, model, false, GL.GL_RGBA);
					// determine which sides are visible
					// note: this is kinda tough, her eI'm using the lookat vector and rotaitng it by hand by what I know its rotated by (lots of assumption since those rotation are technically in the parent class), all in reverse order
					// note: this is buggy
					Point3D lookat = V.Point3D(-.5, -.5, -2);
					Matrix4x4 m = new Matrix4x4();
					m.identity();
					m.rotate((float) roty, Axis.Y);
					m.rotate((float) rotx, Axis.X);
					//m.scale((float) scale, (float) scale, (float) scale);
					m.translate((float) lookat.x, (float) lookat.y, (float) lookat.z);
					lookat.x = m.m[12];
					lookat.y = m.m[13];
					lookat.z = m.m[14];
					//System.out.println(lookat);
					boolean reverseX = lookat.x > 0;
					boolean reverseY = lookat.y < 0;
					boolean reverseZ = lookat.z > 0;
					// draw
					gl.glEnable(GL2.GL_TEXTURE_3D);
					gl.glBindTexture(GL2.GL_TEXTURE_3D, modelTexture);
					gl.glColor4d(1, 1, 1, 1);
					double dx = 1;
					double dy = 1;
					double dz = 1;
					gl.glBegin(GL2.GL_QUADS);
					// draw the z-quads
					for (int z = 0; z < D; z++) {
						double r = (z / (double) (D - 1));
						if (r == 1) r = .99; // I can't use exactly 1, for me it draws a mix of 0 and 1 if I do.
						gl.glNormal3d(0, 0, reverseZ ? -1 : 1);
						if (reverseZ) {
							gl.glTexCoord3d(0, 0, r);
							gl.glVertex3d(0, 0, -(z + 1) * dz);
							gl.glTexCoord3d(0, 1, r);
							gl.glVertex3d(0, dy * H, -(z + 1) * dz);
							gl.glTexCoord3d(1, 1, r);
							gl.glVertex3d(dx * W, dy * H, -(z + 1) * dz);
							gl.glTexCoord3d(1, 0, r);
							gl.glVertex3d(dx * W, 0, -(z + 1) * dz);
						} else {
							gl.glTexCoord3d(0, 0, r);
							gl.glVertex3d(0, 0, -z * dz);
							gl.glTexCoord3d(1, 0, r);
							gl.glVertex3d(dx * W, 0, -z * dz);
							gl.glTexCoord3d(1, 1, r);
							gl.glVertex3d(dx * W, dy * H, -z * dz);
							gl.glTexCoord3d(0, 1, r);
							gl.glVertex3d(0, dy * H, -z * dz);
						}
					}
					// draw the x-quads
					for (int x = 0; x < W; x++) {
						double s = (x / (double) (W - 1));
						if (s == 1) s = .99;
						gl.glNormal3d(reverseX ? -1 : 1, 0, 0);
						if (reverseX) {
							gl.glTexCoord3d(s, 0, 0);
							gl.glVertex3d(x * dz, 0, 0);
							gl.glTexCoord3d(s, 1, 0);
							gl.glVertex3d(x * dz, dy * H, 0);
							gl.glTexCoord3d(s, 1, 1);
							gl.glVertex3d(x * dz, dy * H, dz * -D);
							gl.glTexCoord3d(s, 0, 1);
							gl.glVertex3d(x * dz, 0, dz * -D);
						} else {
							gl.glTexCoord3d(s, 0, 0);
							gl.glVertex3d((x + 1) * dz, 0, 0);
							gl.glTexCoord3d(s, 0, 1);
							gl.glVertex3d((x + 1) * dz, 0, dz * -D);
							gl.glTexCoord3d(s, 1, 1);
							gl.glVertex3d((x + 1) * dz, dy * H, dz * -D);
							gl.glTexCoord3d(s, 1, 0);
							gl.glVertex3d((x + 1) * dz, dy * H, 0);
						}
					}
					// draw the y-quads
					for (int y = 0; y < H; y++) {
						double t = (y / (double) (H - 1));
						if (t == 1) t = .99;
						gl.glNormal3d(0, reverseY ? -1 : 1, 0);
						if (reverseY) {
							gl.glTexCoord3d(0, t, 0);
							gl.glVertex3d(0, y * dy, 0);
							gl.glTexCoord3d(0, t, 1);
							gl.glVertex3d(0, y * dy, dz * -D);
							gl.glTexCoord3d(1, t, 1);
							gl.glVertex3d(dx * W, y * dy, dz * -D);
							gl.glTexCoord3d(1, t, 0);
							gl.glVertex3d(dx * W, y * dy, 0);
						} else {
							gl.glTexCoord3d(0, t, 0);
							gl.glVertex3d(0, (y + 1) * dy, 0);
							gl.glTexCoord3d(1, t, 0);
							gl.glVertex3d(dx * W, (y + 1) * dy, 0);
							gl.glTexCoord3d(1, t, 1);
							gl.glVertex3d(dx * W, (y + 1) * dy, dz * -D);
							gl.glTexCoord3d(0, t, 1);
							gl.glVertex3d(0, (y + 1) * dy, dz * -D);
						}
					}

					gl.glEnd();
					gl.glBindTexture(GL3.GL_TEXTURE_3D, 0);
					gl.glDisable(GL2.GL_TEXTURE_3D);

					// restore
					gl.glEnable(GL2.GL_BLEND);
					gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
					gl.glEnable(GL2.GL_DEPTH_TEST);
					gl.glDepthFunc(GL2.GL_LEQUAL);

				}
			}
		}

		// Runnable
		public void run() {
			T.reset();
			while (thread == Thread.currentThread()) {
				dirty();
				if (T.lastCheck(1000)) System.out.println(fps.get());
				T.sleep(1);
			}
		}
	}

	// Main
	public static void main(String[] args) {
		UI.usualFrameInit(new GLVoxel(), null, true);
	}

}
