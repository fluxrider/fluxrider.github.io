/*
 * Written by David Lareau on August 27, 2011.
 * 
 * Viewer of voxel models.
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.KeyEventPostProcessor;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.media.opengl.GL2;
import javax.media.opengl.awt.GLJPanel;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import flux.geo3D.G;
import flux.geo3D.Line3D;
import flux.geo3D.Point3D;
import flux.gfx.voxel.VoxelModel;
import flux.math.M;
import flux.mem.V;
import flux.ui.ImageFileFilter;
import flux.ui.Layout;
import flux.ui.UI;
import flux.util.C;
import flux.util.K;

public class VoxelViewer extends JFrame implements ActionListener, ChangeListener {

	// Attributes
	private K config;
	private final String CONFIG_OPEN_PATH = "open_path";

	private VoxelModel model;

	private JPanel preview;
	private JButton load;
	private JSlider eyeX, eyeY, eyeZ;
	private JSlider tlX, tlY, tlZ;
	private JSlider trX, trY, trZ;
	private JSlider blX, blY, blZ;
	private JSlider resolutionW;
	//private JSlider resolutionH;
	private JSlider version;

	private BufferedImage output;
	private Point3D eye = new Point3D();
	private Point3D topLeft = new Point3D();
	private Point3D topRight = new Point3D();
	private Point3D bottomLeft = new Point3D();

	/*
		private RadialSelect rotX, rotY, rotZ;
		private JSlider eyeDistance;
		private JSlider planeDistance;
		private JSlider planeW, planeH;
		private JSlider atX, atY, atZ;
	*/

	private GLJPanel glPanel;
	private Geo3DFramework glListener;

	// Construct
	public VoxelViewer() {
		// Config
		config = new K("config.txt", true, String.format("%s=%s", CONFIG_OPEN_PATH, "."));

		// Output Buffer for voxel rendering
		output = new BufferedImage(32, 32, BufferedImage.TYPE_INT_RGB);

		// Widget
		preview = new JPanel() {
			public void paint(Graphics g) {
				paintPreview((Graphics2D) g, getWidth(), getHeight());
			}
		};
		load = new JButton("Load...");
		eyeX = UI.createHSlider(-10, 10, 4, this);
		eyeY = UI.createHSlider(-10, 10, 4, this);
		eyeZ = UI.createHSlider(-100, 100, -10, this);
		tlX = UI.createHSlider(-20, 20, 0, this);
		tlY = UI.createHSlider(-20, 20, 0, this);
		tlZ = UI.createHSlider(-20, 20, -5, this);
		trX = UI.createHSlider(-20, 20, 7, this);
		trY = UI.createHSlider(-20, 20, 0, this);
		trZ = UI.createHSlider(-20, 20, -5, this);
		blX = UI.createHSlider(-20, 20, 0, this);
		blY = UI.createHSlider(-20, 20, 7, this);
		blZ = UI.createHSlider(-20, 20, -5, this);
		resolutionW = UI.createHSlider(1, 250, 32, this);
		//resolutionH = UI.createHSlider(1, 500, 32, this);
		version = UI.createHSlider(1, 3, 1, this);

		glPanel = Geo3DFramework.createPanel();
		glListener = new GLView(glPanel);

		/*
		rotX = new RadialSelect(1, 0, 1, 1);
		rotY = new RadialSelect(1, 0, 1, 1);
		rotZ = new RadialSelect(1, 0, 1, 1);
		eyeDistance = UI.createHSlider(0, 100, 20, this);
		planeDistance = UI.createHSlider(0, 100, 10, this);
		planeW = UI.createHSlider(1, 100, 10, this);
		planeH = UI.createHSlider(1, 100, 10, this);
		atX = UI.createHSlider(-20, 20, 0, this);
		atY = UI.createHSlider(-20, 20, 0, this);
		atZ = UI.createHSlider(-20, 20, 0, this);
		*/

		//KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher()
		KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventPostProcessor(new KeyEventPostProcessor() {

			public boolean postProcessKeyEvent(KeyEvent e) {
				if (e.getID() == KeyEvent.KEY_PRESSED) {
					Object s = e.getComponent();
					if (!(s instanceof JTextField) && !(s instanceof JTable && ((JTable) s).isEditing())) {
						// do my thing
						glListener.keyPressed(e);
					}
				}
				return true;
			}
		});

		// Event
		load.addActionListener(this);

		// Layout
		JPanel grid = new JPanel(new GridLayout(1, 2));
		grid.add(preview);
		grid.add(glPanel);
		JPanel panel = new JPanel(new BorderLayout());
		panel.add(grid, BorderLayout.CENTER);
		panel.add(Layout.box(BoxLayout.X_AXIS, load, new JButton("Focus Trap")), BorderLayout.SOUTH);
		panel.add(Layout.box(BoxLayout.Y_AXIS, new JLabel("Algo"), version, new JLabel("Resolution"), resolutionW, /*resolutionH,*/new JLabel("Eye"), eyeX, eyeY, eyeZ, new JLabel("Plane TopLeft"), tlX, tlY, tlZ, new JLabel("Plane TopRight"), trX, trY, trZ, new JLabel("Plane BottomLeft"), blX, blY, blZ), BorderLayout.EAST);
		//panel.add(Layout.box(BoxLayout.Y_AXIS, Layout.box(BoxLayout.X_AXIS, rotX, rotY, rotZ), new JLabel("Resolution"), resolutionW, resolutionH, new JLabel("Eye Distance"), eyeDistance, new JLabel("Plane Distance"), planeDistance, new JLabel("Plane WxH"), planeW, planeH, new JLabel("Lookat Delta"), atX, atY, atZ), BorderLayout.EAST);
		this.setContentPane(panel);

		// Misc
		stateChanged(null);
	}

	// Methods
	public void onLoad() {
		try {
			File file = UI.selectFile(this, new ImageFileFilter(true), true, config, CONFIG_OPEN_PATH);
			if (file != null) {
				BufferedImage image = ImageIO.read(file);
				this.model = VoxelModel.read(image, 1, 2);
				dirty();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void paintPreview(Graphics2D g, int W, int H) {
		// Draw output buffer (stretched to fit)
		g.drawImage(output, 0, 0, W, H, null);
		//if(model != null) g.drawImage(getSlice(model,1), 0, 0, W, H, null);
	}

	public void dirty() {
		renderModel();
		preview.repaint();
		glPanel.display();
	}

	private Point3D horizontalStep = new Point3D(); // buffer
	private Point3D verticalStep = new Point3D(); // buffer
	private Point3D dy = new Point3D(); // buffer

	private void renderModel() {
		if (model != null) {
			// Note: origin is top left corner of voxel model, positive y going down
			int W = model.getWidth();
			int H = model.getHeight();
			int D = model.getDepth();
			int outW = output.getWidth();
			int outH = output.getHeight();
			Graphics2D g = (Graphics2D) output.getGraphics();

			// Clear
			g.setColor(Color.BLACK);
			g.fillRect(0, 0, outW, outH);

			// Render voxel model on output surface

			// VERSION 1: use a single ray on center of pixel
			if (version.getValue() == 1) {
				G.div(G.sub_(topRight, topLeft), outW, horizontalStep);
				G.div(G.sub_(bottomLeft, topLeft), outH, verticalStep);
				for (int y = 0; y < outH; y++) {
					G.mul(verticalStep, y, dy);
					for (int x = 0; x < outW; x++) {
						Point3D dx = G.mul_(horizontalStep, x);
						Point3D pixel = G.add_(topLeft, G.add_(dx, dy));
						Point3D gaze = G.sub_(pixel, eye);
						int voxel = findVoxel(eye, gaze, model);
						output.setRGB(x, y, voxel);
					}
				}
			}

			// VERSION 2: use a single ray on each pixel corner, and average the 4 color evenly
			if (version.getValue() == 2) {
				int buffer[][] = new int[outW + 1][outH + 1]; // I could only use 2 rows but this is a test so whatever
				G.div(G.sub_(topRight, topLeft), outW, horizontalStep);
				G.div(G.sub_(bottomLeft, topLeft), outH, verticalStep);
				for (int y = 0; y <= outH; y++) {
					G.mul(verticalStep, y - .5, dy);
					for (int x = 0; x <= outW; x++) {
						Point3D dx = G.mul_(horizontalStep, x - .5);
						Point3D pixel = G.add_(topLeft, G.add_(dx, dy));
						Point3D gaze = G.sub_(pixel, eye);
						int voxel = findVoxel(eye, gaze, model);
						buffer[x][y] = voxel;
					}
				}
				// average
				int rgbs[] = new int[4];
				int ns[] = new int[4];
				for (int y = 0; y < outH; y++) {
					for (int x = 0; x < outW; x++) {
						rgbs[0] = buffer[x][y];
						rgbs[1] = buffer[x + 1][y];
						rgbs[2] = buffer[x][y + 1];
						rgbs[3] = buffer[x + 1][y + 1];
						ns[0] = ns[1] = ns[2] = ns[3] = 1;
						int voxel = C.blendN(rgbs, ns, 0, 4);
						output.setRGB(x, y, voxel);
					}
				}
			}

			// VERSION 3: version 2 + version 1 (corners + center, center has a bigger weight)
			if (version.getValue() == 3) {
				// corners
				int buffer[][] = new int[outW + 1][outH + 1];
				G.div(G.sub_(topRight, topLeft), outW, horizontalStep);
				G.div(G.sub_(bottomLeft, topLeft), outH, verticalStep);
				for (int y = 0; y <= outH; y++) {
					G.mul(verticalStep, y - .5, dy);
					for (int x = 0; x <= outW; x++) {
						Point3D dx = G.mul_(horizontalStep, x - .5);
						Point3D pixel = G.add_(topLeft, G.add_(dx, dy));
						Point3D gaze = G.sub_(pixel, eye);
						int voxel = findVoxel(eye, gaze, model);
						buffer[x][y] = voxel;
					}
				}
				// centers
				int centers[][] = new int[outW][outH];
				for (int y = 0; y < outH; y++) {
					G.mul(verticalStep, y, dy);
					for (int x = 0; x < outW; x++) {
						Point3D dx = G.mul_(horizontalStep, x);
						Point3D pixel = G.add_(topLeft, G.add_(dx, dy));
						Point3D gaze = G.sub_(pixel, eye);
						int voxel = findVoxel(eye, gaze, model);
						centers[x][y] = voxel;
					}
				}
				// average
				int rgbs[] = new int[5];
				int ns[] = new int[5];
				for (int y = 0; y < outH; y++) {
					for (int x = 0; x < outW; x++) {
						rgbs[0] = buffer[x][y];
						rgbs[1] = buffer[x + 1][y];
						rgbs[2] = buffer[x][y + 1];
						rgbs[3] = buffer[x + 1][y + 1];
						rgbs[4] = centers[x][y];
						ns[0] = ns[1] = ns[2] = ns[3] = 1;
						ns[4] = 4;
						int voxel = C.blendN(rgbs, ns, 0, 5);
						output.setRGB(x, y, voxel);
					}
				}
			}

		}
	}

	private Line3D findVoxel_gaze = new Line3D(); // buffer
	private Point3D findVoxel_intersectZ = new Point3D();
	private Point3D findVoxel_intersectY = new Point3D();
	private Point3D findVoxel_intersectX = new Point3D();
	private Point3D gazeDbg = new Point3D();

	private int findVoxel(Point3D eye, Point3D gaze_, VoxelModel model) {
		gazeDbg.set(gaze_);
		//System.out.println(_gaze);
		int W = model.getWidth();
		int H = model.getHeight();
		int D = model.getDepth();

		// the gaze vector sign will tell which direction to test each slice
		// the eye position will tell which slice to start from
		boolean reverseZ = gaze_.z < 0;
		int z = (int) (reverseZ ? Math.ceil(eye.z) : Math.ceil(eye.z));
		boolean validz = !M.kindaEquals(gaze_.z, 0) && (reverseZ ? z > 0 : z < D);
		boolean reverseY = gaze_.y < 0;
		int y = (int) (reverseY ? Math.ceil(eye.y) : Math.ceil(eye.y));
		boolean validy = !M.kindaEquals(gaze_.y, 0) && (reverseY ? y > 0 : y < H);
		boolean reverseX = gaze_.x < 0;
		int x = (int) (reverseX ? Math.ceil(eye.x) : Math.ceil(eye.x));
		boolean validx = !M.kindaEquals(gaze_.x, 0) && (reverseX ? x > 0 : x < W);
		// Create gaze line
		findVoxel_gaze.set(eye, G.add_(eye, gaze_));

		//System.out.println("================================");
		//System.out.println("Slice: " + x + (reverseX ? "-" : "+") + (validx ? "" : "!") + " " + y + (reverseY ? "-" : "+") + (validy ? "" : "!") + " " + z + (reverseZ ? "-" : "+") + (validz ? "" : "!"));

		while (validz || validy || validx) {
			if (validz) if (!G.intersection(findVoxel_gaze, V.Plane3D(V.Point3D(0, 0, z), V.Point3D(0, 0, -1)), findVoxel_intersectZ)) System.out.println("WoopiesZ " + gazeDbg);
			if (validy) if (!G.intersection(findVoxel_gaze, V.Plane3D(V.Point3D(0, y, 0), V.Point3D(0, -1, 0)), findVoxel_intersectY)) System.out.println("WoopiesY " + gazeDbg);
			if (validx) if (!G.intersection(findVoxel_gaze, V.Plane3D(V.Point3D(x, 0, 0), V.Point3D(-1, 0, 0)), findVoxel_intersectX)) System.out.println("WoopiesX " + gazeDbg);
			// compute distance of each ray slice stop from eye
			double dz = validz ? G.sub_(findVoxel_intersectZ, eye).length2() : Double.MAX_VALUE;
			double dy = validy ? G.sub_(findVoxel_intersectY, eye).length2() : Double.MAX_VALUE;
			double dx = validx ? G.sub_(findVoxel_intersectX, eye).length2() : Double.MAX_VALUE;
			//System.out.println(dx + " " + dy + " " + dz);

			if (validz && dz <= dy && dz <= dx) {
				int voxel = model.get((int) Math.floor(findVoxel_intersectZ.x), (int) Math.floor(findVoxel_intersectZ.y), reverseZ ? z - 1 : z);
				if (C.isOpaque(voxel)) return zmod(voxel);
				z += reverseZ ? -1 : 1;
				validz = reverseZ ? z > 0 : z < D;
				if (validz) if (!G.intersection(findVoxel_gaze, V.Plane3D(V.Point3D(0, 0, z), V.Point3D(0, 0, -1)), findVoxel_intersectZ)) System.out.println("WoopiesDooZ " + gazeDbg);
			} else if (validy && dy <= dz && dy <= dx) {
				int voxel = model.get((int) Math.floor(findVoxel_intersectY.x), reverseY ? y - 1 : y, (int) Math.floor(findVoxel_intersectY.z));
				if (C.isOpaque(voxel)) return ymod(voxel);
				y += reverseY ? -1 : 1;
				validy = reverseY ? y > 0 : y < H;
				if (validy) if (!G.intersection(findVoxel_gaze, V.Plane3D(V.Point3D(0, y, 0), V.Point3D(0, -1, 0)), findVoxel_intersectY)) System.out.println("WoopiesDooY " + gazeDbg);
			} else if (validx && dx <= dz && dx <= dy) {
				int voxel = model.get(reverseX ? x - 1 : x, (int) Math.floor(findVoxel_intersectX.y), (int) Math.floor(findVoxel_intersectX.z));
				if (C.isOpaque(voxel)) return xmod(voxel);
				x += reverseX ? -1 : 1;
				validx = reverseX ? x > 0 : x < W;
				if (validx) if (!G.intersection(findVoxel_gaze, V.Plane3D(V.Point3D(x, 0, 0), V.Point3D(-1, 0, 0)), findVoxel_intersectX)) System.out.println("WoopiesDooX " + gazeDbg);
			} else {
				System.out.println("Whoopie all");
				validz = false;
				validy = false;
				validx = false;
			}
			//System.out.println("Slice: " + x + (reverseX ? "-" : "+") + (validx ? "" : "!") + " " + y + (reverseY ? "-" : "+") + (validy ? "" : "!") + " " + z + (reverseZ ? "-" : "+") + (validz ? "" : "!"));
		}

		return 0x00000000;
	}

	private int xmod(int rgb) {
		return rgb | 0xAA0000;//return new Color(rgb).darker().darker().getRGB();
	}

	private int ymod(int rgb) {
		return rgb | 0x00AA00;//return new Color(rgb).darker().getRGB();
	}

	private int zmod(int rgb) {
		return rgb | 0x0000AA;//return rgb;
	}

	// ActionListener
	public void actionPerformed(ActionEvent e) {
		Object o = e.getSource();
		if (o == load) onLoad();
	}

	// ChangeListener
	public void stateChanged(ChangeEvent e) {
		eye.x = eyeX.getValue();
		eye.y = eyeY.getValue();
		eye.z = eyeZ.getValue();
		topLeft.x = tlX.getValue();
		topLeft.y = tlY.getValue();
		topLeft.z = tlZ.getValue();
		topRight.x = trX.getValue();
		topRight.y = trY.getValue();
		topRight.z = trZ.getValue();
		bottomLeft.x = blX.getValue();
		bottomLeft.y = blY.getValue();
		bottomLeft.z = blZ.getValue();
		/*
		eye.set(0, 0, -eyeDistance.getValue());
		Point3D u_ = V.Point3D(0, 0, 0);
		Point3D v_ = V.Point3D(0, 0, 0);
		Point3D n_ = V.Point3D(eye);
		n_.normalizeInPlace();
		Point3D p_ = V.Point3D(0, 0, -planeDistance.getValue());
		G.decomposeUV(V.Plane3D(p_, n_), u_, v_);
		double hw = (planeW.getValue() / 10.0) / 2;
		double hh = (planeH.getValue() / 10.0) / 2;
		G.mul(u_, hw, u_);
		G.mul(v_, hw, v_);
		topLeft.set(G.sub_(G.sub_(p_, u_), v_));
		topRight.set(G.sub_(G.add_(p_, u_), v_));
		bottomLeft.set(G.add_(G.sub_(p_, u_), v_));
		*/
		int W = resolutionW.getValue();
		//int H = resolutionH.getValue();
		int H = resolutionW.getValue();
		if (output.getWidth() != W || output.getHeight() != H) {
			output = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
		}
		dirty();
	}

	// Main
	public static void main(String[] args) {
		UI.usualFrameInit(new VoxelViewer(), null, true);
	}

	// Test
	private static void printModel(VoxelModel model) {
		System.out.println("W: " + model.getWidth());
		System.out.println("H: " + model.getHeight());
		System.out.println("D: " + model.getDepth());
		for (int z = 0; z < model.getDepth(); z++) {
			for (int y = 0; y < model.getHeight(); y++) {
				for (int x = 0; x < model.getWidth(); x++) {
					System.out.print(C.toStringRGBA(model.get(x, y, z)) + " ");
				}
				System.out.println();
			}
			System.out.println();
			System.out.println();
		}
	}

	private static BufferedImage getSlice(VoxelModel model, int z) {
		int W = model.getWidth();
		int H = model.getHeight();
		BufferedImage out = new BufferedImage(W, H, BufferedImage.TYPE_INT_ARGB);
		for (int y = 0; y < H; y++) {
			for (int x = 0; x < W; x++) {
				out.setRGB(x, y, model.get(x, y, z));
			}
		}
		return out;
	}

	// GL
	private class GLView extends Geo3DFramework {
		public GLView(GLJPanel panel) {
			super(panel, true);
		}

		private Point3D horizontalStep = new Point3D(); // buffer
		private Point3D verticalStep = new Point3D(); // buffer
		private Point3D dy = new Point3D(); // buffer

		public void render(GL2 gl) {
			if (model != null) {
				// Note: origin is top left corner of voxel model, positive y going down
				int W = model.getWidth();
				int H = model.getHeight();
				int D = model.getDepth();
				int outW = output.getWidth();
				int outH = output.getHeight();

				// Draw model
				for (int z = 0; z < D; z++) {
					for (int y = 0; y < H; y++) {
						for (int x = 0; x < W; x++) {
							if (model.has(x, y, z)) {
								cube(gl, V.Point3D(x + .5, y + .5, z + .5), model.get(x, y, z), 1);
							}
						}
					}
				}

				// Draw eye and surface lines
				point(gl, eye, Color.RED, 5);
				line(gl, V.Line3D(topLeft, topRight), Color.BLUE.getRGB(), 1);
				line(gl, V.Line3D(topLeft, bottomLeft), Color.GREEN.getRGB(), 1);

				// Render voxel model on output surface
				G.div(G.sub_(topRight, topLeft), outW, horizontalStep);
				G.div(G.sub_(bottomLeft, topLeft), outH, verticalStep);
				for (int y = 0; y < outH; y++) {
					G.mul(verticalStep, y, dy);
					for (int x = 0; x < outW; x++) {
						// Draw eye-pixel line
						Point3D dx = G.mul_(horizontalStep, x);
						Point3D pixel = G.add_(topLeft, G.add_(dx, dy));
						//line(gl, V.Line3D(pixel, eye), Color.YELLOW, 1);
						// Draw gaze from eye 
						Point3D gaze = G.sub_(pixel, eye);
						line(gl, V.Line3D(eye, G.add_(eye, gaze)), C.rgbNormalizedInput(x / (double) outW, y / (double) outH, 1), 1);
					}
				}
			}
		}
	}

}
