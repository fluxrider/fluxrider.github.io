/*
 * Written by David Lareau on March 19, 2010.
 * 
 * Texture utility
 */

import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;

import javax.media.opengl.GL2;

import flux.util.C;

public class Texture2D {

	public static int loadTexture(GL2 gl, BufferedImage img, boolean enableLinearInterpolation) {
		int id = genOneTextureID(gl);
		loadTexture(gl, id, img, enableLinearInterpolation);
		return id;
	}

	public static void loadTexture(GL2 gl, int textureID, BufferedImage img, boolean enableLinearInterpolation) {
		gl.glActiveTexture(GL2.GL_TEXTURE0);
		gl.glBindTexture(GL2.GL_TEXTURE_2D, textureID);
		loadRGBATexture(gl, img);
		gl.glTexParameterf(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_S, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameterf(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_WRAP_T, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MIN_FILTER, enableLinearInterpolation ? GL2.GL_LINEAR : GL2.GL_NEAREST);
		gl.glTexParameteri(GL2.GL_TEXTURE_2D, GL2.GL_TEXTURE_MAG_FILTER, enableLinearInterpolation ? GL2.GL_LINEAR : GL2.GL_NEAREST);
	}

	public static void loadRGBATexture(GL2 gl, BufferedImage img) {
		// waste memory at the sake of simplicity: make any loaded image full rgba texture
		int W = img.getWidth();
		int H = img.getHeight();
		ByteBuffer pixels = ByteBuffer.allocateDirect(W * H * 4);
		//pixels.order(java.nio.ByteOrder.nativeOrder());

		// About the order: Documentation for glTexImage2D says: The first element corresponds to the lower left corner of the texture image. Subsequent elements progress left-to-right through the remaining texels in the lowest row of the texture image, and then in successively higher rows of the texture image. The final element corresponds to the upper right corner of the texture image.
		for (int y = H - 1; y >= 0; y--) {
			for (int x = 0; x < W; x++) {
				int rgb = img.getRGB(x, y);
				//pixels.putInt(rgb); // for some reason, the colors is wrong if I go this way (must be a sign or byte order thing)
				pixels.put((byte) C.r(rgb));
				pixels.put((byte) C.g(rgb));
				pixels.put((byte) C.b(rgb));
				pixels.put((byte) C.a(rgb)); // alpha
			}
		}
		pixels.flip();

		gl.glTexImage2D(GL2.GL_TEXTURE_2D, 0, GL2.GL_RGBA, W, H, 0, GL2.GL_RGBA, GL2.GL_UNSIGNED_BYTE, pixels);
	}

	public static int genOneTextureID(GL2 gl) {
		final int[] tmp = new int[1];
		gl.glGenTextures(1, tmp, 0);
		return tmp[0];
	}
}
