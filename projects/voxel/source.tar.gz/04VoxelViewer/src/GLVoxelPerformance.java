/*
 * Written by David Lareau on September 10, 2011.
 * 
 * Viewer of voxel space that changes all the time using opengl.
 * This implementation tries different strategy to achieve maximum rendering speed.
 * 
 * newt [done]
 * color rgb5551 [done]
 * dxt1 compression (if lossless, don't bother if lossy)
 * voxel model as bytebuffer
 * GL3 no fixed pipeline
 * 
 * Current benchmark: 96x96x96 gives 80fps
 */
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;

import javax.imageio.ImageIO;
import javax.media.opengl.GL;
import javax.media.opengl.GL2;
import javax.media.opengl.GL3;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.glu.GLU;
import javax.swing.JOptionPane;

import com.jogamp.newt.opengl.GLWindow;

import flux.geo3D.G;
import flux.geo3D.Line3D;
import flux.geo3D.Plane3D;
import flux.geo3D.Point3D;
import flux.gfx.voxel.VoxelModel;
import flux.mem.V;
import flux.opengl.OpenGLWindow;
import flux.opengl.PolledInput;
import flux.time.T;
import flux.ui.ImageFileFilter;
import flux.ui.UI;
import flux.util.C;
import flux.util.FPS;
import flux.util.K;
import flux.util.MovingAverage;

public class GLVoxelPerformance extends OpenGLWindow {

	// Attributes
	private K config;
	private final String CONFIG_OPEN_PATH = "open_path";

	private VoxelModel model;
	private int modelTexture;

	private int pboIds[];
	private int index = 0;

	private MovingAverage timer0; // display
	private MovingAverage timer1; // load model
	private MovingAverage timer2; // draw texture quads
	private MovingAverage timer3;
	private MovingAverage timer4;
	private MovingAverage timer5;

	private boolean deletePbos;

	private int mode;
	private final int MODE_COUNT = 2;

	private int pixelType;

	private FPS fps;

	protected double rotx, roty;
	protected double scale;
	protected boolean showAxis;

	// Construct
	public GLVoxelPerformance() {
		// OpenGLWindow
		super(true, true, true, true);
		//input.verbose = true;

		// Config
		config = new K("config.txt", true, String.format("%s=%s", CONFIG_OPEN_PATH, "."));
		timer0 = new MovingAverage(150);
		timer1 = new MovingAverage(150);
		timer2 = new MovingAverage(150);
		timer3 = new MovingAverage(150);
		timer4 = new MovingAverage(150);
		timer5 = new MovingAverage(150);
		mode = 1;
		pixelType = GL.GL_RGBA;
		//pixelType = GL.GL_RGB5_A1;

		showAxis = true;
		scale = 1;
		fps = new FPS(1000, 10);
	}

	// OpenGLWindow
	public void init(GLAutoDrawable drawable) {
		GL2 gl = drawable.getGL().getGL2();

		// disable vsync
		gl.setSwapInterval(0);

		// Smooth Points and Lines
		gl.glEnable(GL2.GL_BLEND);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		gl.glEnable(GL2.GL_POINT_SMOOTH);
		gl.glHint(GL2.GL_POINT_SMOOTH_HINT, GL2.GL_NICEST);
		gl.glEnable(GL2.GL_LINE_SMOOTH);
		gl.glHint(GL2.GL_LINE_SMOOTH_HINT, GL2.GL_NICEST);

		// Depth
		gl.glClearDepth(1.0f);
		gl.glEnable(GL2.GL_DEPTH_TEST);
		gl.glDepthFunc(GL2.GL_LEQUAL);
		// almost completly transparent pixel will not update the z-buffer
		gl.glAlphaFunc(GL2.GL_GREATER, 0.1f);
		gl.glEnable(GL2.GL_ALPHA_TEST);

		// Culling
		gl.glFrontFace(GL2.GL_CCW);
		gl.glEnable(GL2.GL_CULL_FACE);
		gl.glCullFace(GL2.GL_BACK);

		// Lighting (must now specify normals)
		/*
		gl.glEnable(GL2.GL_LIGHTING);
		gl.glEnable(GL2.GL_COLOR_MATERIAL);
		gl.glShadeModel(GL2.GL_SMOOTH);
		gl.glColorMaterial(GL2.GL_FRONT_AND_BACK, GL2.GL_AMBIENT_AND_DIFFUSE);
		gl.glEnable(GL2.GL_LIGHT0);
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_AMBIENT, new float[] { .5f, .5f, .5f, 1 }, 0);
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_DIFFUSE, new float[] { 1, 1, 1, 1 }, 0);
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_SPECULAR, new float[] { 0, 0, 0, 1 }, 0);
		//gl.glLightModelfv(GL2.GL_LIGHT_MODEL_AMBIENT, new float[] { 0.0f, 0.0f, 0.0f, 1.0f }, 0);
		gl.glMaterialfv(GL2.GL_FRONT_AND_BACK, GL2.GL_EMISSION, new float[] { 0.0f, 0.0f, 0.0f, 1.0f }, 0);
		gl.glMaterialfv(GL2.GL_FRONT_AND_BACK, GL2.GL_SPECULAR, new float[] { 0.0f, 0.0f, 0.0f, 1.0f }, 0);
		*/

		// Texture
		gl.glEnable(GL2.GL_TEXTURE_2D);
		gl.glEnable(GL2.GL_TEXTURE_3D);

	}

	public void reshape(GLAutoDrawable drawable, int x, int y, int w, int h) {
		GL2 gl = drawable.getGL().getGL2();
		gl.glMatrixMode(GL2.GL_PROJECTION);
		gl.glLoadIdentity();
		GLU glu = new GLU();
		glu.gluPerspective(60.0f, w / (double) h, 0.1, 1000.0);
		glu.gluLookAt(.5, .5, 2, 0, 0, 0, 0, 1, 0);
		gl.glMatrixMode(GL2.GL_MODELVIEW);
		gl.glLoadIdentity();
		gl.glViewport(0, 0, w, h);
	}

	public void dispose(GLAutoDrawable drawable) {
	}

	public void display(GLAutoDrawable drawable) {
		long t0 = System.nanoTime();
		GL2 gl = drawable.getGL().getGL2();
		gl.glClear(GL3.GL_COLOR_BUFFER_BIT | GL3.GL_DEPTH_BUFFER_BIT);
		gl.glLoadIdentity();

		// Rotate according to input
		gl.glScaled(scale, scale, scale);
		gl.glRotated(rotx, 1, 0, 0);
		gl.glRotated(roty, 0, 1, 0);

		// Light
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, new float[] { .7f, .7f, .7f, 1.0f }, 0);
		gl.glLightf(GL2.GL_LIGHT0, GL2.GL_ATTENUATION_EXT, GL2.GL_LINEAR_ATTENUATION);
		point(gl, .7, .7, .7, 0xffff00, 20); // light indicator

		if (showAxis) {
			// Origin white point
			point(gl, 0, 0, 0, 0xFFFFFF, 5);

			// Unit axis lines
			line(gl, 0, 0, 0, 1, 0, 0, 0xFF0000, 0x000000, 3);
			line(gl, 0, 0, 0, 0, 1, 0, 0x00FF00, 0x000000, 3);
			line(gl, 0, 0, 0, 0, 0, 1, 0x0000FF, 0x000000, 3);
		}

		render(drawable.getGL().getGL2());
		fps.frame();
		timer0.add(System.nanoTime() - t0);
	}

	public void tick() {
		if (input.held(PolledInput.FK_ESCAPE)) isRunningMainLoop = false;
		if (input.typed(PolledInput.FK_LEFT)) roty -= 5;
		if (input.typed(PolledInput.FK_RIGHT)) roty += 5;
		if (input.typed(PolledInput.FK_UP)) rotx -= 5;
		if (input.typed(PolledInput.FK_DOWN)) rotx += 5;
		if (input.typed(PolledInput.FK_R)) {
			rotx = roty = 0;
			scale = 1;
		}
		if (input.typed(PolledInput.FK_NUMPAD_ADD)) scale *= 2;
		if (input.typed(PolledInput.FK_NUMPAD_SUBTRACT)) scale /= 2;
		if (input.typed(PolledInput.FK_M)) switchMode();
		if (input.typed(PolledInput.FK_L)) onLoad();
		if (input.typed(PolledInput.FK_G)) onGen();
		input.polled();

		// update model once in while and show fps
		if (T.lastCheck(1000)) {
			double total = timer0.get();
			double loadModelRatio = timer1.get() / total;
			double textureQuadsRatio = timer2.get() / total;
			total = timer1.get();
			double pbo2texRatio = timer3.get() / total;
			double unsetRatio = timer4.get() / total;
			double loadTexRatio = timer5.get() / total;
			System.out.println(String.format("FPS: %.2f loadModel: %.2f textureQuads: %.2f", fps.get(), loadModelRatio, textureQuadsRatio));
			System.out.println(String.format("pbo2texture: %.2f unset: %.2f loadTexture: %.2f", pbo2texRatio, unsetRatio, loadTexRatio));
			if (model != null) rshift(model);
		}

	}

	// Util
	protected void point(GL2 gl, double x, double y, double z, int rgb, double size) {
		gl.glPointSize((float) size);
		gl.glBegin(GL.GL_POINTS);
		gl.glColor3d(C.r1(rgb), C.g1(rgb), C.b1(rgb));
		gl.glVertex3d(x, y, z);
		gl.glEnd();
	}

	protected void line(GL2 gl, double px, double py, double pz, double qx, double qy, double qz, int prgb, int qrgb, double size) {
		gl.glLineWidth((float) size);
		gl.glBegin(GL.GL_LINES);
		gl.glColor3d(C.r1(prgb), C.g1(prgb), C.b1(prgb));
		gl.glVertex3d(px, py, pz);
		gl.glColor3d(C.r1(qrgb), C.g1(qrgb), C.b1(qrgb));
		gl.glVertex3d(qx, qy, qz);
		gl.glEnd();
	}

	protected void plane(GL2 gl, double px, double py, double pz, double nx, double ny, double nz, int prgb, int nrgb, double planeSize, double nlength, double nsize) {
		// plane surface sample
		Point3D u_ = V.Point3D(0, 0, 0);
		Point3D v_ = V.Point3D(0, 0, 0);
		G.decomposeUV(V.Plane3D(V.Point3D(px, py, pz), V.Point3D(nx, ny, nz)), u_, v_);
		G.mul(u_, planeSize, u_);
		G.mul(v_, planeSize, v_);
		gl.glBegin(GL2.GL_QUADS);
		gl.glColor3d(C.r1(prgb), C.g1(prgb), C.b1(prgb));
		gl.glVertex3d(px + u_.x, py + u_.y, pz + u_.z);
		gl.glVertex3d(px - v_.x, py - v_.y, pz - v_.z);
		gl.glVertex3d(px - u_.x, py - u_.y, pz - u_.z);
		gl.glVertex3d(px + v_.x, py + v_.y, pz + v_.z);
		gl.glEnd();
		// normal
		line(gl, px, py, pz, px + nx * nlength, py + ny * nlength, pz + nz * nlength, nrgb, nrgb, nsize);
	}

	protected void point(GL2 gl, Point3D p, Color color, double size) {
		point(gl, p.x, p.y, p.z, color.getRGB(), size);
	}

	protected void line(GL2 gl, Point3D p, Point3D q, int prgb, int qrgb, double size) {
		line(gl, p.x, p.y, p.z, q.x, q.y, q.z, prgb, qrgb, size);
	}

	protected void line(GL2 gl, Line3D line, int color, double size) {
		line(gl, line.getP(), line.getQ(), color, color, size);
	}

	protected void plane(GL2 gl, Plane3D plane, Color planeColor, Color ncolor, double planeSize, double nlength, double nsize) {
		Point3D p = plane.getPoint();
		Point3D n = plane.getNormal();
		plane(gl, p.x, p.y, p.z, n.x, n.y, n.z, planeColor.getRGB(), ncolor.getRGB(), planeSize, nlength, nsize);
	}

	// axis aligned cube
	protected void cube(GL2 gl, Point3D center, int rgb, double radius) {
		gl.glPushMatrix();
		gl.glTranslated(center.x, center.y, center.z);
		gl.glScaled(radius, radius, radius);
		gl.glColor3d(C.r1(rgb), C.g1(rgb), C.b1(rgb));
		unitCube(gl);
		gl.glPopMatrix();
	}

	protected void unitCube(GL2 gl) {
		double u = .5;
		gl.glBegin(GL2.GL_QUADS);
		// front
		gl.glNormal3d(0, 0, 1);
		gl.glVertex3d(-u, -u, u);
		gl.glVertex3d(u, -u, u);
		gl.glVertex3d(u, u, u);
		gl.glVertex3d(-u, u, u);
		// right
		gl.glNormal3d(1, 0, 0);
		gl.glVertex3d(u, -u, u);
		gl.glVertex3d(u, -u, -u);
		gl.glVertex3d(u, u, -u);
		gl.glVertex3d(u, u, u);
		// left
		gl.glNormal3d(-1, 0, 0);
		gl.glVertex3d(-u, u, u);
		gl.glVertex3d(-u, u, -u);
		gl.glVertex3d(-u, -u, -u);
		gl.glVertex3d(-u, -u, u);
		// back
		gl.glNormal3d(0, 0, -1);
		gl.glVertex3d(-u, u, -u);
		gl.glVertex3d(u, u, -u);
		gl.glVertex3d(u, -u, -u);
		gl.glVertex3d(-u, -u, -u);
		// top
		gl.glNormal3d(0, 1, 0);
		gl.glVertex3d(-u, u, -u);
		gl.glVertex3d(-u, u, u);
		gl.glVertex3d(u, u, u);
		gl.glVertex3d(u, u, -u);
		// bottom
		gl.glNormal3d(0, -1, 0);
		gl.glVertex3d(-u, -u, -u);
		gl.glVertex3d(u, -u, -u);
		gl.glVertex3d(u, -u, u);
		gl.glVertex3d(-u, -u, u);
		gl.glEnd();
	}

	// Main
	public static void main(String[] args) {
		System.out.println("Engage");

		GLVoxelPerformance app = new GLVoxelPerformance();
		GLWindow window = app.window;
		window.setTitle("Example OpenGLWindow main()");
		window.setPosition(100, 100);
		window.setSize(800, 600);
		window.setVisible(true);
		window.setUndecorated(true);

		app.mainLoop();
		window.destroy();

		System.out.println("Over and out");
		System.exit(0); // because I use JOptionPane, the app doesn't quit on its own 
	}

	// Methods
	public void onLoad() {
		try {
			File file = UI.selectFile(null, new ImageFileFilter(true), true, config, CONFIG_OPEN_PATH);
			if (file != null) {
				BufferedImage image = ImageIO.read(file);
				this.model = VoxelModel.read(image, 1, 2);
				this.modelTexture = -1;
				this.deletePbos = true;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void onGen() {
		int W = Integer.parseInt(JOptionPane.showInputDialog("Width", "10"));
		int H = Integer.parseInt(JOptionPane.showInputDialog("Height", "10"));
		int D = Integer.parseInt(JOptionPane.showInputDialog("Depth", "10"));
		this.model = new VoxelModel(W, H, D);
		for (int z = 0; z < D; z++) {
			for (int y = 0; y < H; y++) {
				for (int x = 0; x < W; x++) {
					int c = C.random();
					if (Math.random() < .2) c &= 0x00FFFFFF; // set transparent
					else c |= 0xFF000000; // set opaque
					model.set(x, y, z, c);
				}
			}
		}
		this.modelTexture = -1;
		this.deletePbos = true;
	}

	private void switchMode() {
		mode = (mode + 1) % MODE_COUNT;
		System.out.println("Switching mode: " + mode);
		this.modelTexture = -1;
		this.deletePbos = true;
	}

	public void loadModel(GL2 gl) {
		// Load Mode 
		if (deletePbos) {
			if (pboIds != null) gl.glDeleteBuffers(2, pboIds, 0);
			pboIds = null;
			deletePbos = false;
		}
		switch (mode) {
			// Fully load every frame, even redo the bytebuffer!
			case 0:
				if (modelTexture != -1) Texture3D.delete(gl, modelTexture);
				modelTexture = Texture3D.loadTexture(gl, model, false, pixelType);
				// on quit I should call Texture3D.delete(gl, modelTexture);
				break;
			// Update using two PBO (1 for application to PBO, and another for PBO to texture object)
			case 1:
				long byteCount = model.getWidth() * model.getHeight() * model.getDepth() * Texture3D.getPixelDataSize(pixelType);
				if (pboIds == null) {
					System.out.println("Initializing PBO");
					pboIds = new int[2];
					gl.glGenBuffers(2, pboIds, 0);
					gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[0]);
					gl.glBufferData(GL2.GL_PIXEL_UNPACK_BUFFER, byteCount, null, GL2.GL_STREAM_DRAW);
					gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[1]);
					gl.glBufferData(GL2.GL_PIXEL_UNPACK_BUFFER, byteCount, null, GL2.GL_STREAM_DRAW);
					gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, 0);
					// on quit you should call glDeleteBuffersARB(2, pboIds, 0);
					// I'm also loading the texture once, but really I just need a texture3D id of the good size allocated
					if (modelTexture != -1) Texture3D.delete(gl, modelTexture);
					modelTexture = Texture3D.loadTexture(gl, model, false, pixelType);
				}

				index = (index + 1) % 2;
				int nextIndex = (index + 1) % 2;

				long t3 = System.nanoTime();
				// bind the texture and PBO
				gl.glBindTexture(GL2.GL_TEXTURE_3D, modelTexture);
				gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[index]);
				// copy pixels from PBO to texture object
				// Use offset instead of ponter.
				gl.glTexSubImage3D(GL2.GL_TEXTURE_3D, 0, 0, 0, 0, model.getWidth(), model.getHeight(), model.getDepth(), Texture3D.getPixelDataFormat(pixelType), Texture3D.getPixelDataType(pixelType), 0);
				timer3.add(System.nanoTime() - t3);

				long t4 = System.nanoTime();
				// bind PBO to update pixel values
				gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[nextIndex]);
				// map the buffer object into client's memory
				// Note that glMapBufferARB() causes sync issue.
				// If GPU is working with this buffer, glMapBufferARB() will wait(stall)
				// for GPU to finish its job. To avoid waiting (stall), you can call
				// first glBufferDataARB() with NULL pointer before glMapBufferARB().
				// If you do that, the previous data in PBO will be discarded and
				// glMapBufferARB() returns a new allocated pointer immediately
				// even if GPU is still working with the previous data.
				gl.glBufferData(GL2.GL_PIXEL_UNPACK_BUFFER, byteCount, null, GL2.GL_STREAM_DRAW);
				timer4.add(System.nanoTime() - t4);

				long t5 = System.nanoTime();
				ByteBuffer ptr = gl.glMapBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, GL2.GL_WRITE_ONLY);
				if (ptr != null) {
					// update data directly on the mapped buffer
					Texture3D.loadTexture(model, ptr, pixelType);
					gl.glUnmapBuffer(GL2.GL_PIXEL_UNPACK_BUFFER); // release pointer to mapping buffer
				}
				timer5.add(System.nanoTime() - t5);

				// it is good idea to release PBOs with ID 0 after use.
				// Once bound with 0, all pixel operations behave normal ways.
				gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, 0);

				break;
		}
	}

	public void render(GL2 gl) {
		//int buffer[] = new int[10];
		//gl.glGetIntegerv(GL2.GL_MAX_3D_TEXTURE_SIZE, buffer, 0);
		//System.out.println("GL: + " + Arrays.toString(buffer));

		if (model != null) {
			// Note: origin is top left corner of voxel model, positive y going down
			int W = model.getWidth();
			int H = model.getHeight();
			int D = model.getDepth();

			long t1 = System.nanoTime();
			loadModel(gl);
			timer1.add(System.nanoTime() - t1);

			long t2 = System.nanoTime();
			// draw
			gl.glBindTexture(GL2.GL_TEXTURE_3D, modelTexture);
			gl.glColor4d(1, 1, 1, 1);
			double dx = 1;
			double dy = 1;
			double dz = 1;
			gl.glBegin(GL2.GL_QUADS);
			// draw the z-quads
			for (int reverse = 0; reverse < 2; reverse++) {
				boolean reverseZ = reverse == 1;
				for (int z = 0; z < D; z++) {
					double r = (z / (double) (D - 1));
					if (r == 1) r = .99; // I can't use exactly 1, for me it draws a mix of 0 and 1 if I do.
					gl.glNormal3d(0, 0, reverseZ ? -1 : 1);
					if (reverseZ) {
						gl.glTexCoord3d(0, 0, r);
						gl.glVertex3d(0, 0, -(z + 1) * dz);
						gl.glTexCoord3d(0, 1, r);
						gl.glVertex3d(0, dy * H, -(z + 1) * dz);
						gl.glTexCoord3d(1, 1, r);
						gl.glVertex3d(dx * W, dy * H, -(z + 1) * dz);
						gl.glTexCoord3d(1, 0, r);
						gl.glVertex3d(dx * W, 0, -(z + 1) * dz);
					} else {
						gl.glTexCoord3d(0, 0, r);
						gl.glVertex3d(0, 0, -z * dz);
						gl.glTexCoord3d(1, 0, r);
						gl.glVertex3d(dx * W, 0, -z * dz);
						gl.glTexCoord3d(1, 1, r);
						gl.glVertex3d(dx * W, dy * H, -z * dz);
						gl.glTexCoord3d(0, 1, r);
						gl.glVertex3d(0, dy * H, -z * dz);
					}
				}
			}
			// draw the x-quads
			for (int reverse = 0; reverse < 2; reverse++) {
				boolean reverseX = reverse == 1;
				for (int x = 0; x < W; x++) {
					double s = (x / (double) (W - 1));
					if (s == 1) s = .99;
					gl.glNormal3d(reverseX ? -1 : 1, 0, 0);
					if (reverseX) {
						gl.glTexCoord3d(s, 0, 0);
						gl.glVertex3d(x * dz, 0, 0);
						gl.glTexCoord3d(s, 1, 0);
						gl.glVertex3d(x * dz, dy * H, 0);
						gl.glTexCoord3d(s, 1, 1);
						gl.glVertex3d(x * dz, dy * H, dz * -D);
						gl.glTexCoord3d(s, 0, 1);
						gl.glVertex3d(x * dz, 0, dz * -D);
					} else {
						gl.glTexCoord3d(s, 0, 0);
						gl.glVertex3d((x + 1) * dz, 0, 0);
						gl.glTexCoord3d(s, 0, 1);
						gl.glVertex3d((x + 1) * dz, 0, dz * -D);
						gl.glTexCoord3d(s, 1, 1);
						gl.glVertex3d((x + 1) * dz, dy * H, dz * -D);
						gl.glTexCoord3d(s, 1, 0);
						gl.glVertex3d((x + 1) * dz, dy * H, 0);
					}
				}
			}
			// draw the y-quads
			for (int reverse = 0; reverse < 2; reverse++) {
				boolean reverseY = reverse == 1;
				for (int y = 0; y < H; y++) {
					double t = (y / (double) (H - 1));
					if (t == 1) t = .99;
					gl.glNormal3d(0, reverseY ? -1 : 1, 0);
					if (reverseY) {
						gl.glTexCoord3d(0, t, 0);
						gl.glVertex3d(0, y * dy, 0);
						gl.glTexCoord3d(0, t, 1);
						gl.glVertex3d(0, y * dy, dz * -D);
						gl.glTexCoord3d(1, t, 1);
						gl.glVertex3d(dx * W, y * dy, dz * -D);
						gl.glTexCoord3d(1, t, 0);
						gl.glVertex3d(dx * W, y * dy, 0);
					} else {
						gl.glTexCoord3d(0, t, 0);
						gl.glVertex3d(0, (y + 1) * dy, 0);
						gl.glTexCoord3d(1, t, 0);
						gl.glVertex3d(dx * W, (y + 1) * dy, 0);
						gl.glTexCoord3d(1, t, 1);
						gl.glVertex3d(dx * W, (y + 1) * dy, dz * -D);
						gl.glTexCoord3d(0, t, 1);
						gl.glVertex3d(0, (y + 1) * dy, dz * -D);
					}
				}
			}

			gl.glEnd();
			gl.glBindTexture(GL3.GL_TEXTURE_3D, 0);
			timer2.add(System.nanoTime() - t2);
		}
	}

	// shift the model to the right (cyclic)
	private void rshift(VoxelModel model) {
		int W = model.getWidth();
		int H = model.getHeight();
		int D = model.getDepth();
		for (int z = 0; z < D; z++) {
			for (int y = 0; y < H; y++) {
				int buffer = model.get(W - 1, y, z);
				for (int x = W - 1; x > 0; x--) {
					model.set(x, y, z, model.get(x - 1, y, z));
				}
				model.set(0, y, z, buffer);
			}
		}
	}

}
