/*
 * Written by David Lareau.
 * 
 * A point in 2D space. I'm supporting basic vector methods (normalize and length).
 */
package flux.geo2D;

public class Point2D {

	// Attributes (public)
	public double x;
	public double y;

	// Construct
	public Point2D() {
		this(0, 0);
	}

	public Point2D(double x, double y) {
		set(x, y);
	}

	public String toString() {
		return String.format("(%.2f,%.2f)", x, y);
	}

	public void set(double x, double y) {
		this.x = x;
		this.y = y;
	}

	// Vector Methods
	public double normalizeInPlace() {
		double length = length();
		x /= length;
		y /= length;
		return length;
	}

	public double length() {
		return Math.sqrt(length2());
	}

	public double length2() {
		return length2(x, y);
	}

	public double atan2() {
		return atan2(x, y);
	}

	// Static Methods
	public static final double length(double x, double y) {
		return Math.sqrt(length2(x, y));
	}

	public static final double length2(double x, double y) {
		return x * x + y * y;
	}

	public static final double atan2(double x, double y) {
		return Math.atan2(y, x);
	}

}
