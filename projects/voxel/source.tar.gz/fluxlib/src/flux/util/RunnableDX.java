package flux.util;

public interface RunnableDX {

	public void run(Object... args);

}
