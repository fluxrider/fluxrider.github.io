/* 
 * Written by David Lareau on May 8, 2009
 * 
 * Color conversion & decoding function
 */
package flux.util;

import java.awt.Color;

import flux.math.M;
import flux.random.R;

public class C {

	// Internal use buffer
	private static float buffer_f[] = new float[3];

	// Static conversion
	public static int rgb(int r, int g, int b) {
		if (r > 255 || r < 0 || g > 255 || g < 0 || b > 255 || b < 0) throw new IllegalArgumentException(r + " " + g + " " + b);
		return (r << 16) | (g << 8) | b;
	}

	public static int rgba(int r, int g, int b, int a) {
		if (r > 255 || r < 0 || g > 255 || g < 0 || b > 255 || b < 0 || a > 255 || a < 0) throw new IllegalArgumentException(r + " " + g + " " + b + " " + a);
		return (a << 24) | (r << 16) | (g << 8) | b;
	}

	public static int rgb(int rgb[]) {
		return rgb(rgb[0], rgb[1], rgb[2]);
	}

	public static int rgb(Color color) {
		return rgb(color.getRed(), color.getGreen(), color.getBlue());
	}

	public static int fromGray(int gray) {
		return rgb(gray, gray, gray);
	}

	public static boolean pad(int rgb[]) {
		boolean padded = false;
		for (int i = 0; i < 3; i++) {
			if (rgb[i] < 0) {
				rgb[i] = 0;
				padded = true;
			}
			if (rgb[i] > 255) {
				rgb[i] = 255;
				padded = true;
			}
		}
		return padded;
	}

	public static int pad(int gray) {
		if (gray < 0) return 0;
		if (gray > 255) return 255;
		return gray;
	}

	// round and pad 255 based high precision input
	public static int rgbDX(double r, double g, double b) {
		r = Math.min(255, Math.max(0, Math.round(r)));
		g = Math.min(255, Math.max(0, Math.round(g)));
		b = Math.min(255, Math.max(0, Math.round(b)));
		return C.rgb((int) r, (int) g, (int) b);
	}

	// store r,g,c in t[0],t[1],t[2]
	public static void store(int rgb, int t[]) {
		t[0] = r(rgb);
		t[1] = g(rgb);
		t[2] = b(rgb);
	}

	public static int rgbNormalizedInput(double r, double g, double b) {
		return rgb(to255(r), to255(g), to255(b));
	}

	public static int rgbNormalizedInput(double rgb[]) {
		return rgbNormalizedInput(rgb[0], rgb[1], rgb[2]);
	}

	public static int r(int rgb) {
		return (rgb & 0x00FF0000) >> 16;
	}

	public static int g(int rgb) {
		return (rgb & 0x0000FF00) >> 8;
	}

	public static int b(int rgb) {
		return (rgb & 0x000000FF);
	}

	public static int a(int rgba) {
		return (rgba & 0xFF000000) >>> 24;
	}

	public static double r1(int rgb) {
		return C.toDouble(C.r(rgb));
	}

	public static double g1(int rgb) {
		return C.toDouble(C.g(rgb));
	}

	public static double b1(int rgb) {
		return C.toDouble(C.b(rgb));
	}

	public static double a1(int rgba) {
		return C.toDouble(C.a(rgba));
	}

	public static boolean isOpaque(int rgba) {
		return a(rgba) == 255;
	}

	public static boolean isFullyTransparent(int rgba) {
		return a(rgba) == 0;
	}

	public static String toString(int rgb) {
		return C.r(rgb) + "," + C.g(rgb) + "," + C.b(rgb);
	}

	public static String toStringRGBA(int rgba) {
		return C.r(rgba) + "," + C.g(rgba) + "," + C.b(rgba) + "," + C.a(rgba);
	}

	public static int gray(int rgb) {
		return (r(rgb) + g(rgb) + b(rgb)) / 3;
	}

	public static int grayDX(int rgb) {
		return (int) (0.2125 * r(rgb) + 0.7154 * g(rgb) + 0.0721 * b(rgb));
	}

	public static double grayDX(double rgb[]) {
		return (0.2125 * rgb[0] + 0.7154 * rgb[1] + 0.0721 * rgb[2]);
	}

	// @return max(r, g, b)
	public static int maxRGB(int rgb) {
		return Math.max(Math.max(r(rgb), g(rgb)), b(rgb));
	}

	public static double toDouble(int b255) {
		return b255 / (double) 255;
	}

	public static int to255(double v) {
		return (int) Math.round(v * 255);
	}

	public static int blend(int rgb1, int rgb2, int n1, int n2) {
		int red = (int) Math.round((C.r(rgb1) * n1 + C.r(rgb2) * n2) / (double) (n1 + n2));
		int grn = (int) Math.round((C.g(rgb1) * n1 + C.g(rgb2) * n2) / (double) (n1 + n2));
		int blu = (int) Math.round((C.b(rgb1) * n1 + C.b(rgb2) * n2) / (double) (n1 + n2));
		return C.rgb(red, grn, blu);
	}

	public static int blendN(int rgbs[], int ns[], int offset, int length) {
		int sumR = 0;
		int sumG = 0;
		int sumB = 0;
		int sumN = 0;
		for (int i = 0; i < length; i++) {
			int rgb = rgbs[i + offset];
			int n = ns[i + offset];
			sumR += C.r(rgb) * n;
			sumG += C.g(rgb) * n;
			sumB += C.b(rgb) * n;
			sumN += n;
		}
		int red = (int) Math.round((sumR) / (double) sumN);
		int grn = (int) Math.round((sumG) / (double) sumN);
		int blu = (int) Math.round((sumB) / (double) sumN);
		return C.rgb(red, grn, blu);
	}

	public static void blend(double c1[], double c2[], double out[], int n1, int n2) {
		for (int i = 0; i < 3; i++) {
			out[i] = (c1[i] * n1 + c2[i] * n2) / (n1 + n2);
		}
	}

	public static double distance(int rgb1, int rgb2) {
		return Math.sqrt(distance2(rgb1, rgb2));
	}

	public static double distance2(int rgb1, int rgb2) {
		int r1 = r(rgb1);
		int g1 = g(rgb1);
		int b1 = b(rgb1);
		int r2 = r(rgb2);
		int g2 = g(rgb2);
		int b2 = b(rgb2);
		return (r1 - r2) * (r1 - r2) + (g1 - g2) * (g1 - g2) + (b1 - b2) * (b1 - b2);
	}

	// Color Spaces
	public static void toXYZ(int rgb[], double xyz[]) {
		// get r,g,b in [0,1] form
		double R = toDouble(rgb[0]);
		double G = toDouble(rgb[1]);
		double B = toDouble(rgb[2]);

		// sRGB simplified gamma function
		//double r = Math.pow(R, 2.2);
		//double g = Math.pow(G, 2.2);
		//double b = Math.pow(B, 2.2);

		// sRGB gamma function
		double r, g, b;
		if (R <= 0.04045) r = R / 12.92;
		else r = Math.pow((R + 0.055) / 1.055, 2.4);
		if (G <= 0.04045) g = G / 12.92;
		else g = Math.pow((G + 0.055) / 1.055, 2.4);
		if (B <= 0.04045) b = B / 12.92;
		else b = Math.pow((B + 0.055) / 1.055, 2.4);

		// Observer. = 2°, Illuminant = D65  (2.2?)
		// (matrices from http://www.brucelindbloom.com/index.html?Eqn_RGB_to_XYZ.html)
		double X = r * 0.4124564 + g * 0.3575761 + b * 0.1804375;
		double Y = r * 0.2126729 + g * 0.7151522 + b * 0.0721750;
		double Z = r * 0.0193339 + g * 0.1191920 + b * 0.9503041;

		// scale XYZ
		X *= 100;
		Y *= 100;
		Z *= 100;

		// round off to three decimal point
		X = M.round(X, 3);
		Y = M.round(Y, 3);
		Z = M.round(Z, 3);

		// return
		xyz[0] = X;
		xyz[1] = Y;
		xyz[2] = Z;
	}

	public static void fromXYZ(double xyz[], int rgb[]) {
		// unscale X,Y,Z
		double X = xyz[0] / 100.0;
		double Y = xyz[1] / 100.0;
		double Z = xyz[2] / 100.0;

		// (matrices from http://www.brucelindbloom.com/index.html?Eqn_RGB_to_XYZ.html)
		double r = X * 3.2404542 + Y * -1.5371385 + Z * -0.4985314;
		double g = X * -0.9692660 + Y * 1.8760108 + Z * 0.0415560;
		double b = X * 0.0556434 + Y * -0.2040259 + Z * 1.0572252;

		// sRGB simplified gamma function reversed
		//double R = Math.pow(r, 1 / 2.2);
		//double G = Math.pow(g, 1 / 2.2);
		//double B = Math.pow(b, 1 / 2.2);

		// sRGB gamma function reversed
		double R, G, B;
		if (r <= 0.0031308) R = 12.92 * r;
		else R = 1.055 * Math.pow(r, 1.0 / 2.4) - 0.055;
		if (g <= 0.0031308) G = 12.92 * g;
		else G = 1.055 * Math.pow(g, 1.0 / 2.4) - 0.055;
		if (b <= 0.0031308) B = 12.92 * b;
		else B = 1.055 * Math.pow(b, 1.0 / 2.4) - 0.055;

		// return
		rgb[0] = to255(R);
		rgb[1] = to255(G);
		rgb[2] = to255(B);
	}

	public static void toLab(double xyz[], double lab[]) {
		// Reference White
		double Xr = 95.047;
		double Yr = 100.000;
		double Zr = 108.883;

		// CIE Standard constants
		double e = 0.008856;
		double k = 903.3;

		// relative X,YZ over reference
		double xr = xyz[0] / Xr;
		double yr = xyz[1] / Yr;
		double zr = xyz[2] / Zr;

		double fx, fy, fz;
		if (xr > e) fx = Math.pow(xr, 1 / 3.0);
		else fx = (k * xr + 16) / 116;
		if (yr > e) fy = Math.pow(yr, 1 / 3.0);
		else fy = (k * yr + 16) / 116;
		if (zr > e) fz = Math.pow(zr, 1 / 3.0);
		else fz = (k * zr + 16) / 116;

		double L = 116 * fy - 16;
		double a = 500 * (fx - fy);
		double b = 200 * (fy - fz);

		// round off to three decimal point
		L = M.round(L, 3);
		a = M.round(a, 3);
		b = M.round(b, 3);

		// return
		lab[0] = L;
		lab[1] = a;
		lab[2] = b;
	}

	public static void fromLab(double lab[], double xyz[]) {
		// Reference White
		double Xr = 95.047;
		double Yr = 100.000;
		double Zr = 108.883;

		// CIE Standard constants
		double e = 0.008856;
		double k = 903.3;

		// Input
		double L = lab[0];
		double a = lab[1];
		double b = lab[2];

		double fy = (L + 16) / 116;
		double fx = a / 500 + fy;
		double fz = fy - b / 200;

		double xr, yr, zr;
		double fx3 = fx * fx * fx;
		double fz3 = fz * fz * fz;
		if (fx3 > e) xr = fx3;
		else xr = (116 * fx - 16) / k;
		if (fz3 > e) zr = fz3;
		else zr = (116 * fz - 16) / k;
		if (L > k * e) yr = Math.pow((L + 16) / 116, 3);
		else yr = L / k;

		double X = xr * Xr;
		double Y = yr * Yr;
		double Z = zr * Zr;

		// round off to three decimal point
		X = M.round(X, 3);
		Y = M.round(Y, 3);
		Z = M.round(Z, 3);

		// return
		xyz[0] = X;
		xyz[1] = Y;
		xyz[2] = Z;
	}

	public static void toHSB(int rgb, double hsb[]) {
		Color.RGBtoHSB(r(rgb), g(rgb), b(rgb), buffer_f);
		hsb[0] = buffer_f[0];
		hsb[1] = buffer_f[1];
		hsb[2] = buffer_f[2];
	}

	public static int fromHSB(double hsb[]) {
		return Color.HSBtoRGB((float) hsb[0], (float) hsb[1], (float) hsb[2]);
	}

	public static void toHSB(int rgb[], double hsb[]) {
		Color.RGBtoHSB(rgb[0], rgb[1], rgb[2], buffer_f);
		hsb[0] = buffer_f[0];
		hsb[1] = buffer_f[1];
		hsb[2] = buffer_f[2];
	}

	public static void fromHSB(double hsb[], int rgb[]) {
		int color = Color.HSBtoRGB((float) hsb[0], (float) hsb[1], (float) hsb[2]);
		rgb[0] = r(color);
		rgb[1] = g(color);
		rgb[2] = b(color);
	}

	public static void toLuv(double xyz[], double luv[]) {
		// Reference White
		double Xr = 95.047;
		double Yr = 100.000;
		double Zr = 108.883;

		// CIE Standard constants
		double e = 0.008856;
		double k = 903.3;

		// Input
		double X = xyz[0];
		double Y = xyz[1];
		double Z = xyz[2];

		double yr = Y / Yr;
		double up = (4 * X) / (X + 15 * Y + 3 * Z);
		double vp = (9 * Y) / (X + 15 * Y + 3 * Z);
		double upr = (4 * Xr) / (Xr + 15 * Yr + 3 * Zr);
		double vpr = (9 * Yr) / (Xr + 15 * Yr + 3 * Zr);

		double L;
		if (yr > e) L = 116 * Math.pow(yr, 1 / 3.0) - 16;
		else L = k * yr;
		double u = 13 * L * (up - upr);
		double v = 13 * L * (vp - vpr);

		// round off to three decimal point
		L = M.round(L, 3);
		u = M.round(u, 3);
		v = M.round(v, 3);

		// return
		luv[0] = L;
		luv[1] = u;
		luv[2] = v;
	}

	public static void fromLuv(double luv[], double xyz[]) {
		// Reference White
		double Xr = 95.047;
		double Yr = 100.000;
		double Zr = 108.883;

		// CIE Standard constants
		double e = 0.008856;
		double k = 903.3;

		// Input
		double L = luv[0];
		double u = luv[1];
		double v = luv[2];

		double ur = (4 * Xr) / (Xr + 15 * Yr + 3 * Zr);
		double vr = (9 * Yr) / (Xr + 15 * Yr + 3 * Zr);

		double Y;
		if (L > k * e) Y = Math.pow((L + 16) / 116, 3);
		else Y = L / k;

		double a = ((52 * L) / (u + 13 * L * ur) - 1) / 3.0;
		double b = -5 * Y;
		double c = -1 / 3.0;
		double d = Y * ((39 * L) / (v + 13 * L * vr) - 5);

		double X = (d - b) / (a - c);
		double Z = X * a + b;

		// scale XYZ
		X *= 100.0;
		Y *= 100.0;
		Z *= 100.0;

		// round off to three decimal point
		X = M.round(X, 3);
		Y = M.round(Y, 3);
		Z = M.round(Z, 3);

		// return
		xyz[0] = X;
		xyz[1] = Y;
		xyz[2] = Z;
	}

	// Color Test
	public static boolean isSameIgnoreAlpha(int rgb1, int rgb2) {
		// crop alpha
		rgb1 &= 0xFFFFFF;
		rgb2 &= 0xFFFFFF;
		// compare
		return rgb1 == rgb2;
	}

	public static boolean isPink(int rgb) {
		return isSameIgnoreAlpha(rgb, 0xFF00FF);
	}

	// Random
	public static int random() {
		return C.rgb(R.uniform_inclusive_s32(0, 255), R.uniform_inclusive_s32(0, 255), R.uniform_inclusive_s32(0, 255));
	}
}
