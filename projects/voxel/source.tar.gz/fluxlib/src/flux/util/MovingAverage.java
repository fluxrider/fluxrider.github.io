/*
 * Written by David Lareau on September 7, 2011.
 * 
 * A moving average.
 */
package flux.util;

import flux.data.OverwriteCircularArray_double;

public class MovingAverage {

	// Attributes
	private OverwriteCircularArray_double t;

	// Construct
	public MovingAverage(int capacity) {
		t = new OverwriteCircularArray_double(capacity);
	}

	// Methods
	public void add(double x) {
		t.add(x);
	}

	public double get() {
		int n = t.size();
		if (n == 0) return 0;
		double sum = 0;
		for (int i = 0; i < n; i++) {
			sum += t.get(i);
		}
		return sum / n;
	}

}
