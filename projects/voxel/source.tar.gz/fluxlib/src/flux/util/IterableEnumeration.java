package flux.util;

import java.util.Enumeration;
import java.util.Iterator;

@SuppressWarnings("unchecked")
public class IterableEnumeration<T> implements Iterator<T>, Iterable<T> {

	private Enumeration e;

	public IterableEnumeration(Enumeration e) {
		this.e = e;
	}

	public boolean hasNext() {
		return e.hasMoreElements();

	}

	public T next() {
		return (T) e.nextElement();
	}

	public void remove() {
	}

	public Iterator<T> iterator() {
		return this;
	}

}
