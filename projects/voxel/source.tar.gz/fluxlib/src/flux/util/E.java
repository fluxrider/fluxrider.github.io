/*
 * Written by David Lareau on Septmber 15, 2011.
 * 
 * Collection of common enum values.
 */
package flux.util;

public class E {

	// Coordinate Index
	public static final int X = 0;
	public static final int Y = 1;
	public static final int Z = 2;

	// Direction
	public static final int NONE = 0;
	public static final int EAST = 1;
	public static final int SOUTH = 2;
	public static final int WEST = 3;
	public static final int NORTH = 4;

	public static int leftOf(int dir) {
		if (dir == EAST) return NORTH;
		if (dir == SOUTH) return EAST;
		if (dir == WEST) return SOUTH;
		if (dir == NORTH) return WEST;
		throw new RuntimeException("Invalid Enum: " + dir);
	}

	public static int rightOf(int dir) {
		if (dir == EAST) return SOUTH;
		if (dir == SOUTH) return WEST;
		if (dir == WEST) return NORTH;
		if (dir == NORTH) return EAST;
		throw new RuntimeException("Invalid Enum: " + dir);
	}

	public static int oppositeOf(int dir) {
		if (dir == EAST) return WEST;
		if (dir == SOUTH) return NORTH;
		if (dir == WEST) return EAST;
		if (dir == NORTH) return SOUTH;
		throw new RuntimeException("Invalid Enum: " + dir);
	}

	// Cube Face
	public static final int FRONT = 0;
	public static final int REAR = 1;
	public static final int LEFT = 2;
	public static final int RIGHT = 3;
	public static final int TOP = 4;
	public static final int BOTTOM = 5;

}
