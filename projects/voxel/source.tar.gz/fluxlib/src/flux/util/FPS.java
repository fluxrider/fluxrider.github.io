/*
 * Written by David Lareau on March 5, 2010.
 * 
 * Compute frame per second.
 */
package flux.util;

import flux.data.OverwriteCircularArray_double;
import flux.math.M;
import flux.time.Timer;

public class FPS {

	// Attributes
	private int frameCount;
	private int fpsInterval;
	private double fps;
	private Timer fpsTimer;
	private long lastFPSTime;
	private OverwriteCircularArray_double history;

	// Construct
	public FPS() {
		this(1000, 60);
	}

	public FPS(int interval, int historyLength) {
		this.fpsTimer = new Timer();
		this.fpsInterval = interval;
		history = new OverwriteCircularArray_double(historyLength);
	}

	// Method
	public void frame() {
		// fps
		frameCount++;
		if (fpsTimer.lastCheck(fpsInterval)) {
			long now = System.currentTimeMillis();
			fps = frameCount * 1000 / (double) (now - lastFPSTime);
			frameCount = 0;
			if (lastFPSTime > 0) history.add(fps);
			lastFPSTime = now;
		}
	}

	public double get() {
		return M.round(fps, 1);
	}

	public double min() {
		if (!history.empty()) {
			double min = history.get(0);
			for (int i = 1; i < history.size(); i++) {
				double v = history.get(i);
				if (v < min) min = v;
			}
			return M.round(min, 1);
		}
		return 0;
	}

	public double max() {
		if (!history.empty()) {
			double max = history.get(0);
			for (int i = 1; i < history.size(); i++) {
				double v = history.get(i);
				if (v > max) max = v;
			}
			return M.round(max, 1);
		}
		return 0;
	}

	public double stddev() {
		double sum = 0;
		double sum2 = 0;
		int n = history.size();
		for (int i = 0; i < n; i++) {
			double v = history.get(i);
			sum += v;
			sum2 += v * v;
		}
		double mean = sum / n;
		double variance = (sum2 / (n - 1)) - ((n / (double) (n - 1)) * mean * mean);
		return Math.sqrt(variance);
	}
}
