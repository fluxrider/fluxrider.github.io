/* 
 * Written by David Lareau on August 27, 2011
 * 
 * Configurations file.
 */
package flux.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Map;
import java.util.TreeMap;

public class K {

	// Attributes
	private Map<String, String> map = new TreeMap<String, String>();
	private String autosave;

	// Construct (defaults are key=value pairs)
	public K(String filename, boolean autosave, String... defaults) {
		read(filename, defaults);
		if (autosave) {
			this.autosave = filename;
			write(filename);
		}
	}

	// Methods
	public boolean has(String key) {
		return map.containsKey(key);
	}

	public String get(String key) {
		return map.get(key);
	}

	public void set(String key, String value) {
		if (key.contains("=")) throw new RuntimeException("K does not support keys with '=' in them like: " + key);
		if (value.contains("=")) throw new RuntimeException("K does not support values with '=' in them like: " + value);
		map.put(key, value);
		if (autosave != null) write(autosave);
	}

	// IO
	public void write(String filename) {
		try {
			PrintWriter out = new PrintWriter(new FileOutputStream(filename));
			for (String key : map.keySet()) {
				out.println(String.format("%s=%s", key, map.get(key)));
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void read(String filename, String... defaults) {
		// Initialize with default values
		for (String pair : defaults) {
			handlePair(pair);
		}

		// Read values from file
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(filename)));
			String line;
			while ((line = in.readLine()) != null) {
				handlePair(line);
			}
			in.close();
		} catch (IOException e) {
		}
	}

	private void handlePair(String pair) {
		if (pair.indexOf('=') == -1) throw new RuntimeException("Expecting key=value pair, not " + pair);
		String parts[] = pair.split("=");
		map.put(parts[0], parts.length == 2 ? parts[1] : "");
	}

}
