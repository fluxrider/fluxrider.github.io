/*
 * Written by David Lareau.
 * 
 * Collection of time functions that I find handy.
 */
package flux.time;

public class T {

	// Sleep (handles exception)
	public static final void sleep(long milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	// Hour/Minute/Seconds from milliseconds
	public static final int hours(long milliseconds) {
		return (int) (milliseconds / (1000 * 60 * 60));
	}

	public static final int minutes(long milliseconds, boolean resetOnHour) {
		int t = (int) (milliseconds / (1000 * 60));
		if (resetOnHour) t %= 60;
		return t;
	}

	public static final int seconds(long milliseconds, boolean resetOnMinute) {
		int t = (int) (milliseconds / 1000);
		if (resetOnMinute) t %= 60;
		return t;
	}

	public static final int milliseconds(long milliseconds, boolean resetOnSeconds) {
		long t = milliseconds;
		if (resetOnSeconds) t %= 1000;
		return (int) t;
	}

	public static final String text(long ms) {
		return T.hours(ms) + ":" + T.minutes(ms, true) + ":" + T.seconds(ms, true);
	}

	// Timer (static instance)
	public static Timer timer = new Timer();

	public static final boolean lastCheck(long interval) {
		return timer.lastCheck(interval);
	}

	public static final void reset() {
		timer.reset();
	}

	public static final long elapsed() {
		return timer.elapsed();
	}

}
