/*
 * Written by David Lareau.
 * 
 * A sphere.
 */
package flux.geo3D;

public class Sphere {

	// Attributes
	private Point3D center;
	private double radius;

	// Construct
	public Sphere(Point3D center_, double radius) {
		this.center = new Point3D(center_);
		this.radius = radius;
	}

	// Methods
	public Point3D getCenter() {
		return center;
	}

	public double getRadius() {
		return radius;
	}

}
