/*
 * Written by David Lareau.
 * 
 * A point in 3D space. I'm supporting basic vector methods (normalize and length). Other operations like dot and cross product are in flux.geo3D.G.
 */
package flux.geo3D;

public class Point3D {

	// Attributes (public)
	public double x;
	public double y;
	public double z;

	// Construct
	public Point3D() {
		this(0, 0, 0);
	}

	public Point3D(double x, double y, double z) {
		set(x, y, z);
	}

	public Point3D(Point3D p_) {
		set(p_);
	}

	public String toString() {
		return String.format("(%.2f,%.2f,%.2f)", x, y, z);
	}

	public void set(double x, double y, double z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public void set(Point3D p_) {
		this.x = p_.x;
		this.y = p_.y;
		this.z = p_.z;
	}

	// Vector Methods
	public double normalizeInPlace() {
		double length = length();
		x /= length;
		y /= length;
		z /= length;
		return length;
	}

	public double length() {
		return Math.sqrt(length2());
	}

	public double length2() {
		return G.dot(this, this);
	}

	// Static Methods
	public static final double length(double x, double y, double z) {
		return Math.sqrt(length2(x, y, z));
	}

	public static final double length2(double x, double y, double z) {
		return x * x + y * y + z * z;
	}

}
