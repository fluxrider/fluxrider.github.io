/*
 * Written by David Lareau.
 * 
 * A line in 3D space. Different forms are supported to define the line.
 */
package flux.geo3D;

public class Line3D {

	// Attributes
	private Point3D p;
	private Point3D q;

	// Construct
	public Line3D(Point3D p_, Point3D q_) {
		this();
		set(p_, q_);
	}

	public Line3D() {
		// empty line, makes no sense but is used by V to create an object pool
		this.p = new Point3D();
		this.q = new Point3D();
	}

	public String toString() {
		return String.format("%s-%s", p, q);
	}

	public void set(Point3D p_, Point3D q_) {
		this.p.set(p_);
		this.q.set(q_);
	}

	public void set(double px, double py, double pz, double qx, double qy, double qz) {
		p.set(px, py, pz);
		q.set(qx, qy, qz);
	}

	// Methods
	public Point3D getP() {
		return p;
	}

	public Point3D getQ() {
		return q;
	}

	public Point3D getVectorQPUnormalized_() {
		return G.sub_(q, p);
	}

}
