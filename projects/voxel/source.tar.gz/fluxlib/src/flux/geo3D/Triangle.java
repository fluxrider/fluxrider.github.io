/*
 * Written by David Lareau.
 * 
 * A triangle.
 */
package flux.geo3D;

public class Triangle {

	// Attributes
	private Point3D a;
	private Point3D b;
	private Point3D c;

	// Construct
	public Triangle(Point3D a_, Point3D b_, Point3D c_) {
		this.a = new Point3D(a_);
		this.b = new Point3D(b_);
		this.c = new Point3D(c_);
	}

	// Methods
	public Point3D getA() {
		return a;
	}

	public Point3D getB() {
		return b;
	}

	public Point3D getC() {
		return c;
	}

}
