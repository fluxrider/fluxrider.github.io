/*
 * Written by David Lareau on September 11, 2011.
 * 
 * A grid of voxels stored in a byte buffer.
 * The buffer allows quick copy to a PBO buffer.
 * 
 * The voxel format is decided by the conversion methods supplied.
 * 
 * (Note: origin is bottom left corner of voxel model, positive y going up, unlike 2D image, this feels better in 3D)
 */
package flux.opengl.voxel;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.nio.ByteBuffer;

import flux.geo3D.Point3D;
import flux.util.C;

public class VoxelModelGL {

	// Attributes
	private ByteBuffer grid;
	private final int W, H, D; // dimensions of grid: width, height and depth
	private final VoxelFormat format;

	// Construct
	public VoxelModelGL(int width, int height, int depth, VoxelFormat format) {
		this.W = width;
		this.H = height;
		this.D = depth;
		this.format = format;
		this.grid = ByteBuffer.allocateDirect(W * H * D * format.getPixelDataSize());
	}

	// Methods
	public final int getRGBA(int x, int y, int z) {
		if (!inBounds(x, y, z)) return (Color.MAGENTA.getRGB() & 0x00FFFFFF); // transparent pink
		grid.position(format.offset(x, y, z, W, H, D));
		return format.format2rgba(grid);
	}

	public final boolean inBounds(int x, int y, int z) {
		return !(x < 0 || y < 0 || z < 0 || x >= W || y >= H || z >= D);
	}

	public final boolean has(int x, int y, int z) {
		return C.isOpaque(getRGBA(x, y, z));
	}

	public final void setRGBA(int x, int y, int z, int rgba) {
		if (!inBounds(x, y, z)) throw new RuntimeException(String.format("Out of bound %d,%d,%d %dx%dx%d", x, y, z, W, H, D));
		grid.position(format.offset(x, y, z, W, H, D));
		format.rgba2format(rgba, grid);
	}

	public final int getWidth() {
		return W;
	}

	public final int getHeight() {
		return H;
	}

	public final int getDepth() {
		return D;
	}

	public final ByteBuffer getBuffer() {
		grid.position(0);
		return grid;
	}

	public final VoxelFormat getFormat() {
		return format;
	}

	// Static Load
	public static VoxelModelGL read(BufferedImage image, int rows, int columns, VoxelFormat format) {
		int iw = image.getWidth();
		int ih = image.getHeight();

		// init grid dimensions
		if (iw % columns != 0) throw new RuntimeException("Image not dividable in specified number of columns: " + iw + " % " + columns + " != 0, its " + (iw % columns));
		if (ih % rows != 0) throw new RuntimeException("Image not dividable in specified number of rows: " + ih + " % " + rows + " != 0, its " + (ih % rows));
		int W = iw / columns;
		int H = ih / rows;
		int D = rows * columns;
		VoxelModelGL model = new VoxelModelGL(W, H, D, format);

		// for each cell (z-slice) in the image, enter the values in the grid
		int z = 0;
		for (int r = 0; r < rows; r++) {
			int yoffset = H * r;
			for (int c = 0; c < columns; c++) {
				int xoffset = W * c;
				for (int y = 0; y < H; y++) {
					for (int x = 0; x < W; x++) {
						model.setRGBA(x, H - y - 1, z, image.getRGB(xoffset + x, yoffset + y));
					}
				}
				z++;
			}
		}

		return model;
	}

	// Point3D convenience
	public final int getRGBA(Point3D p) {
		return getRGBA((int) p.x, (int) p.y, (int) p.z);
	}

	public final boolean inBounds(Point3D p) {
		return inBounds((int) p.x, (int) p.y, (int) p.z);
	}

	public final boolean has(Point3D p) {
		return has((int) p.x, (int) p.y, (int) p.z);
	}

	public final void setRGBA(Point3D p, int rgba) {
		setRGBA((int) p.x, (int) p.y, (int) p.z, rgba);
	}

}
