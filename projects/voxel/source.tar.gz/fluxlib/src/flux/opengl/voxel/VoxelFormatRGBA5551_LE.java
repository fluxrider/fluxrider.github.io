/*
 * Written by David Lareau on September 11, 2011.
 *
 * Converts to follow GL_RGBA rules.
 * Amongst other thing, the y is upside down (0 is bottom)
 */
package flux.opengl.voxel;

import java.nio.ByteBuffer;

import javax.media.opengl.GL;

import flux.util.C;

public class VoxelFormatRGBA5551_LE implements VoxelFormat {

	public int getPixelDataSize() {
		return 2;
	}

	public int getPixelDataFormat() {
		return GL.GL_RGBA;
	}

	public int getPixelDataType() {
		return GL.GL_UNSIGNED_SHORT_5_5_5_1;
	}

	public int getInternalFormat() {
		return GL.GL_RGB5_A1;
	}

	public int offset(int x, int y, int z, int W, int H, int D) {
		return (z * H * W + (H - y - 1) * W + x) * 2;
	}

	public void rgba2format(int rgba, ByteBuffer out) {
		int r = C.r(rgba) / 8;
		int g = C.g(rgba) / 8;
		int b = C.b(rgba) / 8;
		int a = C.isFullyTransparent(rgba) ? 0 : 1;

		int high = (r << 3) | (g >>> 2);
		g &= 3; // keep lower two bytes only (uncessessary)
		int low = (g << 6) | (b << 1) | a;

		out.put((byte) low);
		out.put((byte) high);
	}

	public int format2rgba(ByteBuffer in) {
		int low = in.get() & 0x00FF;
		int high = in.get() & 0x00FF;
		int r = (high >>> 3) * 8;
		int g = (((high & 7) << 2) | (low >>> 6)) * 8;
		int b = ((low >>> 1) & 31) * 8;
		int a = ((low & 1) == 0) ? 0 : 255;
		return C.rgba(r, g, b, a);
	}
}
