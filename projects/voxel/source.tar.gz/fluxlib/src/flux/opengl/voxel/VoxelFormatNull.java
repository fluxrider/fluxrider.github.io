/*
 * Written by David Lareau on September 11, 2011.
 *
 * Does no conversion, simply copies the rgba integer to the buffer.
 */
package flux.opengl.voxel;

import java.nio.ByteBuffer;

public class VoxelFormatNull implements VoxelFormat {

	public int getPixelDataSize() {
		return 4;
	}

	public int getPixelDataFormat() {
		throw new RuntimeException("Not meant to be used by opengl");
	}

	public int getPixelDataType() {
		throw new RuntimeException("Not meant to be used by opengl");
	}

	public int getInternalFormat() {
		throw new RuntimeException("Not meant to be used by opengl");
	}

	public int offset(int x, int y, int z, int W, int H, int D) {
		return (z * H * W + y * W + x) * getPixelDataSize();
	}

	public void rgba2format(int rgba, ByteBuffer out) {
		out.putInt(rgba);
	}

	public int format2rgba(ByteBuffer in) {
		return in.getInt();
	}

}
