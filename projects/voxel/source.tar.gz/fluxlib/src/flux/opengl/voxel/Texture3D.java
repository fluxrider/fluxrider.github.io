/*
 * Written by David Lareau on September 5, 2011.
 * 
 * 3D Texture utility
 */
package flux.opengl.voxel;

import javax.media.opengl.GL2;

public class Texture3D {

	public static int loadTexture(GL2 gl, VoxelModelGL img, boolean enableMinLinear, boolean enableMagLinear) {
		int id = genOneTextureID(gl);
		loadTexture(gl, id, img, enableMinLinear, enableMagLinear);
		return id;
	}

	public static void loadTexture(GL2 gl, int textureID, VoxelModelGL img, boolean enableMinLinear, boolean enableMagLinear) {
		gl.glActiveTexture(GL2.GL_TEXTURE0);
		gl.glBindTexture(GL2.GL_TEXTURE_3D, textureID);
		loadTexture(gl, img);
		gl.glTexParameterf(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_WRAP_S, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameterf(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_WRAP_T, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameterf(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_WRAP_R, GL2.GL_CLAMP_TO_EDGE);
		gl.glTexParameteri(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_MIN_FILTER, enableMinLinear ? GL2.GL_LINEAR : GL2.GL_NEAREST);
		gl.glTexParameteri(GL2.GL_TEXTURE_3D, GL2.GL_TEXTURE_MAG_FILTER, enableMagLinear ? GL2.GL_LINEAR : GL2.GL_NEAREST);
	}

	public static void loadTexture(GL2 gl, VoxelModelGL img) {
		// waste memory at the sake of simplicity: make any loaded image full rgba texture
		int W = img.getWidth();
		int H = img.getHeight();
		int D = img.getDepth();
		gl.glTexImage3D(GL2.GL_TEXTURE_3D, 0, img.getFormat().getInternalFormat(), W, H, D, 0, img.getFormat().getPixelDataFormat(), img.getFormat().getPixelDataType(), img.getBuffer());
	}

	public static int genOneTextureID(GL2 gl) {
		final int[] tmp = new int[1];
		gl.glGenTextures(1, tmp, 0);
		return tmp[0];
	}

	public static void delete(GL2 gl, int id) {
		final int[] tmp = new int[1];
		tmp[0] = id;
		gl.glDeleteTextures(1, tmp, 0);
	}

}
