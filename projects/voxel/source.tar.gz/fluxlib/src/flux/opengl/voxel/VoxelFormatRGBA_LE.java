/*
 * Written by David Lareau on September 11, 2011.
 *
 * Converts to follow GL_RGBA rules.
 * Amongst other thing, the y is upside down (0 is bottom)
 * 
 * This class also optimizes 3-dimensional lookup by building lookup tables (actually, this hinders speed instead of speeding things up, so its commented out)
 */
package flux.opengl.voxel;

import java.nio.ByteBuffer;

import javax.media.opengl.GL;

import flux.util.C;

public class VoxelFormatRGBA_LE implements VoxelFormat {

	// Voxel Format
	public int getPixelDataSize() {
		return 4;
	}

	public int getPixelDataFormat() {
		return GL.GL_RGBA;
	}

	public int getPixelDataType() {
		return GL.GL_UNSIGNED_BYTE;
	}

	public int getInternalFormat() {
		return GL.GL_RGBA;
	}

	public final int offset(final int x, final int y, final int z, final int W, final int H, final int D) {
		return (z * H * W + (H - y - 1) * W + x) * 4;
		//if (zs == null) buildLookups(W, H, D);
		//return zs[z] + ys[y] + xs[x];
	}

	public final void rgba2format(int rgba, ByteBuffer out) {
		out.put((byte) C.r(rgba));
		out.put((byte) C.g(rgba));
		out.put((byte) C.b(rgba));
		out.put((byte) C.a(rgba));
	}

	public final int format2rgba(ByteBuffer in) {
		int r = in.get() & 0x00FF;
		int g = in.get() & 0x00FF;
		int b = in.get() & 0x00FF;
		int a = in.get() & 0x00FF;
		return C.rgba(r, g, b, a);
	}

	// Lookup table optimization
	/*
	private int zs[];
	private int ys[];
	private int xs[];

	private void buildLookups(int W, int H, int D) {
		zs = new int[D];
		for (int z = 0; z < D; z++) {
			zs[z] = z * H * W * 4;
		}
		ys = new int[H];
		for (int y = 0; y < H; y++) {
			ys[y] = (H - y - 1) * W * 4;
		}
		xs = new int[W];
		for (int x = 0; x < W; x++) {
			xs[x] = x * 4;
		}
	}
	*/

}
