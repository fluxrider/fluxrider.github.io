/*
 * Written by David Lareau on September 11, 2011.
 *
 * Defines the format of a voxel by supplying conversion methods from and to rgba for it.
 */
package flux.opengl.voxel;

import java.nio.ByteBuffer;

public interface VoxelFormat {

	public int getPixelDataSize(); // size of format

	public int getPixelDataFormat(); // ex: GL_RGBA

	public int getPixelDataType(); // ex: GL_UNSIGNED_BYTE, GL_UNSIGNED_SHORT_5_5_5_1

	public int getInternalFormat(); // ex: GL_RGBA, GL_RGB5_A1

	public int offset(int x, int y, int z, int W, int H, int D); // address of data[x][y][z] in bytebuffer

	public void rgba2format(int rgba, ByteBuffer out); // convert rgba to this pixel format

	public int format2rgba(ByteBuffer in); // convert this pixel format to rgba

}
