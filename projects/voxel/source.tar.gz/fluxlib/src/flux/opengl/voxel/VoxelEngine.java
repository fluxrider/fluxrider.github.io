/*
 * Written by David Lareau on September 10, 2011.
 * 
 * Renders a voxel space. This class is more a template/example than anything else, and only usufull for simple app.
 *
 * Overwrite tick to: 
 *  - handle your own input 
 *  - update the voxel model for the next frame
 *  - setup camera options
 *  - setup lighting options
 *  
 * Current issues:
 *  - computer crashed once (possible factors: bad drivers, overheating card, jogl issue)
 *  - there are depth buffer battles bettween the planes (visible when any lighting is on)
 *  - aliasing
 *  - severe artifact when fsaa is enabled
 *  
 * Feature request:
 *  - palette format
 *  - mouse events
 *  - joystick events
 */
package flux.opengl.voxel;

import java.nio.ByteBuffer;

import javax.media.opengl.GL;
import javax.media.opengl.GL2;
import javax.media.opengl.GL3;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.glu.GLU;

import com.jogamp.newt.opengl.GLWindow;

import flux.geo3D.Point3D;
import flux.opengl.OpenGLWindow;
import flux.opengl.PolledInput;
import flux.time.T;
import flux.util.E;
import flux.util.FPS;

public class VoxelEngine extends OpenGLWindow {

	// Visible Attributes
	protected final VoxelModelGL model;
	protected FPS fps;
	protected Point3D from, at, up;
	protected double fov, near, far;
	protected double rotx, roty, rotz;
	protected double scale;
	protected Point3D translate;
	protected boolean useFakeLight;
	protected double fakeLight[];
	protected boolean useGLLight;
	protected Point3D glLightPosition;
	protected boolean smoothShading;
	protected Point3D textureOffsetX, textureOffsetY, textureOffsetZ;
	protected boolean usingOrtho;
	protected double orthoLeft, orthoRight, orthoBottom, orthoTop, orthoNear, orthoFar;

	// Private Attributes
	private int modelTexture;
	private int pboIds[];
	private int pboIndex;
	private GLU glu;
	private int reshapeX, reshapeY, reshapeW, reshapeH;

	// Construct
	public VoxelEngine(int W, int H, int D, boolean fsaa) {
		super(true, true, true, true, fsaa);
		modelTexture = -1;
		glu = new GLU();

		this.model = new VoxelModelGL(W, H, D, new VoxelFormatRGBA_LE());

		// Fill model with random colors, and a red front 
		/*
		for (int z = 0; z < D; z++) {
			for (int y = 0; y < H; y++) {
				for (int x = 0; x < W; x++) {
					int c = C.random();
					if (z == 0) c = 0xFF0000;
					if (Math.random() < .2) c &= 0x00FFFFFF; // set transparent
					else c |= 0xFF000000; // set opaque
					model.setRGBA(x, y, z, c);
				}
			}
		}
		*/

		// init camera
		from = new Point3D(0, 0, 1.5 * D);
		at = new Point3D(0, 0, 0);
		up = new Point3D(0, 1, 0);
		fov = 60;
		near = .1;
		far = 1000;
		translate = new Point3D(0, 0, 0);
		scale = 1;

		// misc
		glLightPosition = new Point3D(.7, .7, .7);
		fakeLight = new double[6];
		fakeLight[E.TOP] = 1;
		fakeLight[E.BOTTOM] = .25;
		fakeLight[E.FRONT] = .85;
		fakeLight[E.REAR] = .40;
		fakeLight[E.RIGHT] = .70;
		fakeLight[E.LEFT] = .55;
		smoothShading = false;
		textureOffsetX = new Point3D(0, 0, 0);
		textureOffsetY = new Point3D(0, 0, 0);
		textureOffsetZ = new Point3D(0, 0, 0);
		fps = new FPS(1000, 10);
	}

	// OpenGLWindow
	public void tick() {
		if (input.held(PolledInput.FK_ESCAPE)) isRunningMainLoop = false;
		if (input.typed(PolledInput.FK_LEFT)) roty -= 5;
		if (input.typed(PolledInput.FK_RIGHT)) roty += 5;
		if (input.typed(PolledInput.FK_UP)) rotx -= 5;
		if (input.typed(PolledInput.FK_DOWN)) rotx += 5;
		if (input.typed(PolledInput.FK_R)) {
			rotx = roty = 0;
			scale = 1;
			useFakeLight = false;
			useGLLight = false;
		}
		if (input.typed(PolledInput.FK_F)) useFakeLight = !useFakeLight;
		if (input.typed(PolledInput.FK_G)) useGLLight = !useGLLight;

		if (input.typed(PolledInput.FK_NUMPAD_ADD)) scale *= 2;
		if (input.typed(PolledInput.FK_NUMPAD_SUBTRACT)) scale /= 2;
		input.polled();

		// update model once in while and show fps
		if (T.lastCheck(1000)) {
			System.out.println(String.format("FPS: %.2f", fps.get()));
		}
	}

	public void init(GLAutoDrawable drawable) {
		GL2 gl = drawable.getGL().getGL2();

		// disable vsync
		gl.setSwapInterval(0);

		// Smooth Points and Lines
		gl.glEnable(GL2.GL_BLEND);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		/*
		gl.glEnable(GL2.GL_POINT_SMOOTH);
		gl.glHint(GL2.GL_POINT_SMOOTH_HINT, GL2.GL_NICEST);
		gl.glEnable(GL2.GL_LINE_SMOOTH);
		gl.glHint(GL2.GL_LINE_SMOOTH_HINT, GL2.GL_NICEST);
		*/

		// Depth
		gl.glClearDepth(1.0f);
		gl.glEnable(GL2.GL_DEPTH_TEST);
		//gl.glDepthFunc(GL2.GL_LEQUAL);
		gl.glDepthFunc(GL2.GL_LESS);
		//gl.glDepthFunc(GL2.GL_NOTEQUAL);
		// almost completly transparent pixel will not update the z-buffer
		gl.glAlphaFunc(GL2.GL_GREATER, 0.1f);
		gl.glEnable(GL2.GL_ALPHA_TEST);

		// Culling
		gl.glFrontFace(GL2.GL_CCW);
		gl.glEnable(GL2.GL_CULL_FACE);
		gl.glCullFace(GL2.GL_BACK);

		// Lighting (must now specify normals)
		gl.glEnable(GL2.GL_LIGHTING);
		gl.glEnable(GL2.GL_COLOR_MATERIAL);
		gl.glShadeModel(smoothShading ? GL2.GL_SMOOTH : GL2.GL_FLAT);
		gl.glColorMaterial(GL2.GL_FRONT_AND_BACK, GL2.GL_AMBIENT_AND_DIFFUSE);
		gl.glEnable(GL2.GL_LIGHT0);
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_AMBIENT, new float[] { .5f, .5f, .5f, 1 }, 0);
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_DIFFUSE, new float[] { 1, 1, 1, 1 }, 0);
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_SPECULAR, new float[] { 0, 0, 0, 1 }, 0);
		gl.glMaterialfv(GL2.GL_FRONT_AND_BACK, GL2.GL_EMISSION, new float[] { 0.0f, 0.0f, 0.0f, 1.0f }, 0);
		gl.glMaterialfv(GL2.GL_FRONT_AND_BACK, GL2.GL_SPECULAR, new float[] { 0.0f, 0.0f, 0.0f, 1.0f }, 0);

		// Texture
		gl.glEnable(GL2.GL_TEXTURE_3D);
		gl.glHint(GL2.GL_PERSPECTIVE_CORRECTION_HINT, GL.GL_NICEST);
	}

	public void reshape(GLAutoDrawable drawable, int x, int y, int w, int h) {
		reshapeX = x;
		reshapeY = y;
		reshapeW = w;
		reshapeH = h;
		GL2 gl = drawable.getGL().getGL2();
		gl.glMatrixMode(GL2.GL_PROJECTION);
		gl.glLoadIdentity();
		if(usingOrtho) gl.glOrtho(orthoLeft, orthoRight, orthoBottom, orthoTop, orthoNear, orthoFar);
		else glu.gluPerspective(fov, w / (double) h, near, far);
		glu.gluLookAt(from.x, from.y, from.z, at.x, at.y, at.z, up.x, up.y, up.z);
		gl.glMatrixMode(GL2.GL_MODELVIEW);
		gl.glLoadIdentity();
		gl.glViewport(0, 0, w, h);
	}

	public void dispose(GLAutoDrawable drawable) {
		GL2 gl = drawable.getGL().getGL2();
		if (modelTexture != -1) Texture3D.delete(gl, modelTexture);
		modelTexture = -1;
		if (pboIds != null) gl.glDeleteBuffers(2, pboIds, 0);
		pboIds = null;
	}

	public void display(GLAutoDrawable drawable) {
		// reset projecti matrix (in case lookat changed)
		reshape(drawable, reshapeX, reshapeY, reshapeW, reshapeH);

		// clear buffers
		GL2 gl = drawable.getGL().getGL2();
		gl.glClear(GL3.GL_COLOR_BUFFER_BIT | GL3.GL_DEPTH_BUFFER_BIT);
		gl.glLoadIdentity();

		// Rotate according to input
		gl.glScaled(scale, scale, scale);
		gl.glRotated(rotx, 1, 0, 0);
		gl.glRotated(roty, 0, 1, 0);
		gl.glRotated(rotz, 0, 0, 1);
		gl.glTranslated(translate.x, translate.y, translate.z);

		// Light (GL)
		if (useGLLight) {
			gl.glEnable(GL2.GL_LIGHTING);
			gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, new float[] { (float) glLightPosition.x, (float) glLightPosition.y, (float) glLightPosition.z, 1.0f }, 0);
			gl.glLightf(GL2.GL_LIGHT0, GL2.GL_ATTENUATION_EXT, GL2.GL_LINEAR_ATTENUATION);
			gl.glShadeModel(smoothShading ? GL2.GL_SMOOTH : GL2.GL_FLAT);
		} else {
			gl.glDisable(GL2.GL_LIGHTING);
		}

		// Render Voxel (Note: origin is bottom left corner of voxel model, positive y going up)
		int W = model.getWidth();
		int H = model.getHeight();
		int D = model.getDepth();
		updateTexture(gl);

		// Draw quads with 3D texture
		gl.glPushMatrix();
		gl.glTranslated(-W / 2.0, -H / 2.0, D / 2.0);
		gl.glBindTexture(GL2.GL_TEXTURE_3D, modelTexture);
		double dx = 1;
		double dy = 1;
		double dz = 1;
		gl.glBegin(GL2.GL_QUADS);
		// draw the z-quads
		for (int reverse = 0; reverse < 2; reverse++) {
			boolean reverseZ = reverse == 1;
			double light = useFakeLight ? fakeLight[reverseZ ? E.REAR : E.FRONT] : 1;
			gl.glColor4d(light, light, light, 1);
			for (int z = 0; z < D; z++) {
				double r = (z / (double) (D - 1));
				gl.glNormal3d(0, 0, reverseZ ? -1 : 1);
				if (reverseZ) {
					gl.glTexCoord3d(0 + textureOffsetZ.x, 1 + textureOffsetZ.y, r + textureOffsetZ.z);
					gl.glVertex3d(0, 0, -(z + 1) * dz);
					gl.glTexCoord3d(0 + textureOffsetZ.x, 0 + textureOffsetZ.y, r + textureOffsetZ.z);
					gl.glVertex3d(0, dy * H, -(z + 1) * dz);
					gl.glTexCoord3d(1 + textureOffsetZ.x, 0 + textureOffsetZ.y, r + textureOffsetZ.z);
					gl.glVertex3d(dx * W, dy * H, -(z + 1) * dz);
					gl.glTexCoord3d(1 + textureOffsetZ.x, 1 + textureOffsetZ.y, r + textureOffsetZ.z);
					gl.glVertex3d(dx * W, 0, -(z + 1) * dz);
				} else {
					gl.glTexCoord3d(0 + textureOffsetZ.x, 1 + textureOffsetZ.y, r + textureOffsetZ.z);
					gl.glVertex3d(0, 0, -z * dz);
					gl.glTexCoord3d(1 + textureOffsetZ.x, 1 + textureOffsetZ.y, r + textureOffsetZ.z);
					gl.glVertex3d(dx * W, 0, -z * dz);
					gl.glTexCoord3d(1 + textureOffsetZ.x, 0 + textureOffsetZ.y, r + textureOffsetZ.z);
					gl.glVertex3d(dx * W, dy * H, -z * dz);
					gl.glTexCoord3d(0 + textureOffsetZ.x, 0 + textureOffsetZ.y, r + textureOffsetZ.z);
					gl.glVertex3d(0, dy * H, -z * dz);
				}
			}
		}
		// draw the x-quads
		for (int reverse = 0; reverse < 2; reverse++) {
			boolean reverseX = reverse == 1;
			double light = useFakeLight ? fakeLight[reverseX ? E.LEFT : E.RIGHT] : 1;
			gl.glColor4d(light, light, light, 1);
			for (int x = 0; x < W; x++) {
				double s = (x / (double) (W - 1));
				gl.glNormal3d(reverseX ? -1 : 1, 0, 0);
				if (reverseX) {
					gl.glTexCoord3d(s + textureOffsetX.x, 1 + textureOffsetX.y, 0 + textureOffsetX.z);
					gl.glVertex3d(x * dz, 0, 0);
					gl.glTexCoord3d(s + textureOffsetX.x, 0 + textureOffsetX.y, 0 + textureOffsetX.z);
					gl.glVertex3d(x * dz, dy * H, 0);
					gl.glTexCoord3d(s + textureOffsetX.x, 0 + textureOffsetX.y, 1 + textureOffsetX.z);
					gl.glVertex3d(x * dz, dy * H, dz * -D);
					gl.glTexCoord3d(s + textureOffsetX.x, 1 + textureOffsetX.y, 1 + textureOffsetX.z);
					gl.glVertex3d(x * dz, 0, dz * -D);
				} else {
					gl.glTexCoord3d(s + textureOffsetX.x, 1 + textureOffsetX.y, 0 + textureOffsetX.z);
					gl.glVertex3d((x + 1) * dz, 0, 0);
					gl.glTexCoord3d(s + textureOffsetX.x, 1 + textureOffsetX.y, 1 + textureOffsetX.z);
					gl.glVertex3d((x + 1) * dz, 0, dz * -D);
					gl.glTexCoord3d(s + textureOffsetX.x, 0 + textureOffsetX.y, 1 + textureOffsetX.z);
					gl.glVertex3d((x + 1) * dz, dy * H, dz * -D);
					gl.glTexCoord3d(s + textureOffsetX.x, 0 + textureOffsetX.y, 0 + textureOffsetX.z);
					gl.glVertex3d((x + 1) * dz, dy * H, 0);
				}
			}
		}
		// draw the y-quads
		for (int reverse = 0; reverse < 2; reverse++) {
			boolean reverseY = reverse == 1;
			double light = useFakeLight ? fakeLight[reverseY ? E.BOTTOM : E.TOP] : 1;
			gl.glColor4d(light, light, light, 1);
			for (int y = 0; y < H; y++) {
				double t = 1 - (y / (double) (H - 1));
				gl.glNormal3d(0, reverseY ? -1 : 1, 0);
				if (reverseY) {
					gl.glTexCoord3d(0 + textureOffsetY.x, t + textureOffsetY.y, 0 + textureOffsetY.z);
					gl.glVertex3d(0, y * dy, 0);
					gl.glTexCoord3d(0 + textureOffsetY.x, t + textureOffsetY.y, 1 + textureOffsetY.z);
					gl.glVertex3d(0, y * dy, dz * -D);
					gl.glTexCoord3d(1 + textureOffsetY.x, t + textureOffsetY.y, 1 + textureOffsetY.z);
					gl.glVertex3d(dx * W, y * dy, dz * -D);
					gl.glTexCoord3d(1 + textureOffsetY.x, t + textureOffsetY.y, 0 + textureOffsetY.z);
					gl.glVertex3d(dx * W, y * dy, 0);
				} else {
					gl.glTexCoord3d(0 + textureOffsetY.x, t + textureOffsetY.y, 0 + textureOffsetY.z);
					gl.glVertex3d(0, (y + 1) * dy, 0);
					gl.glTexCoord3d(1 + textureOffsetY.x, t + textureOffsetY.y, 0 + textureOffsetY.z);
					gl.glVertex3d(dx * W, (y + 1) * dy, 0);
					gl.glTexCoord3d(1 + textureOffsetY.x, t + textureOffsetY.y, 1 + textureOffsetY.z);
					gl.glVertex3d(dx * W, (y + 1) * dy, dz * -D);
					gl.glTexCoord3d(0 + textureOffsetY.x, t + textureOffsetY.y, 1 + textureOffsetY.z);
					gl.glVertex3d(0, (y + 1) * dy, dz * -D);
				}
			}
		}
		gl.glEnd();
		gl.glBindTexture(GL3.GL_TEXTURE_3D, 0);
		gl.glPopMatrix();

		// Monitor Framerate
		fps.frame();
	}

	public void updateTexture(GL2 gl) {
		// Initialize pbo and texture
		long byteCount = model.getWidth() * model.getHeight() * model.getDepth() * model.getFormat().getPixelDataSize();
		if (pboIds == null) {
			pboIds = new int[2];
			gl.glGenBuffers(2, pboIds, 0);
			gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[0]);
			gl.glBufferData(GL2.GL_PIXEL_UNPACK_BUFFER, byteCount, null, GL2.GL_STREAM_DRAW);
			gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[1]);
			gl.glBufferData(GL2.GL_PIXEL_UNPACK_BUFFER, byteCount, null, GL2.GL_STREAM_DRAW);
			gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, 0);
			modelTexture = Texture3D.loadTexture(gl, model, false, false);
		}

		// Alternate between pbo (buffering optimization)
		pboIndex = (pboIndex + 1) % 2;
		int nextIndex = (pboIndex + 1) % 2;

		// Copy pixels of ready PBO to texture object
		gl.glBindTexture(GL2.GL_TEXTURE_3D, modelTexture);
		gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[pboIndex]);
		gl.glTexSubImage3D(GL2.GL_TEXTURE_3D, 0, 0, 0, 0, model.getWidth(), model.getHeight(), model.getDepth(), model.getFormat().getPixelDataFormat(), model.getFormat().getPixelDataType(), 0);

		// Fill new pixels to buffer PBO
		gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, pboIds[nextIndex]);
		gl.glBufferData(GL2.GL_PIXEL_UNPACK_BUFFER, byteCount, null, GL2.GL_STREAM_DRAW);
		ByteBuffer ptr = gl.glMapBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, GL2.GL_WRITE_ONLY);
		if (ptr != null) {
			ptr.put(model.getBuffer());
			ptr.flip();
			gl.glUnmapBuffer(GL2.GL_PIXEL_UNPACK_BUFFER);
		}
		gl.glBindBuffer(GL2.GL_PIXEL_UNPACK_BUFFER, 0);
	}

	// Main
	public static void main(String[] args) {
		System.out.println("Engage");

		VoxelEngine app = new VoxelEngine(10, 10, 10, false);
		GLWindow window = app.window;
		window.setTitle("Example OpenGLWindow main()");
		window.setPosition(100, 100);
		window.setSize(800, 600);
		window.setVisible(true);
		window.setUndecorated(true);

		app.mainLoop();
		window.destroy();

		System.out.println("Over and out");
		//System.exit(0); // necessary is JOptionPane is called 
	}
}
