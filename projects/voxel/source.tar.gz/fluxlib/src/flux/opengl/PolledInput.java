/*
 * Written by David Lareau on March 03, 2010
 * 
 * Wrapper around NEWT keyboard events that allow state polling.
 * Features:
 *  - mark lost events (ex: quick pressed & release between polls)
 *  - mark if the event is new (was not pressed during last poll, is pressed now)
 *  
 *  Sadly, some keyboard constants and mouse key code overlap so right now this class only deals with keyboard event. (KeyEvent.VK_CANCEL and MouseEvent.BUTTON_3)
 *  Also, there is no such thing as indexing keys from 0 to VK_COUNT in NEWT so I use maps.
 *  
 *  Bug: in linux, the letter events like VK_A are only generated when shift+a are pressed. I hope this will be resolved with an update.
 *  
 *  NOTE: September 10, 2011 update.
 *        Due to bugs in the newt key events, I am hardcoding the mapping that works for me.
 *        At the same time, I am numbering the virtual key code from 0 to COUNT, that way I can use a simple table instead of a map
 *  EXTRA NOTE: actually, current version of newt events on linux is pretty messed up and some keys return the same keycode
 */

package flux.opengl;

import java.util.Arrays;

import com.jogamp.newt.event.KeyEvent;
import com.jogamp.newt.event.KeyListener;
import com.jogamp.newt.event.WindowEvent;
import com.jogamp.newt.event.WindowListener;
import com.jogamp.newt.event.WindowUpdateEvent;

public class PolledInput implements WindowListener, KeyListener {

	// CONSTANTS
	public static final int FK_ESCAPE = 0;
	public static final int FK_LEFT = 1;
	public static final int FK_RIGHT = 2;
	public static final int FK_UP = 3;
	public static final int FK_DOWN = 4;
	public static final int FK_SPACE = 5;
	public static final int FK_ENTER = 6;
	public static final int FK_A = 7;
	public static final int FK_B = 8;
	public static final int FK_C = 9;
	public static final int FK_D = 10;
	public static final int FK_E = 11;
	public static final int FK_F = 12;
	public static final int FK_G = 13;
	public static final int FK_H = 14;
	public static final int FK_I = 15;
	public static final int FK_J = 16;
	public static final int FK_K = 17;
	public static final int FK_L = 18;
	public static final int FK_M = 19;
	public static final int FK_N = 20;
	public static final int FK_O = 21;
	public static final int FK_P = 22;
	public static final int FK_Q = 23;
	public static final int FK_R = 24;
	public static final int FK_S = 25;
	public static final int FK_T = 26;
	public static final int FK_U = 27;
	public static final int FK_V = 28;
	public static final int FK_W = 29;
	public static final int FK_X = 30;
	public static final int FK_Y = 31;
	public static final int FK_Z = 32;
	//public static final int FK_F1 = 33;
	//public static final int FK_F2 = 34;
	//public static final int FK_F3 = 35;
	//public static final int FK_F4 = 36;
	//public static final int FK_F5 = 37;
	//public static final int FK_F6 = 38;
	//public static final int FK_F7 = 39;
	//public static final int FK_F8 = 40;
	//public static final int FK_F9 = 41;
	//public static final int FK_F10 = 42;
	//public static final int FK_F11 = 43;
	//public static final int FK_F12 = 44;
	public static final int FK_NUMPAD_SUBTRACT = 45;
	public static final int FK_NUMPAD_ADD = 46;
	//public static final int FK_NUMPAD_ENTER = 47;  
	public static final int FK_TILDE = 48;
	public static final int FK_COUNT = 49;
	public static final int FK_UNKNOWN = -1;

	// Attributes
	private boolean[] keyboard_pressed;
	private boolean[] keyboard_changed;
	private boolean[] keyboard_lost;

	private boolean focused = true; // BUG: not exact, maybe the component is not focused on start
	private boolean destroyed;
	public boolean verbose;

	// Construct
	public PolledInput() {
		keyboard_pressed = new boolean[FK_COUNT];
		keyboard_changed = new boolean[FK_COUNT];
		keyboard_lost = new boolean[FK_COUNT];
	}

	// Methods
	public boolean typed(int key) {
		return (held(key) && changed(key)) || lost(key);
	}

	public boolean held(int key) {
		return keyboard_pressed[key];
	}

	public boolean changed(int key) {
		return keyboard_changed[key];
	}

	public boolean lost(int key) {
		return keyboard_lost[key];
	}

	public void polled() {
		Arrays.fill(keyboard_changed, false);
		Arrays.fill(keyboard_lost, false);
	}

	public void clearKeys() {
		Arrays.fill(keyboard_pressed, false);
		Arrays.fill(keyboard_changed, false);
		Arrays.fill(keyboard_lost, false);
	}

	public boolean focused() {
		return focused;
	}

	public boolean destroyed() {
		return destroyed;
	}

	// Private Methods
	private void setKey(int key, boolean state) {
		if (key == FK_UNKNOWN) return;
		keyboard_lost[key] = held(key) && !state && changed(key);
		keyboard_changed[key] = held(key) != state;
		keyboard_pressed[key] = state;
	}

	// KeyListener
	public void keyPressed(KeyEvent e) {
		if (verbose) System.out.println(e);
		setKey(translateNEWT2FK(e.getKeyCode(), e.getKeyChar()), true);
	}

	public void keyReleased(KeyEvent e) {
		if (verbose) System.out.println(e);
		setKey(translateNEWT2FK(e.getKeyCode(), e.getKeyChar()), false);
	}

	public void keyTyped(KeyEvent e) {
	}

	// WindowListener
	public void windowDestroyNotify(WindowEvent e) {
		if (verbose) System.out.println(e);
		destroyed = true;
	}

	public void windowGainedFocus(WindowEvent e) {
		if (verbose) System.out.println(e);
		clearKeys();
		focused = true;
	}

	public void windowLostFocus(WindowEvent e) {
		if (verbose) System.out.println(e);
		clearKeys();
		focused = false;
	}

	public void windowMoved(WindowEvent e) {
		if (verbose) System.out.println(e);
	}

	public void windowResized(WindowEvent e) {
		if (verbose) System.out.println(e);
	}

	public void windowDestroyed(WindowEvent e) {
		if (verbose) System.out.println(e);
	}

	public void windowRepaint(WindowUpdateEvent e) {
		if (verbose) System.out.println(e);
	}

	// Static
	public static int translateNEWT2FK(int newtCode, char newtChar) {
		switch (newtCode) {
			case 27:
				return FK_ESCAPE;
			case 37:
				return FK_LEFT;
			case 39:
				return FK_RIGHT;
			case 38:
				return FK_UP;
			case 40:
				return FK_DOWN;
			case 32:
				return FK_SPACE;
			case 65293:
				return FK_ENTER;
			case 96:
				return FK_TILDE;
			case 97:
			case 65:
				return FK_A;
			case 98:
			case 66:
				return FK_B;
			case 99:
			case 67:
				return FK_C;
			case 100:
			case 68:
				return FK_D;
			case 101:
			case 69:
				return FK_E;
			case 102:
			case 70:
				return FK_F;
			case 103:
			case 71:
				return FK_G;
			case 104:
			case 72:
				return FK_H;
			case 105:
			case 73:
				return FK_I;
			case 106:
			case 74:
				return FK_J;
			case 107:
			case 75:
				return FK_K;
			case 108:
			case 76:
				return FK_L;
			case 109:
			case 77:
				return FK_M;
			case 110:
			case 78:
				return FK_N;
			case 111:
			case 79:
				return FK_O;
			case 112:
			case 80:
				return FK_P;
			case 113:
			case 81:
				return FK_Q;
			case 114:
			case 82:
				return FK_R;
			case 115:
			case 83:
				return FK_S;
			case 116:
			case 84:
				return FK_T;
			case 117:
			case 85:
				return FK_U;
			case 118:
			case 86:
				return FK_V;
			case 119:
			case 87:
				return FK_W;
			case 120:
			case 88:
				return FK_X;
			case 121:
			case 89:
				return FK_Y;
			case 122:
			case 90:
				return FK_Z;
				/*
				case 112:
				return FK_F1;
				case 113:
				return FK_F2;
				case 114:
				return FK_F3;
				case 115:
				return FK_F4;
				case 116:
				return FK_F5;
				case 117:
				return FK_F6;
				case 118:
				return FK_F7;
				case 119:
				return FK_F8;
				case 120:
				return FK_F9;
				case 121:
				return FK_F10;
				case 122:
				return FK_F11;
				case 123:
				return FK_F12;
				*/
			case 65453:
				return FK_NUMPAD_SUBTRACT;
			case 65451:
				return FK_NUMPAD_ADD;
		}
		return FK_UNKNOWN;
	}
}
