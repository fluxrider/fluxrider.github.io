/*
 * Written by David Lareau on September 8, 2011.
 * 
 * A opengl setup for performance.
 * Current Implementation uses NEWT (but its super buggy in linux, so I disable edt, and workaround the inputs)
 */
package flux.opengl;

import javax.media.opengl.GL2;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLProfile;

import com.jogamp.newt.Display;
import com.jogamp.newt.NewtFactory;
import com.jogamp.newt.event.KeyEvent;
import com.jogamp.newt.opengl.GLWindow;

import flux.time.T;

public class OpenGLWindow implements GLEventListener {

	// Attributes
	public GLWindow window;
	protected PolledInput input;
	protected boolean isRunningMainLoop;
	private boolean verboseDefaults;

	// Construct
	public OpenGLWindow(boolean callInitSingleton, boolean setHeadlessProperty, boolean disableEDT, boolean verboseDefaults, boolean fsaa) {
		// Setup
		if (callInitSingleton) GLProfile.initSingleton(true);
		if (setHeadlessProperty) System.setProperty("java.awt.headless", "true");
		if (disableEDT) NewtFactory.setUseEDT(false);
		GLProfile profile = GLProfile.getDefault();
		GLCapabilities capabilities = new GLCapabilities(profile);
		if (fsaa) {
			System.out.println(capabilities);
			capabilities.setSampleBuffers(true);
			capabilities.setHardwareAccelerated(true);
			capabilities.setNumSamples(4);
			capabilities.setAlphaBits(8);
			System.out.println(capabilities);
		}
		this.window = GLWindow.create(capabilities);

		// Events
		window.addGLEventListener(this);
		this.input = new PolledInput();
		window.addKeyListener(input);
		window.addWindowListener(input);
	}

	// GLEventListener
	public void init(GLAutoDrawable drawable) {
		if (verboseDefaults) System.out.println("Default Init");
		GL2 gl = drawable.getGL().getGL2();
		gl.setSwapInterval(0); // disable vsync
	}

	public void reshape(GLAutoDrawable drawable, int x, int y, int w, int h) {
		if (verboseDefaults) System.out.println(String.format("Default Reshape %d,%d %dx%d", x, y, w, h));
	}

	public void dispose(GLAutoDrawable drawable) {
		if (verboseDefaults) System.out.println("Default Dispose");
	}

	public void display(GLAutoDrawable drawable) {
		if (verboseDefaults) System.out.println(String.format("Default Display %d", System.currentTimeMillis()));
	}

	// Methods
	public void tick() {
		if (verboseDefaults) System.out.println(String.format("Default Tick %d", System.currentTimeMillis()));
		if (input.held(KeyEvent.VK_ESCAPE)) isRunningMainLoop = false;
		input.polled();
	}

	public void mainLoop() {
		this.isRunningMainLoop = true;
		Display display = window.getScreen().getDisplay();
		do {
			display.dispatchMessages();
			tick();
			window.display();
			T.sleep(1);
		} while (isRunningMainLoop);
	}

	// Main
	public static void main(String[] args) {
		OpenGLWindow app = new OpenGLWindow(true, true, true, true, true);
		GLWindow window = app.window;

		// NOTE: setPosition(), setSize(), setUndecorated(), getScreen() all behave strangely depending on when I call them.
		// Hardcoded setBounds before setVisible(), and calling setUndecorated() after setVisible() seems to be the only viable solution.
		// Sadly this means no screen centering. 
		/*
		double coverage = .75;
		Screen screen = window.getScreen();
		int w = (int) (screen.getWidth() * coverage);
		int h = (int) (screen.getHeight() * coverage);
		int x = (screen.getWidth() - w) / 2;
		int y = (screen.getHeight() - h) / 2;
		window.setPosition(x, y);
		window.setSize(w, h);
		System.out.println(String.format("%d %d %d %d", x, y, w, h));
		*/
		window.setTitle("Example OpenGLWindow main()");
		window.setPosition(100, 100);
		window.setSize(800, 600);
		window.setVisible(true);
		window.setUndecorated(false);
		//window.setFullscreen(true);

		app.mainLoop();
		window.destroy();

		System.out.println("Over and out");

	}

}
