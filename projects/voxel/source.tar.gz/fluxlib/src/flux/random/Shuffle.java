/*
 * Written by David Lareau.
 * 
 * Collection of shuffling functions.
 */
package flux.random;

public class Shuffle {

	// Non bias shuffle (Fisher–Yates, Knuth) 
	public static final void shuffle(int t[]) {
		shuffle(t, 0, t.length);
	}

	public static final void shuffle(int t[], int offset, int length) {
		int n = length;
		for (int i = 0; i < n - 1; i++) {
			swap(t, offset + i, offset + R.uniform_exclusive_s32(i, n));
		}
	}

	// Group Cross Shuffle (this is a made up name)
	public static final void groupCrossShuffle(int t[]) {
		groupCrossShuffle(t, 0, t.length, 4, .25);
	}

	public static final void groupCrossShuffle(int t[], int offset, int length, int nGroups, double cross) {
		// The goal of this shuffle is to shuffle such that the values at the beginning cannot jump to the end in one shuffle and vice versa
		// I'm using this to reshuffle and avoid the last value now being the first, and the first value now being last
		// Motivation: shuffle images in a random slideshow, and I don't want the last image shown to be reshown soon, and I don't want the first image shown to now be the last such that I have to see 2n images before I can see it again.
		// I do this by independantly shuffling section of the array, and then shuffling small crossover bettween parts
		// when doing the cross over shuffle, I do every even pair, then odd pairs to avoid carrying a values across many groups in the case of cross > .5 
		// thus the name, groupCrossShuffle (shuffle groups, and allow some crossing)
		// the cross parameter represent a percentage overlap of two group (1 means both group will completly mix, 0 means there will be no mixing, .5 means the last half of a group will mix with the first half of the next group)
		if (cross < 0 || cross > 1) throw new IllegalArgumentException("cross should be a [0, 1] percentage, not " + cross);
		// Shuffle independantly each group
		int currentOffset = 0;
		int nextOffset = 0;
		for (int group = 0; group < nGroups; group++) {
			currentOffset = nextOffset;
			nextOffset = ((length * (group + 1)) / nGroups);
			shuffle(t, currentOffset, nextOffset - currentOffset);
		}
		// Shuffle Cross-over section bettwen groups
		// Even pairs
		nextOffset = 0;
		int nextNextOffset = (length / nGroups);
		for (int group = 0; group < nGroups - 1; group++) {
			currentOffset = nextOffset;
			nextOffset = nextNextOffset;
			nextNextOffset = ((length * (group + 2)) / nGroups);
			if (group % 2 == 0) {
				int n = nextNextOffset - currentOffset;
				int nCross = cross > 0 ? Math.max(2, (int) Math.round(n * cross)) : 0;
				if (nCross > 1) shuffle(t, currentOffset + (n - nCross) / 2, nCross);
			}
		}
		// Odd pairs
		nextOffset = 0;
		nextNextOffset = (length / nGroups);
		for (int group = 0; group < nGroups - 1; group++) {
			currentOffset = nextOffset;
			nextOffset = nextNextOffset;
			nextNextOffset = ((length * (group + 2)) / nGroups);
			if (group % 2 == 1) {
				int n = nextNextOffset - currentOffset;
				int nCross = cross > 0 ? Math.max(2, (int) Math.round(n * cross)) : 0;
				if (nCross > 1) shuffle(t, currentOffset + (n - nCross) / 2, nCross);
			}
		}
	}

	// Multi table sync shuffle
	public static <T> void syncShuffle(T[]... tables) {
		syncShuffle(null, tables[0].length, tables);
	}

	public static <T> void syncShuffle(int offsets[], int length, T[]... tables) {
		int n = length;
		for (int i = 0; i < n - 1; i++) {
			int j = R.uniform_exclusive_s32(i, n);
			for (int t = 0; t < tables.length; t++) {
				if (offsets != null) swap(tables[t], offsets[t] + i, offsets[t] + j);
				else swap(tables[t], i, j);
			}
		}
	}

	// Private Utilities
	private static final void swap(int t[], int i, int j) {
		int temp = t[i];
		t[i] = t[j];
		t[j] = temp;
	}

	private static final <T> void swap(T t[], int i, int j) {
		T temp = t[i];
		t[i] = t[j];
		t[j] = temp;
	}

	// Main
	/*
	//Test bias of shuffle
	public static void main(String[] args) {
		Map<String, Integer> count = new TreeMap<String, Integer>();
		int t[] = new int[] { 1, 2, 3 };
		// Iterate 
		int N = 10000000;
		System.out.println("Iterating " + N + " times");
		for (int i = 0; i < N; i++) {
			shuffle(t);
			String k = Arrays.toString(t);
			if (!count.containsKey(k)) count.put(k, 0);
			count.put(k, count.get(k) + 1);
			if (T.lastCheck(1000)) System.out.println("i: " + i + " (" + M.ratioP(i, N) + ")");
		}
		// Report
		int size = count.keySet().size();
		int pass = 0;
		for (String k : count.keySet()) {
			if (!M.kindaEquals(count.get(k) / (double) N, 1 / (double) size)) System.out.println(k + ": " + M.ratio(count.get(k), N));
			else pass++;
		}
		System.out.println("Pass: " + pass + " out of " + size);
		if(pass < size) System.out.println("Was looking for: " + M.ratio(1, size));
	}
	*/

	/*
	// Test group cross shuffle
	public static void main(String[] args) {
		
		int t[] = new int[] { 1, 2, 30, 40, 500, 600, 7000, 8000, 90000 };
		System.out.println(Arrays.toString(t));
		for (int i = 0; i < 10; i++) {
			groupCrossShuffle(t, 0, t.length, 4, .25);
			System.out.println(Arrays.toString(t));
		}
	}
	*/

}
