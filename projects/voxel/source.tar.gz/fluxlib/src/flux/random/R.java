/*
 * Written by David Lareau.
 * 
 * Collection of random functions that I find handy.
 */
package flux.random;

public class R {

	// Uniform Range
	public static final double uniform_exclusive_f64(double min, double max) {
		return min + (Math.random() * (max - min)); // [min, max[
	}

	public static final int uniform_inclusive_s32(int min, int max) {
		if (min > max) throw new IllegalArgumentException("k > l, " + min + " > " + max);
		return min + (int) (Math.random() * (max - min + 1)); // [min, max]
	}

	public static final int uniform_exclusive_s32(int min, int max) {
		return uniform_inclusive_s32(min, max - 1); // [min, max[
	}

	// Uniform Dice
	public static final int d(int face) {
		return uniform_inclusive_s32(1, face);
	}
	public static final int d4() { return d(4);	}
	public static final int d6() { return d(6);	}
	public static final int d8() { return d(8);	}
	public static final int d10() { return d(10);	}
	public static final int d12() { return d(12);	}
	public static final int d20() { return d(20);	}
	public static final int d100() { return d(100);	}

}
