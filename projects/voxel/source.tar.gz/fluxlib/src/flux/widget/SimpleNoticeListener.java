package flux.widget;

public interface SimpleNoticeListener {

	public void simpleNotice(Object source);

}
