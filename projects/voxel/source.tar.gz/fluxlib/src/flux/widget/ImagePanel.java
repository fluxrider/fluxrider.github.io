/*
 * Written by David Lareau on October 19, 2010.
 * 
 * Paints an image over a checkboard transparent mate bg. 
 * Allow zoom/pan image
 */
package flux.widget;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.swing.JPanel;

public class ImagePanel extends JPanel implements MouseListener, MouseMotionListener, MouseWheelListener, ComponentListener {

	// Attributes
	private BufferedImage image;

	private Color bgTone1 = new Color(102, 102, 102);
	private Color bgTone2 = new Color(153, 153, 153);
	private int bgSquarePixelSize = 8;

	private Color borderTone = new Color(255, 0, 255, 128);
	private int borderPixelSize = 5;

	private double zoom;
	private double panX, panY;
	private boolean _dirty;

	private List<PixelListener> pixelListeners = new LinkedList<PixelListener>();

	public boolean fitOnResize = true;

	// Construct
	public ImagePanel(BufferedImage image) {
		this.image = image;
		this.setPreferredSize(new Dimension(image.getWidth(), image.getHeight()));
		_dirty = false;
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.addMouseWheelListener(this);
		this.addComponentListener(this);
		resetZoomPan();
	}

	// Methods
	public void setImage(BufferedImage image) {
		this.image = image;
		dirty();
	}

	public BufferedImage getImage() {
		return image;
	}

	public void resetZoomPan() {
		zoom = 1;
		panX = 0;
		panY = 0;
		dirty();
	}

	public void fitZoomPan() {
		if (image == null) resetZoomPan();
		int W = getWidth();
		int H = getHeight();
		int w = image.getWidth();
		int h = image.getHeight();
		zoom = Math.min(W / (double) w, H / (double) h);
		panX = (W - (w * zoom)) / 2;
		panY = (H - (h * zoom)) / 2;
		dirty();
	}

	public synchronized void dirty() {
		boolean alreadyDirty = _dirty;
		_dirty = true;
		if (!alreadyDirty) repaint();
	}

	// Paint
	public synchronized void paint(Graphics g) {
		int W = getWidth();
		int H = getHeight();
		paintBG(g, W, H);
		paintImage(g, W, H);
		paintBorder(g, W, H);
		_dirty = false;
	}

	private void paintBG(Graphics g, int W, int H) {
		// gray tone checkboard pattern
		g.setColor(bgTone1);
		g.fillRect(0, 0, W, H);
		g.setColor(bgTone2);
		for (int y = 0; y < H; y += bgSquarePixelSize) {
			for (int x = ((y / bgSquarePixelSize) % 2 == 0 ? 0 : bgSquarePixelSize); x < W; x += 2 * bgSquarePixelSize) {
				g.fillRect(x, y, bgSquarePixelSize, bgSquarePixelSize);
			}
		}
	}

	protected void paintImage(Graphics g, int W, int H) {
		paintImage(g, 0, 0, image, true, 1);
	}

	protected void paintImage(Graphics _g, int x, int y, BufferedImage img, boolean scaledToSource, double scale) {
		if (scaledToSource && image == null) return;
		if (img == null) return;
		int imageW = scaledToSource ? image.getWidth() : img.getWidth();
		int imageH = scaledToSource ? image.getHeight() : img.getHeight();
		imageW *= scale;
		imageH *= scale;
		Graphics2D g = (Graphics2D) _g;
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, zoom >= 1 ? RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR : RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		g.drawImage(img, (int) Math.round(panX + x * zoom), (int) Math.round(panY + y * zoom), (int) (imageW * zoom), (int) (imageH * zoom), null);
	}

	private void paintBorder(Graphics g, int W, int H) {
		if (image == null) return;
		int imageW = image.getWidth();
		int imageH = image.getHeight();
		g.setColor(borderTone);
		int x = (int) Math.round(panX);
		int y = (int) Math.round(panY);
		int w = (int) (imageW * zoom);
		int h = (int) (imageH * zoom);
		for (int i = 1; i <= borderPixelSize; i++) {
			g.drawRect(x - i, y - i, w + 2 * i - 1, h + 2 * i - 1);
		}
	}

	// Conversion
	public int getLogicX(int x) {
		return (int) ((x - panX) / zoom);
	}

	public int getLogicY(int y) {
		return (int) ((y - panY) / zoom);
	}

	// MouseListener
	protected Point _mouse;
	protected Set<Integer> _buttons = new HashSet<Integer>(5);

	public void mouseClicked(MouseEvent e) {
		// Report to listeners
		if (image != null) {
			for (PixelListener listener : pixelListeners) {
				int imageX = (int) ((e.getX() - panX) / zoom);
				int imageY = (int) ((e.getY() - panY) / zoom);
				if (isWithinImage(imageX, imageY)) {
					int rgb = image.getRGB(imageX, imageY);
					listener.pixelEvent(imageX, imageY, rgb);
				}
			}
		}
		// Reset zoom/pan with middle click
		if (e.getButton() == MouseEvent.BUTTON2) {
			if (e.getClickCount() == 1) fitZoomPan();
			if (e.getClickCount() == 2) resetZoomPan();
		}
		_mouse = e.getPoint();
	}

	public void mouseEntered(MouseEvent e) {
		_mouse = e.getPoint();
	}

	public void mouseExited(MouseEvent e) {
		_mouse = e.getPoint();
	}

	public void mousePressed(MouseEvent e) {
		_mouse = e.getPoint();
		_buttons.add(e.getButton());
	}

	public void mouseReleased(MouseEvent e) {
		_mouse = e.getPoint();
		_buttons.remove(e.getButton());
	}

	// MouseMotionListener
	public void mouseDragged(MouseEvent e) {
		int dx = _mouse.x - e.getX();
		int dy = _mouse.y - e.getY();
		panX -= dx;
		panY -= dy;
		dirty();
		_mouse = e.getPoint();
	}

	public void mouseMoved(MouseEvent e) {
		_mouse = e.getPoint();
	}

	// MouseWheelListener
	public void mouseWheelMoved(MouseWheelEvent e) {
		if (image != null) {
			int imageW = image.getWidth();
			int imageH = image.getHeight();

			double _zoom = zoom; // store zoom for panning computation
			boolean magnify = e.getWheelRotation() < 0;
			int amount = Math.abs(e.getWheelRotation());
			for (int i = 0; i < amount; i++)
				if (magnify) zoom /= .75;
				else zoom *= .75;
			double limit = Math.min(1, Math.max(50.0 / imageW, 50.0 / imageH)); // cannot zoom out so far that image is lower than 50 pixel in any dimension
			zoom = Math.max(limit, zoom);

			// modify pan so that the mouse pointer still hovers the same relative image pixel
			int x = e.getX();
			int y = e.getY();
			double hoveredX = ((x - panX) / _zoom);
			double hoveredY = ((y - panY) / _zoom);
			// if out of bound of the image, it can be confusing, so I prefer to pretend we zoom the center
			if (!isWithinImage(hoveredX, hoveredY)) {
				x = (int) (panX + imageW * _zoom / 2);
				y = (int) (panY + imageH * _zoom / 2);
				hoveredX = ((x - panX) / _zoom);
				hoveredY = ((y - panY) / _zoom);
			}
			panX = -(hoveredX * zoom - x);
			panY = -(hoveredY * zoom - y);
		}

		dirty();
		_mouse = e.getPoint();
	}

	// ComponentListener
	public void componentHidden(ComponentEvent e) {
	}

	public void componentMoved(ComponentEvent e) {
	}

	public void componentResized(ComponentEvent e) {
		if(fitOnResize) fitZoomPan();
	}

	public void componentShown(ComponentEvent e) {
	}

	// Listeners
	public void addPixelListener(PixelListener listener) {
		pixelListeners.add(listener);
	}

	public void removePixelListener(PixelListener listener) {
		pixelListeners.remove(listener);
	}

	// Util
	public boolean isWithinImage(double x, double y) {
		if (image == null) return false;
		if (x < 0 || y < 0) return false;
		if (x >= image.getWidth()) return false;
		if (y >= image.getHeight()) return false;
		return true;
	}

}
