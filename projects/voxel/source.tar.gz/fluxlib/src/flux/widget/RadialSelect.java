/*
 * Written by David Lareau on September 3, 2011.
 * 
 * A widget to select an angle on a circle. Also allows selecting an amplitude.
 * Basicaly, it returns a x value from [-1,1], and another for y.
 * You can constraint the values to respect length(x,y) == 1 
 */
package flux.widget;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;

import javax.swing.JPanel;

import flux.geo2D.Point2D;
import flux.geo3D.G;

public class RadialSelect extends JPanel implements MouseListener, MouseMotionListener {

	// Attributes
	private Point2D p;
	private double minLength;
	private double maxLength;

	// Construct
	public RadialSelect(double x, double y, double minLength, double maxLength) {
		//this.setPreferredSize(new Dimension(50, 50));
		this.setMinimumSize(new Dimension(50, 50));
		addMouseListener(this);
		addMouseMotionListener(this);
		p = new Point2D();
		this.minLength = minLength;
		this.maxLength = maxLength;
		set(x, y);
	}

	public RadialSelect() {
		this(0, 0, 0, 1);
	}

	public RadialSelect(double x, double y) {
		this(x, y, 0, 1);
	}

	// Methods
	public void set(double x, double y) {
		p.x = x;
		p.y = y;
		double length = p.length();
		if (length > maxLength) {
			p.normalizeInPlace();
			G.mul(p, maxLength, p);
		}
		if (length < minLength) {
			p.normalizeInPlace();
			G.mul(p, minLength, p);
		}
		//System.out.println(String.format("%s: %.2f", p, Math.toDegrees(p.atan2())));
	}

	public void set(Point2D p_) {
		set(p_.x, p_.y);
	}

	public Point2D get() {
		return p;
	}

	// Paint
	public void paint(Graphics g) {
		int W = getWidth();
		int H = getHeight();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, W, H);
		g.setColor(Color.BLACK);
		int x = (int) (W / 2 + p.x * W / 2);
		int y = (int) (H / 2 + p.y * H / 2);
		int w = 3;
		int h = 3;
		g.drawLine(W / 2, H / 2, x, y);
		g.fillRect(x - w / 2, y - h / 2, w, h);
	}

	// MouseListener
	public void mouseClicked(MouseEvent e) {
		mouse(e);
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
		mouse(e);
	}

	public void mouseReleased(MouseEvent e) {
		mouse(e);
	}

	public void mouseDragged(MouseEvent e) {
		mouse(e);
	}

	public void mouseMoved(MouseEvent e) {
		//if (e.getButton() != MouseEvent.NOBUTTON) mouse(e);
	}

	private void mouse(MouseEvent e) {
		int W = getWidth();
		int H = getHeight();
		double x = e.getX() * 2 / (double) W - 1;
		double y = e.getY() * 2 / (double) H - 1;
		set(x, y);
		repaint();
	}

	// Listener

}
