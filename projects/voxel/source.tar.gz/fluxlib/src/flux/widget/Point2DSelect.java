/*
 * Written by David Lareau on February 12, 2012.
 * 
 * A widget to select the coordinated of a point in 2D space.
 * The values are bounded, but just graphically.
 */
package flux.widget;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;

import flux.geo2D.Point2D;
import flux.math.M;

public class Point2DSelect extends JPanel implements MouseListener, MouseMotionListener {

	// Attributes
	private Point2D p;
	private double minX;
	private double maxX;
	private double minY;
	private double maxY;

	public List<SimpleNoticeListener> listeners = new LinkedList<SimpleNoticeListener>();

	// Construct
	public Point2DSelect(double x, double y, double minX, double maxX, double minY, double maxY) {
		this.setPreferredSize(new Dimension(50, 50));
		this.setMinimumSize(new Dimension(50, 50));
		addMouseListener(this);
		addMouseMotionListener(this);
		p = new Point2D();
		this.minX = minX;
		this.maxX = maxX;
		this.minY = minY;
		this.maxY = maxY;
		set(x, y);
	}

	// Methods
	public void set(double x, double y) {
		p.x = x;
		p.y = y;
		for (SimpleNoticeListener listener : listeners) {
			listener.simpleNotice(this);
		}
	}

	public void set(Point2D p_) {
		set(p_.x, p_.y);
	}

	public Point2D get() {
		return p;
	}

	// Paint
	public void paint(Graphics g) {
		int W = getWidth();
		int H = getHeight();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, W, H);

		boolean busted = p.x < minX || p.x > maxX || p.y < minY || p.y > maxY;
		g.setColor(busted ? Color.RED : Color.BLACK);
		int x = (int) ((p.x - minX) / (maxX - minX) * W);
		int y = (int) ((p.y - minY) / (maxY - minY) * H);
		x = (int) M.boundCrop(x, 0, W - 1);
		y = (int) M.boundCrop(y, 0, H - 1);
		g.fillRect(x - 1, y - 1, 3, 3);
	}

	// MouseListener
	public void mouseClicked(MouseEvent e) {
		mouse(e);
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
		mouse(e);
	}

	public void mouseReleased(MouseEvent e) {
		mouse(e);
	}

	public void mouseDragged(MouseEvent e) {
		mouse(e);
	}

	public void mouseMoved(MouseEvent e) {
		//if (e.getButton() != MouseEvent.NOBUTTON) mouse(e);
	}

	private void mouse(MouseEvent e) {
		int W = getWidth();
		int H = getHeight();
		double x = e.getX() / (double) W * (maxX - minX) + minX;
		double y = e.getY() / (double) H * (maxY - minY) + minY;
		x = M.boundCrop(x, minX, maxX);
		y = M.boundCrop(y, minY, maxY);
		set(x, y);
		repaint();
	}

	// Main
	public static void main(String[] args) {
		JFrame frame = new JFrame("Point2DSelect");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 800, 600);
		frame.setContentPane(new Point2DSelect(0, 0, 1, 10, 1, 10));
		frame.setVisible(true);
	}

}
