/*
 * Written by David Lareau on October 20, 2010.
 *
 * An interface to listen to pixel events. I know it means nothing. I'm using this to report scaled position of mouse clicks on ImagePanel. 
 */
package flux.widget;

public interface PixelListener {

	public void pixelEvent(int x, int y, int rgb);

}
