// Written by David Lareau on August 28, 2011
// Loosely inspired from code written by Fan Zhang summer 2011 that used regexp for filtering and image icon for loading (I use ImageIO for both)
package flux.widget;

import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.WeakHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileView;

import flux.ui.ImageFileFilter;
import flux.ui.UI;

public class ThumbnailFileChooser extends JFileChooser {

	// Attributes
	private static ImageFileFilter filter = new ImageFileFilter(false);
	private Map<File, Icon> cache = new WeakHashMap<File, Icon>();
	private ExecutorService executor = Executors.newCachedThreadPool();

	// Construct
	public ThumbnailFileChooser(final int iconWidth, final int iconHeight, final Object minifyInterpolation) {
		// Give a special file view that will load image previews
		setFileView(new FileView() {
			public Icon getIcon(final File file) {
				if (!filter.accept(file)) return null;

				// Try cache
				Icon cachedIcon = cache.get(file);
				if (cachedIcon != null) return cachedIcon;

				// Create a empty image icon that will be updated in another thread
				final ImageIcon icon = new ImageIcon(new BufferedImage(iconWidth, iconHeight, BufferedImage.TYPE_INT_ARGB));
				cache.put(file, icon);

				// start image loading thread for the icon
				executor.submit(new Runnable() {
					public void run() {
						try {
							BufferedImage image = ImageIO.read(file);
							UI.drawScaledImage(icon.getImage().getGraphics(), image, 0, 0, iconWidth, iconHeight, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR, minifyInterpolation);
						} catch (IOException e) {
							e.printStackTrace();
						}
						SwingUtilities.invokeLater(new Runnable() {
							public void run() {
								repaint();
							}
						});
					}
				});

				return icon;
			}
		});

	}
}
