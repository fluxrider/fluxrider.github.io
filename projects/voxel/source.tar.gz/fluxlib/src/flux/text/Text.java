/*
 * Written by David Lareau.
 * 
 * Collection of text functions that I find handy.
 */
package flux.text;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Text {

	public static String resolveXMLEntities(String s) {
		StringBuilder out = new StringBuilder();
		// &#xB0;
		Pattern pattern = Pattern.compile("(.*)&#x(..);(.*)");
		Matcher m = pattern.matcher(s);
		if (m.matches()) {
			out.append("Yup: ");
			out.append(m.group(1));
			out.append((char) Integer.parseInt(m.group(2), 16));
			out.append(m.group(3));
		} else {
			out.append("Nope: ");
			out.append(s);
		}
		return out.toString();
	}

	public static String toBinary(int _x) {
		long x = _x;
		StringBuilder s = new StringBuilder();
		for (long i = 1; i < 2147483648l; i *= 2)
			s.insert(0, (((x & i) == 0) ? "0" : "1"));
		return s.toString();
	}

	// Test
	public static void main(String[] args) {
		System.out.println(resolveXMLEntities("Cloudy, 13.4&#xB0;C"));
	}
}
