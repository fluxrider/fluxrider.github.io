/* 
 * Written by David Lareau on June 4, 2009
 *
 * UI helper function
 */
package flux.ui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.ListSelectionModel;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

import flux.util.K;
import flux.widget.ThumbnailFileChooser;

public class UI {

	public static int thumbnailFileChooserIconWidth = 32;
	public static int thumbnailFileChooserIconHeight = 32;
	public static Object thumbnailFileChooserMinifyInterpolation = RenderingHints.VALUE_INTERPOLATION_BICUBIC;

	// GUI option list
	public static int selectOption(Component parent, String title, Object[] options, int n, int defaultIndex) {
		Object option = JOptionPane.showInputDialog(parent, title, title, JOptionPane.PLAIN_MESSAGE, null, options, options[defaultIndex]);
		if (option != null) {
			for (int i = 0; i < n; i++) {
				if (option.equals(options[i])) return i;
			}
		}
		return defaultIndex;
	}

	// Test cmd arg against option list
	public static int selectOption(Object[] options, int n, int defaultIndex, String arg) {
		for (int i = 0; i < n; i++) {
			if (arg.equals(options[i])) return i;
		}
		return defaultIndex;
	}

	public static String listString(Object[] options) {
		StringBuilder s = new StringBuilder();
		s.append('[');
		for (int i = 0; i < options.length; i++) {
			s.append(options[i]);
			if (i != options.length - 1) s.append(',');
		}
		s.append(']');
		return s.toString();
	}

	public static String listString(Object[][] options) {
		StringBuilder s = new StringBuilder();
		s.append('[');
		for (int i = 0; i < options.length; i++) {
			s.append(listString(options[i]));
			if (i != options.length - 1) s.append(',');
		}
		s.append(']');
		return s.toString();
	}

	public static int[] selectOptions(Component parent, String title, Object[] options, int n) {
		final JDialog dialog = new JDialog();
		JList list = new JList(options);
		list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		JButton ok = new JButton("Ok");
		ok.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dialog.setVisible(false);
			}
		});
		JPanel panel = new JPanel(new BorderLayout());
		panel.setPreferredSize(new Dimension(200, 200));
		panel.add(list, BorderLayout.CENTER);
		panel.add(ok, BorderLayout.SOUTH);
		dialog.setContentPane(panel);
		dialog.setModal(true);
		dialog.setBounds(parent.getX(), parent.getY(), 200, 200);
		dialog.setVisible(true);
		int[] indices = list.getSelectedIndices();
		dialog.dispose();
		return indices;
	}

	public static File selectFile(Component parent, FileFilter filter, boolean imageThumbnail, File directory) {
		// Setup FileChooser
		JFileChooser chooser = imageThumbnail ? new ThumbnailFileChooser(thumbnailFileChooserIconWidth, thumbnailFileChooserIconHeight, thumbnailFileChooserMinifyInterpolation) : new JFileChooser();
		chooser.setMultiSelectionEnabled(false);
		if (filter != null) chooser.addChoosableFileFilter(filter);
		if (directory != null) chooser.setCurrentDirectory(directory);

		// Get File
		if (chooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) {
			return chooser.getSelectedFile();
		}
		return null;
	}

	public static File selectFile(Component parent, FileFilter filter, boolean imageThumbnail, K config, String directoryKey) {
		// Setup FileChooser
		JFileChooser chooser = imageThumbnail ? new ThumbnailFileChooser(thumbnailFileChooserIconWidth, thumbnailFileChooserIconHeight, thumbnailFileChooserMinifyInterpolation) : new JFileChooser();
		chooser.setMultiSelectionEnabled(false);
		if (filter != null) chooser.addChoosableFileFilter(filter);
		chooser.setCurrentDirectory(new File(config.get(directoryKey)));

		// Get File
		if (chooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) {
			config.set(directoryKey, chooser.getCurrentDirectory().getAbsolutePath()); // Update config path
			return chooser.getSelectedFile();
		}
		return null;
	}

	public static void reportError(Component parent, String message, boolean stdout, boolean gui) {
		if (gui) JOptionPane.showMessageDialog(parent, message);
		if (stdout) System.out.println(message);
	}

	public static void reportError(Component parent, Exception e, boolean stdout, boolean gui) {
		if (gui) JOptionPane.showMessageDialog(parent, e.toString());
		if (stdout) e.printStackTrace();
	}

	public static JFrame usualFrameInit(JFrame frame, JPanel content, boolean debugLayout) {
		if (frame == null) frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		if (content != null) frame.setContentPane(content);
		if (debugLayout) setCenteredBounds(frame, .65, -.15);
		else setCenteredBounds(frame, .85, 0);
		frame.setVisible(true);
		return frame;
	}

	public static void setCenteredBounds(Window frame, double percent, double yoffsetPercent) {
		// set default window size to be percent of default screen, with optinal offset in y dimension
		Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
		int w = (int) (screen.getWidth() * percent);
		int h = (int) (screen.getHeight() * percent);
		int x = (int) ((screen.getWidth() - w) / 2);
		int y = (int) ((screen.getHeight() - h) / 2);
		int yoffsetH = (int) (screen.getHeight() * yoffsetPercent);
		frame.setBounds(x, y + yoffsetH, w, h);
	}

	public static BufferedImage loadImage(String path, boolean _throw) {
		try {
			return ImageIO.read(new File(path));
		} catch (IOException e) {
			if (_throw) throw new RuntimeException(path, e);
			return null;
		}
	}

	public static void drawScaledImage(Graphics _g, Image image, int x, int y, int W, int H) {
		drawScaledImage(_g, image, x, y, W, H, RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
	}

	public static void drawScaledImage(Graphics _g, Image image, int x, int y, int W, int H, Object magnifyInterpolation, Object minifyInterpolation) {
		int w = image.getWidth(null);
		int h = image.getHeight(null);
		double zoom = Math.min(W / (double) w, H / (double) h);
		double panX = (W - (w * zoom)) / 2;
		double panY = (H - (h * zoom)) / 2;
		Graphics2D g = (Graphics2D) _g;
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, zoom >= 1 ? magnifyInterpolation : minifyInterpolation);
		g.drawImage(image, x + (int) Math.round(panX), y + (int) Math.round(panY), (int) Math.round(w * zoom), (int) Math.round(h * zoom), null);
	}

	public static JSlider createHSlider(int min, int max, int init, ChangeListener listener) {
		JSlider slider = new JSlider(JSlider.HORIZONTAL, min, max, init);
		int range = max - min + 1;
		slider.setMajorTickSpacing(range / 5);
		slider.setMinorTickSpacing(range / 20);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		if (listener != null) slider.addChangeListener(listener);
		return slider;
	}
}
