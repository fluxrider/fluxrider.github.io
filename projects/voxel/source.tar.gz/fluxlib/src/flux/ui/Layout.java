/* 
 * Written by David Lareau on August 27, 2009
 * 
 * This class helps creating layouts (by hiding temporary layout managers)
 */
package flux.ui;

import java.awt.Component;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JSeparator;

public class Layout {

	public static Box box(int axis, Component... args) {
		Box box = new Box(axis);
		box.add(Box.createGlue());
		for (Component c : args) {
			box.add(c);
			box.add(Box.createGlue());
		}
		return box;
	}

	public static Box box(Component loner) {
		Box box = new Box(BoxLayout.X_AXIS);
		box.add(Box.createGlue());
		box.add(loner);
		box.add(Box.createGlue());
		return box;
	}

	public static void addSeparator(Box box, int orientation) {
		box.add(Box.createGlue());
		box.add(new JSeparator(orientation));
		box.add(Box.createGlue());
	}

}
