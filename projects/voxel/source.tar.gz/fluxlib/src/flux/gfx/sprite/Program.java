/*
 * Written by David Lareau on August 1, 2011. TODO not completed, not sure how is current state
 *
 * A Program for a Sprite.
 * 
 * Supported instruction:
 *  TODO res and frame instruction should be in sprite code not program code
 *  res path id // assign an id to a filepath (to avoid redundant paths which may be very long)
 *  frame resId x y w h // a portion of a res (crop area) (to avoid having to respecify cropping region all the time)
 *  img frameId x y // draw the offseted frame
 *  anchor x y // set anchor point
 *  clear // remove all stacked img
 *  callback message // 
 *  wait tick [clear] // wait for given number of ticks, optionally clear afterwards
 *  loop [n] [clear] // loop optionally for a given number of time (0 is infinite, default) and optionally clear before looping
 *   
 * For flexibility/maintenance reasons, the code is written in string, and is parsed/interpreted on the fly.
 */
package flux.gfx.sprite;

import java.awt.Graphics;
import java.awt.Point;
import java.util.List;

public class Program {

	// Attributes
	private List<String[]> splitted_code;
	private Point anchor;
	private String callback;

	private int loop; // 0 infinite, negative no looping, else number of repeats
	public static final int LOOP_NONE = -1;
	public static final int LOOP_INFINITE = 0;
	private long length;
	private long t;

	// Construct
	public Program() {
		init();
	}

	private void init() {
		// scan for total wait time
		length = 0;
		for (String instruction[] : splitted_code) {
			if (instruction[0].equals("wait")) {
				length += Long.parseLong(instruction[1]);
			}
		}
		// get loop value if any
		if (!splitted_code.isEmpty()) {
			String instruction[] = splitted_code.get(splitted_code.size() - 1);
			if (instruction[0].equals("loop")) {
				if (instruction.length == 1) loop = LOOP_INFINITE;
				else loop = Integer.parseInt(instruction[1]);
			} else {
				loop = LOOP_NONE;
			}
		}
	}

	// Methods
	public void tick(long ticks) {
		if (isDone()) return;
		t += ticks;
		// execute instructions

	}

	public void draw(Graphics g) {
	}

	public Point getAnchor() {
		return new Point(anchor);
	}

	public String getCallback() {
		return callback;
	}

	// Info
	public boolean isInfiniteLooping() {
		return loop == LOOP_INFINITE;
	}

	public int getLoopValue() {
		return loop;
	}

	public boolean isDone() {
		if (isInfiniteLooping()) return false;
		return t < getTotalLength();
	}

	public long getSingleLength() {
		return length;
	}

	public double getTotalLength() {
		if (isInfiniteLooping()) return Double.POSITIVE_INFINITY;
		if (loop == LOOP_NONE) return length;
		return length * loop;
	}

	public long getTick() {
		if (isInfiniteLooping()) return t;
		return Math.min(t, (long) getTotalLength());
	}

}
