/*
 * Written by David Lareau on August 27, 2011.
 * 
 * A grid of voxels.
 * 
 * Note: this is a voxel model for generic use. For a voxel used with opengl, see the flux.opengl.voxel package.
 */
package flux.gfx.voxel;

import java.awt.Color;
import java.awt.image.BufferedImage;

import flux.util.C;

public class VoxelModel {

	// Attributes
	private int grid[][][];
	private int W, H, D; // dimensions of grid: width, height and depth

	// Construct
	public VoxelModel(int width, int height, int depth) {
		this.W = width;
		this.H = height;
		this.D = depth;
		this.grid = new int[W][H][D];
	}

	// Methods
	public int get(int x, int y, int z) {
		if (x < 0 || y < 0 || z < 0 || x >= W || y >= H || z >= D) return (Color.MAGENTA.getRGB() & 0x00FFFFFF); // transparent pink
		return grid[x][y][z];
	}

	public boolean has(int x, int y, int z) {
		return C.isOpaque(get(x, y, z));
	}

	public void set(int x, int y, int z, int value) {
		grid[x][y][z] = value;
	}

	public int getWidth() {
		return W;
	}

	public int getHeight() {
		return H;
	}

	public int getDepth() {
		return D;
	}

	// Static Load
	public static VoxelModel read(BufferedImage image, int cellRows, int cellColumns) {
		int iw = image.getWidth();
		int ih = image.getHeight();

		// init grid dimensions
		if (iw % cellColumns != 0) throw new RuntimeException("Image not dividable in specified number of columns: " + iw + " % " + cellColumns + " != 0, its " + (iw % cellColumns));
		if (ih % cellRows != 0) throw new RuntimeException("Image not dividable in specified number of rows: " + ih + " % " + cellRows + " != 0, its " + (ih % cellRows));
		int W = iw / cellColumns;
		int H = ih / cellRows;
		int D = cellRows * cellColumns;
		VoxelModel model = new VoxelModel(W, H, D);

		// for each cell (z-slice) in the image, create enter the values in the grid
		int z = 0;
		for (int r = 0; r < cellRows; r++) {
			int yoffset = H * r;
			for (int c = 0; c < cellColumns; c++) {
				int xoffset = W * c;
				for (int y = 0; y < H; y++) {
					for (int x = 0; x < W; x++) {
						model.set(x, H - y - 1, z, image.getRGB(xoffset + x, yoffset + y));
					}
				}
				z++;
			}
		}

		return model;
	}
}
