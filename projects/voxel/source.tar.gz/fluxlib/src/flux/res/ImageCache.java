/*
 * Written by David Lareau on August 1, 2011.
 * 
 * Manages images.
 * Id are full path to image file.
 */
package flux.res;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import javax.imageio.ImageIO;

public class ImageCache implements ResourceManager<BufferedImage> {

	// Attributes
	private Map<String, BufferedImage> cache;
	private boolean failFast;

	// Construct
	public ImageCache(boolean failFast) {
		this.cache = new TreeMap<String, BufferedImage>();
		this.failFast = failFast;
	}

	// Methods
	private BufferedImage load(String path) {
		try {
			return ImageIO.read(new File(path));
		} catch (IOException e) {
			if (failFast) throw new RuntimeException(e);
			return null;
		}
	}

	// ResourceManager<BufferedImage>
	public BufferedImage getResource(String id) {
		BufferedImage image = cache.get(id);
		if (image == null) {
			image = load(id);
			if (image != null) cache.put(id, image);
		}
		if (image == null && failFast) throw new RuntimeException("Could not get resource " + id);
		return image;
	}

}
