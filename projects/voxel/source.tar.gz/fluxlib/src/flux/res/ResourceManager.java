/*
 * Written by David Lareau on August 1, 2011.
 * 
 * Manages some resource.
 * This is to abstract loading and caching.
 */
package flux.res;

public interface ResourceManager<T> {

	public T getResource(String id);
	
}
