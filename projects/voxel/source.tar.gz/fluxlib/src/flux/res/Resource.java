/*
 * Written by David Lareau on March 22, 2010.
 * 
 * Attempts to solve the issue between loading files from the file system or files from within a jar. (as in all my files are now in a jar when I do an applet or javawebstart)
 */
package flux.res;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

public class Resource {

	public static InputStream open(String filename) {
		InputStream in = null;

		// Attempt at Filesystem
		try {
			in = new FileInputStream(filename);
		} catch (IOException e) {
		}
		if (in != null) {
			System.out.println("Found " + filename + " using the filesystem");
			return in;
		}

		// Attempt at Jar
		in = Resource.class.getResourceAsStream(filename);
		if (in != null) {
			System.out.println("Found " + filename + " using the jar relative path");
			return in;
		}

		// Attempt at Jar again
		in = Resource.class.getResourceAsStream('/' + filename);
		if (in != null) {
			System.out.println("Found " + filename + " using jar absolute path");
			return in;
		}

		throw new RuntimeException("Could not find file " + filename);
	}

}
