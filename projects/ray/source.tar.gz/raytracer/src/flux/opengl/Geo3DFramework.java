package flux.opengl;

/*
 * A empty scene ready to draw geo3D primitives with rotate input (this is meant for quick debuging)
 */
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.media.opengl.GL;
import javax.media.opengl.GL2;
import javax.media.opengl.GL3;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLCapabilities;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.GLProfile;
import javax.media.opengl.awt.GLJPanel;
import javax.media.opengl.glu.GLU;
import javax.swing.JFrame;

import flux.geo3D.Box;
import flux.geo3D.G;
import flux.geo3D.Line3D;
import flux.geo3D.Plane3D;
import flux.geo3D.Point3D;
import flux.geo3D.Quad;
import flux.geo3D.Sphere;
import flux.geo3D.Triangle;
import flux.mem.V;
import flux.ui.UI;
import flux.util.C;
import flux.util.FPS;

public class Geo3DFramework implements GLEventListener, KeyListener {

	// Attributes
	private GLJPanel panel;
	protected double rotx, roty;
	protected double scale;
	protected boolean showAxis;

	protected FPS fps;

	public Geo3DFramework(GLJPanel panel, boolean showAxis) {
		this.panel = panel;
		panel.addGLEventListener(this);
		panel.addKeyListener(this);
		this.showAxis = showAxis;
		this.scale = 1;
		fps = new FPS(1000, 2);
	}

	// GLEventListener
	public void init(GLAutoDrawable glautodrawable) {
		GL2 gl = glautodrawable.getGL().getGL2();

		// Smooth Points and Lines
		gl.glEnable(GL2.GL_BLEND);
		gl.glBlendFunc(GL2.GL_SRC_ALPHA, GL2.GL_ONE_MINUS_SRC_ALPHA);
		gl.glEnable(GL2.GL_POINT_SMOOTH);
		gl.glHint(GL2.GL_POINT_SMOOTH_HINT, GL2.GL_NICEST);
		gl.glEnable(GL2.GL_LINE_SMOOTH);
		gl.glHint(GL2.GL_LINE_SMOOTH_HINT, GL2.GL_NICEST);

		// Depth
		gl.glClearDepth(1.0f);
		gl.glEnable(GL2.GL_DEPTH_TEST);
		gl.glDepthFunc(GL2.GL_LEQUAL);
		// almost completly transparent pixel will not update the z-buffer
		gl.glAlphaFunc(GL2.GL_GREATER, 0.1f);
		gl.glEnable(GL2.GL_ALPHA_TEST);

		// Culling
		gl.glFrontFace(GL2.GL_CCW);
		gl.glEnable(GL2.GL_CULL_FACE);
		gl.glCullFace(GL2.GL_BACK);

		// Lighting (must now specify normals)
		gl.glEnable(GL2.GL_LIGHTING);
		gl.glEnable(GL2.GL_COLOR_MATERIAL);
		gl.glShadeModel(GL2.GL_SMOOTH);
		gl.glColorMaterial(GL2.GL_FRONT_AND_BACK, GL2.GL_AMBIENT_AND_DIFFUSE);
		gl.glEnable(GL2.GL_LIGHT0);
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_AMBIENT, new float[] { .5f, .5f, .5f, 1 }, 0);
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_DIFFUSE, new float[] { 1, 1, 1, 1 }, 0);
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_SPECULAR, new float[] { 0, 0, 0, 1 }, 0);
		//gl.glLightModelfv(GL2.GL_LIGHT_MODEL_AMBIENT, new float[] { 0.0f, 0.0f, 0.0f, 1.0f }, 0);
		gl.glMaterialfv(GL2.GL_FRONT_AND_BACK, GL2.GL_EMISSION, new float[] { 0.0f, 0.0f, 0.0f, 1.0f }, 0);
		gl.glMaterialfv(GL2.GL_FRONT_AND_BACK, GL2.GL_SPECULAR, new float[] { 0.0f, 0.0f, 0.0f, 1.0f }, 0);
	}

	public void dispose(GLAutoDrawable glautodrawable) {
	}

	public void reshape(GLAutoDrawable glautodrawable, int x, int y, int width, int height) {
		GL2 gl = glautodrawable.getGL().getGL2();
		gl.glMatrixMode(GL2.GL_PROJECTION);
		gl.glLoadIdentity();
		GLU glu = new GLU();
		glu.gluPerspective(60.0f, width / (double) height, 0.1, 1000.0);
		glu.gluLookAt(.5, .5, 2, 0, 0, 0, 0, 1, 0);
		gl.glMatrixMode(GL2.GL_MODELVIEW);
		gl.glLoadIdentity();
		gl.glViewport(0, 0, width, height);
	}

	public synchronized void display(GLAutoDrawable glautodrawable) {
		fps.frame();
		GL2 gl = glautodrawable.getGL().getGL2();
		gl.glClear(GL3.GL_COLOR_BUFFER_BIT | GL3.GL_DEPTH_BUFFER_BIT);
		gl.glLoadIdentity();

		// Rotate according to input
		gl.glScaled(scale, scale, scale);
		gl.glRotated(rotx, 1, 0, 0);
		gl.glRotated(roty, 0, 1, 0);

		// Light
		gl.glLightfv(GL2.GL_LIGHT0, GL2.GL_POSITION, new float[] { .7f, .7f, .7f, 1.0f }, 0);
		gl.glLightf(GL2.GL_LIGHT0, GL2.GL_ATTENUATION_EXT, GL2.GL_LINEAR_ATTENUATION);
		//point(gl, .7, .7, .7, 0xffff00, 20); // light indicator

		if (showAxis) {
			// Origin white point
			point(gl, 0, 0, 0, 0xFFFFFF, 5);

			// Unit axis lines
			line(gl, 0, 0, 0, 1, 0, 0, 0xFF0000, 0x000000, 3);
			line(gl, 0, 0, 0, 0, 1, 0, 0x00FF00, 0x000000, 3);
			line(gl, 0, 0, 0, 0, 0, 1, 0x0000FF, 0x000000, 3);
		}

		render(gl);
	}

	protected void render(GL2 gl) {
		// overwrite this method
	}

	// KeyListener
	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
			case KeyEvent.VK_LEFT:
				roty -= 5;
				break;
			case KeyEvent.VK_RIGHT:
				roty += 5;
				break;
			case KeyEvent.VK_UP:
				rotx -= 5;
				break;
			case KeyEvent.VK_DOWN:
				rotx += 5;
				break;
			case KeyEvent.VK_R:
				rotx = roty = 0;
				scale = 1;
				break;
			case KeyEvent.VK_ADD:
				scale *= 2;
				break;
			case KeyEvent.VK_SUBTRACT:
				scale /= 2;
				break;
			case KeyEvent.VK_ESCAPE:
				//frame.setVisible(false);
				System.exit(0);
				break;
		}
		repaint();
	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {
	}

	// Methods
	public void repaint() {
		panel.display();
	}

	// Util
	protected void point(GL2 gl, double x, double y, double z, int rgb, double size) {
		gl.glPointSize((float) size);
		gl.glBegin(GL.GL_POINTS);
		gl.glColor3d(C.r1(rgb), C.g1(rgb), C.b1(rgb));
		gl.glVertex3d(x, y, z);
		gl.glEnd();
	}

	protected void line(GL2 gl, double px, double py, double pz, double qx, double qy, double qz, int prgb, int qrgb, double size) {
		gl.glLineWidth((float) size);
		gl.glBegin(GL.GL_LINES);
		gl.glColor3d(C.r1(prgb), C.g1(prgb), C.b1(prgb));
		gl.glVertex3d(px, py, pz);
		gl.glColor3d(C.r1(qrgb), C.g1(qrgb), C.b1(qrgb));
		gl.glVertex3d(qx, qy, qz);
		gl.glEnd();
	}

	protected void triangle(GL2 gl, double px, double py, double pz, double qx, double qy, double qz, double rx, double ry, double rz, int rgbFront, int rgbBack) {
		gl.glBegin(GL2.GL_TRIANGLES);
		gl.glColor3d(C.r1(rgbFront), C.g1(rgbFront), C.b1(rgbFront));
		gl.glVertex3d(qx, qy, qz);
		gl.glVertex3d(rx, ry, rz);
		gl.glVertex3d(px, py, pz);
		gl.glColor3d(C.r1(rgbBack), C.g1(rgbBack), C.b1(rgbBack));
		gl.glVertex3d(qx, qy, qz);
		gl.glVertex3d(px, py, pz);
		gl.glVertex3d(rx, ry, rz);
		gl.glEnd();
	}

	protected void triangle(GL2 gl, Triangle t, Color front, Color back) {
		triangle(gl, t.getA(), t.getB(), t.getC(), front, back);
	}

	protected void triangle(GL2 gl, Point3D a, Point3D b, Point3D c, Color front, Color back) {
		triangle(gl, a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z, front.getRGB(), back.getRGB());
	}

	// p: top left, q: bottom left, r: top right
	protected void quad(GL2 gl, double px, double py, double pz, double qx, double qy, double qz, double rx, double ry, double rz, int rgbFront, int rgbBack) {
		gl.glBegin(GL2.GL_QUADS);
		gl.glColor3d(C.r1(rgbFront), C.g1(rgbFront), C.b1(rgbFront));
		gl.glVertex3d(qx, qy, qz);
		gl.glVertex3d(rx + (qx - px), ry + (qy - py), rz + (qz - pz));
		gl.glVertex3d(rx, ry, rz);
		gl.glVertex3d(px, py, pz);
		gl.glColor3d(C.r1(rgbBack), C.g1(rgbBack), C.b1(rgbBack));
		gl.glVertex3d(qx, qy, qz);
		gl.glVertex3d(px, py, pz);
		gl.glVertex3d(rx, ry, rz);
		gl.glVertex3d(rx + (qx - px), ry + (qy - py), rz + (qz - pz));
		gl.glEnd();
	}

	protected void plane(GL2 gl, double px, double py, double pz, double nx, double ny, double nz, int prgb, int nrgb, double planeSize, double nlength, double nsize) {
		// plane surface sample
		Point3D u_ = V.Point3D(0, 0, 0);
		Point3D v_ = V.Point3D(0, 0, 0);
		G.decomposeUV(V.Plane3D(V.Point3D(px, py, pz), V.Point3D(nx, ny, nz)), u_, v_);
		G.mul(u_, planeSize, u_);
		G.mul(v_, planeSize, v_);
		gl.glBegin(GL2.GL_QUADS);
		gl.glColor3d(C.r1(prgb), C.g1(prgb), C.b1(prgb));
		gl.glVertex3d(px + u_.x, py + u_.y, pz + u_.z);
		gl.glVertex3d(px - v_.x, py - v_.y, pz - v_.z);
		gl.glVertex3d(px - u_.x, py - u_.y, pz - u_.z);
		gl.glVertex3d(px + v_.x, py + v_.y, pz + v_.z);
		gl.glEnd();
		// normal
		line(gl, px, py, pz, px + nx * nlength, py + ny * nlength, pz + nz * nlength, nrgb, nrgb, nsize);
	}

	// p,q,r form the base (p:far left, q: front left, r: far right) and s is the far top left). A null color means the face won't be drawn
	//protected void box(GL2 gl, double px, double py, double pz, double qx, double qy, double qz, double rx, double ry, double rz, double sx, double sy, double sz, Color front, Color back, Color top, Color bottom, Color left, Color right) {
	//	double dx = rx - px;
	//	double dz = qz - pz;
	//	double dy = sy - py;
	//	if (bottom != null) quad(gl, px, py, pz, qx, qy, qz, rx, ry, rz, bottom.getRGB(), bottom.getRGB());
	//	if (top != null) quad(gl, px, py + dy, pz, qx, qy + dy, qz, rx, ry + dy, rz, top.getRGB(), top.getRGB());
	//	if (front != null) quad(gl, qx, qy + dy, qz, qx, qy, qz, qx + dx, qy + dy, qz, front.getRGB(), front.getRGB());
	//	if (back != null) quad(gl, qx, qy + dy, qz - dz, qx, qy, qz - dz, qx + dx, qy + dy, qz - dz, back.getRGB(), back.getRGB());
	//	if (left != null) quad(gl, qx, qy + dy, qz, qx, qy, qz, px, py + dy, pz, left.getRGB(), left.getRGB());
	//	if (right != null) quad(gl, qx + dx, qy + dy, qz, qx + dx, qy, qz, px + dx, py + dy, pz, right.getRGB(), right.getRGB());
	//}

	protected void point(GL2 gl, Point3D p, Color color, double size) {
		point(gl, p.x, p.y, p.z, color.getRGB(), size);
	}

	protected void line(GL2 gl, Point3D p, Point3D q, int prgb, int qrgb, double size) {
		line(gl, p.x, p.y, p.z, q.x, q.y, q.z, prgb, qrgb, size);
	}

	protected void line(GL2 gl, Point3D p, Point3D q, Color color, double size) {
		line(gl, p.x, p.y, p.z, q.x, q.y, q.z, color.getRGB(), color.getRGB(), size);
	}

	protected void line(GL2 gl, Line3D line, int color, double size) {
		line(gl, line.getP(), line.getQ(), color, color, size);
	}

	protected void line(GL2 gl, Line3D line, Color color, double size) {
		line(gl, line, color.getRGB(), size);
	}

	protected void quad(GL2 gl, Point3D p, Point3D q, Point3D r, Color front, Color back) {
		quad(gl, p.x, p.y, p.z, q.x, q.y, q.z, r.x, r.y, r.z, front.getRGB(), back.getRGB());
	}

	protected void quad(GL2 gl, Quad q, Color front, Color back) {
		triangle(gl, q.getA(), q.getB(), q.getC(), front, back);
		triangle(gl, q.getB(), q.getD_(), q.getC(), front, back);
	}

	protected void plane(GL2 gl, Plane3D plane, Color planeColor, Color ncolor, double planeSize, double nlength, double nsize) {
		Point3D p = plane.getPoint();
		Point3D n = plane.getNormal();
		plane(gl, p.x, p.y, p.z, n.x, n.y, n.z, planeColor.getRGB(), ncolor.getRGB(), planeSize, nlength, nsize);
	}

	//protected void box(GL2 gl, Point3D p, Point3D q, Point3D r, Point3D s, Color front, Color back, Color top, Color bottom, Color left, Color right) {
	//	box(gl, p.x, p.y, p.z, q.x, q.y, q.z, r.x, r.y, r.z, s.x, s.y, s.z, front, back, top, bottom, left, right);
	//}

	protected void box(GL2 gl, Box box, Color front, Color back, Color top, Color bottom, Color left, Color right) {
		//box(gl, box.getA(), box.getB(), box.getC(), box.getD(), front, back, top, bottom, left, right);
		
		Quad f = box.getFront_();
		Quad ba = box.getBack_();
		Quad t = box.getTop_();
		Quad b = box.getBottom_();
		Quad l = box.getLeft_();
		Quad r = box.getRight_();
		if(front != null) quad(gl, f, front, front);
		if(back != null) quad(gl, ba, back, back);
		if(top != null) quad(gl, t, top, top);
		if(bottom != null) quad(gl, b, bottom, bottom);
		if(left != null) quad(gl, l, left, left);
		if(right != null) quad(gl, r, right, right);
		
	}

	// axis aligned cube
	protected void cube(GL2 gl, Point3D center, int rgb, double radius) {
		gl.glPushMatrix();
		gl.glTranslated(center.x, center.y, center.z);
		gl.glScaled(radius, radius, radius);
		gl.glColor3d(C.r1(rgb), C.g1(rgb), C.b1(rgb));
		unitCube(gl);
		gl.glPopMatrix();
	}

	protected void unitCube(GL2 gl) {
		double u = .5;
		gl.glBegin(GL2.GL_QUADS);
		// front
		gl.glNormal3d(0, 0, 1);
		gl.glVertex3d(-u, -u, u);
		gl.glVertex3d(u, -u, u);
		gl.glVertex3d(u, u, u);
		gl.glVertex3d(-u, u, u);
		// right
		gl.glNormal3d(1, 0, 0);
		gl.glVertex3d(u, -u, u);
		gl.glVertex3d(u, -u, -u);
		gl.glVertex3d(u, u, -u);
		gl.glVertex3d(u, u, u);
		// left
		gl.glNormal3d(-1, 0, 0);
		gl.glVertex3d(-u, u, u);
		gl.glVertex3d(-u, u, -u);
		gl.glVertex3d(-u, -u, -u);
		gl.glVertex3d(-u, -u, u);
		// back
		gl.glNormal3d(0, 0, -1);
		gl.glVertex3d(-u, u, -u);
		gl.glVertex3d(u, u, -u);
		gl.glVertex3d(u, -u, -u);
		gl.glVertex3d(-u, -u, -u);
		// top
		gl.glNormal3d(0, 1, 0);
		gl.glVertex3d(-u, u, -u);
		gl.glVertex3d(-u, u, u);
		gl.glVertex3d(u, u, u);
		gl.glVertex3d(u, u, -u);
		// bottom
		gl.glNormal3d(0, -1, 0);
		gl.glVertex3d(-u, -u, -u);
		gl.glVertex3d(u, -u, -u);
		gl.glVertex3d(u, -u, u);
		gl.glVertex3d(-u, -u, u);
		gl.glEnd();
	}

	protected void sphere(GL2 gl, Sphere sphere, Color color) {
		Point3D c = sphere.getCenter();
		double r = sphere.getRadius();
		// draw a point a 3 axis align lines (this is just for debug purposes, improve this method if time permits)
		point(gl, c, color, 2);
		line(gl, V.Point3D(c.x, c.y - r, c.z), V.Point3D(c.x, c.y + r, c.z), color, 1);
		line(gl, V.Point3D(c.x - r, c.y, c.z), V.Point3D(c.x + r, c.y, c.z), color, 1);
		line(gl, V.Point3D(c.x, c.y, c.z - r), V.Point3D(c.x, c.y, c.z + r), color, 1);
	}

	// Main
	public static JFrame frame;
	static {
		System.out.println("Init Singleton");
		GLProfile.initSingleton(true);
	}

	public static void main(String[] args) {
		start(new Geo3DFramework(createPanel(), true));
	}

	public static GLJPanel createPanel() {
		GLProfile glprofile = GLProfile.getDefault();
		GLCapabilities glcapabilities = new GLCapabilities(glprofile);
		GLJPanel gljpanel = new GLJPanel(glcapabilities);
		return gljpanel;
	}

	public static void start(Geo3DFramework listener) {
		frame = new JFrame("Test Geo3D");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		UI.usualFrameInit(frame, listener.panel, true);
		frame.addKeyListener(listener);
	}

}