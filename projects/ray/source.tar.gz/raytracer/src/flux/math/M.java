/*
 * Written by David Lareau.
 * 
 * Collection of math functions that I find handy.
 */
package flux.math;

import flux.geo3D.Point3D;

public class M {

	// Kinda Equals
	public static final double EPSILON = 0.0000001;

	public static final boolean kindaEquals(double a, double b) {
		return kindaEquals(a, b, EPSILON);
	}

	public static final boolean kindaEquals(double a, double b, double epsilon) {
		return Math.abs(a - b) <= epsilon;
	}

	public static final boolean kindaGreaterOrEqual(double a, double b) {
		return kindaGreaterOrEqual(a, b, EPSILON);
	}

	public static final boolean kindaLowerOrEqual(double a, double b) {
		return kindaLowerOrEqual(a, b, EPSILON);
	}

	public static final boolean kindaGreaterOrEqual(double a, double b, double epsilon) {
		return a > b || kindaEquals(a, b, epsilon);
	}

	public static final boolean kindaLowerOrEqual(double a, double b, double epsilon) {
		return a < b || kindaEquals(a, b, epsilon);
	}

	public static final boolean kindaStriclyGreater(double a, double b, double epsilon) {
		return a > b && !kindaEquals(a, b, epsilon);
	}

	public static final boolean kindaStriclyLower(double a, double b, double epsilon) {
		return a < b && !kindaEquals(a, b, epsilon);
	}

	public static final boolean kindaStriclyGreater(double a, double b) {
		return kindaStriclyGreater(a, b, EPSILON);
	}

	public static final boolean kindaStriclyLower(double a, double b) {
		return kindaStriclyLower(a, b, EPSILON);
	}

	// Round
	public static final double round(double x, int decimals) {
		double p = Math.pow(10, decimals);
		return Math.round(x * p) / p;
	}

	// Cyclic values
	public static final double boundCyclic(double x, double minInclusive, double maxExclusive) {
		double range = maxExclusive - minInclusive;
		while (x < minInclusive)
			x += range;
		while (x >= maxExclusive)
			x -= range;
		return x;
	}

	public static final double boundCrop(double x, double minInclusive, double maxInclusive) {
		return Math.max(minInclusive, Math.min(x, maxInclusive));
	}

	public static final boolean withinInclusive(double x, double minInclusive, double maxInclusive) {
		return x >= minInclusive && x <= maxInclusive;
	}

	// Fraction
	public static final double ratio(double numerator, double denominator) {
		return numerator / denominator;
	}

	public static final double ratioP(double numerator, double denominator) {
		return round(numerator / denominator, 2);
	}

	// Power
	// this is a spin off of an old method I had called greaterOrEqualPowerOfTwo. Now it would be nextPower(x,2,true);
	public static final double nextPower(double current, double base, boolean currentIsCandidate) {
		double p = 1;
		while (p < current)
			p *= base;
		if (p == current && !currentIsCandidate) p *= base;
		return p;
	}

	// Interpolation
	public static double lerp(double t, double a, double b) {
		return a + t * (b - a);
	}

	// Min Max
	public static double max(double... args) {
		double max = args[0];
		for (int i = 1; i < args.length; i++) {
			if (args[i] > max) max = args[i];
		}
		return max;
	}

	public static double min(double... args) {
		double min = args[0];
		for (int i = 1; i < args.length; i++) {
			if (args[i] < min) min = args[i];
		}
		return min;
	}

	public static int indexOfMinValueGreaterThan(double t[], int offset, int length, double greaterThanValue) {
		int minIndex = -1;
		double minValue = Double.MAX_VALUE;
		for (int i = 0; i < length; i++) {
			double value = t[offset + i];
			if (value > greaterThanValue && value < minValue) {
				minIndex = offset + i;
				minValue = value;
			}
		}
		return minIndex;
	}

	// Sign
	public static int sign(double x) {
		if (x < 0)
			return -1;
		else
			return 1;
	}

	public static int signFuzy(double x) {
		if (kindaEquals(x, 0)) return 1;
		return sign(x);
	}

	// Solve
	public static int quadraticRealRoots(double A, double B, double C, double[] out_roots) {
		double det = B * B - 4 * A * C;
		if (det < 0) return 0;
		det = Math.sqrt(det);
		// using Floating point implementation found on wikipedia
		double q = (B + sign(B) * det) / -2;
		out_roots[0] = q / A;
		if (det == 0) return 1;
		out_roots[1] = C / q;
		return 2;
		/*
		out_roots[0] = (-B + det) / (2 * A);
		out_roots[1] = (-B - det) / (2 * A);
		return 2;
		*/
	}

	// Distance
	public static double euclideanDistance2(Point3D p, Point3D q) {
		double dx = q.x - p.x;
		double dy = q.y - p.y;
		double dz = q.z - p.z;
		return dx * dx + dy * dy + dz * dz;
	}

	public static double euclideanDistance(Point3D p, Point3D q) {
		return Math.sqrt(euclideanDistance2(p, q));
	}

	// Main
	public static void main(String[] args) {
		double[] roots = new double[2];
		int n;

		roots[0] = roots[1] = 0;
		n = quadraticRealRoots(-1, -3, 8, roots);
		System.out.println((n >= 1 ? String.valueOf(roots[0]) : "-") + " " + (n >= 2 ? String.valueOf(roots[1]) : "-"));
	}

}
