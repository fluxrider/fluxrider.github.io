/*
 * Written by David Lareau on January 14, 2010
 * 
 * Stores Complex number
 */
package flux.math;

public class Complex {

	// Attributes
	public double real;
	public double imag;

	// Construct
	public Complex() {
		this(0, 0);
	}

	public Complex(double real, double imaginary) {
		this.real = real;
		this.imag = imaginary;
	}

	public String toString() {
		return real + " + i" + imag;
	}

	// Methods
	public double magnitude() {
		return Math.sqrt(real * real + imag * imag);
	}

	public double phase() {
		return Math.atan(imag / real);
	}

}
