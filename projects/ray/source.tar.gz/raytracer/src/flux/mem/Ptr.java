/*
 * Written by David Lareau on February 16, 2012.
 * 
 * Pointer to an object.
 * This can be used to return values through parameters.
 */
package flux.mem;

public class Ptr<T> {

	// Attributes
	public T value;

	// Construct
	public Ptr() {
		this.value = null;
	}

	public Ptr(T value) {
		this.value = value;
	}

}
