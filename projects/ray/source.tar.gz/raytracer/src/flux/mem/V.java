/*
 * Written by David Lareau on September 1, 2011.
 * 
 * Manages pool of preallocated objects for performance/convenience.
 * All these are volatile. That's what the V stands for. Use them quickly.
 * There is a limited concurent amount of them.
 * Keep in mind its not a stack that will overflow, but a circular list.
 * This means if you call get() capacity + 1 time, the first volatile object is being reused.
 * 
 * A tracker mechanism can be used to gauge how big the pools should be.
 */
package flux.mem;

import flux.geo2D.Point2D;
import flux.geo3D.Line3D;
import flux.geo3D.Plane3D;
import flux.geo3D.Point3D;
import flux.geo3D.Quad;
import flux.geo3D.Triangle;
import flux.material.Surface;
import flux.math.Complex;

public class V<T> {

	// Debug
	private static final boolean disableVolatile = true;

	// Attributes
	private T[] objects;
	private int index;
	// tracking
	private int tracker;
	private boolean tracking;

	// Construct
	@SuppressWarnings("unchecked")
	public V(int capacity, Class factory) {
		objects = (T[]) new Object[capacity];
		try {
			for (int i = 0; i < objects.length; i++) {
				objects[i] = (T) factory.newInstance();
			}
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		tracking = false;
	}

	// Methods
	public T get() {
		tracker++;
		if (index >= objects.length) index = 0;
		return objects[index++];
	}

	// Tracker
	public void trackBegin() {
		if (tracking) throw new RuntimeException("Concurrent tracking detected");
		tracker = 0;
		tracking = true;
	}

	public int trackEnd() {
		if (!tracking) throw new RuntimeException("Wasn't tracking to begin with");
		tracking = false;
		return tracker;
	}

	// == Library Objects Pool ==
	public static final int DEFAULT_POOL_SIZE = 20;
	public static V<Point2D> point2D = new V<Point2D>(DEFAULT_POOL_SIZE, Point2D.class);
	public static V<Point3D> point3D = new V<Point3D>(DEFAULT_POOL_SIZE, Point3D.class);
	public static V<Line3D> line3D = new V<Line3D>(DEFAULT_POOL_SIZE, Line3D.class);
	public static V<Plane3D> plane3D = new V<Plane3D>(DEFAULT_POOL_SIZE, Plane3D.class);
	public static V<Complex> complex = new V<Complex>(DEFAULT_POOL_SIZE, Complex.class);
	public static V<Ptr<Object>> ptr = new V<Ptr<Object>>(DEFAULT_POOL_SIZE, Ptr.class);
	public static V<Ptr<Double>> ptrDouble = new V<Ptr<Double>>(DEFAULT_POOL_SIZE, Ptr.class);
	public static V<Triangle> triangle = new V<Triangle>(DEFAULT_POOL_SIZE, Triangle.class);
	public static V<Quad> quad = new V<Quad>(DEFAULT_POOL_SIZE, Quad.class);

	public static Point2D Point2D(double x, double y) {
		Point2D out = disableVolatile ? new Point2D() : point2D.get();
		out.set(x, y);
		return out;
	}

	public static Point3D Point3D(double x, double y, double z) {
		Point3D out = disableVolatile ? new Point3D() : point3D.get();
		out.set(x, y, z);
		return out;
	}

	public static Point3D Point3D(Point3D p_) {
		Point3D out = disableVolatile ? new Point3D() : point3D.get();
		out.set(p_.x, p_.y, p_.z);
		return out;
	}

	public static Point3D Point3D(Point2D p_) {
		Point3D out = disableVolatile ? new Point3D() : point3D.get();
		out.set(p_.x, p_.y, 0);
		return out;
	}

	public static Line3D Line3D(Point3D p_, Point3D q_) {
		Line3D out = disableVolatile ? new Line3D() : line3D.get();
		out.set(p_, q_);
		return out;
	}

	public static Plane3D Plane3D(Point3D p_, Point3D normal_) {
		Plane3D out = disableVolatile ? new Plane3D() : plane3D.get();
		out.set(p_, normal_);
		return out;
	}

	public static Plane3D Plane3D(Triangle t_) {
		Plane3D out = disableVolatile ? new Plane3D() : plane3D.get();
		out.set(t_);
		return out;
	}

	public static Complex Complex(double real, double imaginary) {
		Complex out = disableVolatile ? new Complex() : complex.get();
		out.real = real;
		out.imag = imaginary;
		return out;
	}

	public static Triangle Triangle(Point3D p_, Point3D q_, Point3D r_) {
		Triangle out = disableVolatile ? new Triangle() : triangle.get();
		out.set(p_, q_, r_);
		return out;
	}

	public static Quad Quad(Point3D p_, Point3D q_, Point3D r_) {
		Quad out = disableVolatile ? new Quad() : quad.get();
		out.set(p_, q_, r_);
		return out;
	}

	public static Ptr<Object> Ptr(Object value) {
		Ptr<Object> out = disableVolatile ? new Ptr<Object>() : ptr.get();
		out.value = value;
		return out;
	}

	public static Ptr<Object> Ptr() {
		return Ptr(null);
	}

	public static Ptr<Double> PtrDouble(Double value) {
		Ptr<Double> out = disableVolatile ? new Ptr<Double>() : ptrDouble.get();
		out.value = value;
		return out;
	}

	public static Ptr<Double> PtrDouble() {
		return PtrDouble(null);
	}

	// == Pre-allocated general purpose arrays ==
	public static double[] getDoubleBuffer() {
		return disableVolatile ? new double[DEFAULT_POOL_SIZE] : doubles_;
	}

	public static Surface[] getSurfaceBuffer() {
		return disableVolatile ? new Surface[DEFAULT_POOL_SIZE] : surfaces_;
	}

	private static double[] doubles_ = new double[DEFAULT_POOL_SIZE];
	private static Surface[] surfaces_ = new Surface[DEFAULT_POOL_SIZE];
}
