/*
 * Written by David Lareau
 * 
 * Encompass all material properties I'll be using.
 */
package flux.material;

import java.awt.Color;
import java.io.PrintStream;

import flux.util.A;

public class Material {

	public static final int UNSET = 0;
	public static final int SIMPLE = 1;
	public static final int PHONG = 2;
	public static final int COOK = 3;
	public static final int LIGHT = -1;

	public int type;

	public Material() {
		this.type = UNSET;
	}

	// Simple Color
	public Color color;

	// Blinn Phong
	public double ambient[]; // for each wavelength (r,g,b)
	public double diffuse[]; // for each wavelength (r,g,b)
	public double specular[]; // for each wavelength (r,g,b)
	public double shininess;

	// Cook Torrance
	public double cook_specular = 1;
	public double cook_diffuse = 0;
	public double cook_ambiant = 0.01;
	public double cook_colorCoefficient[] = new double[] { .50, .18, .156 };
	public double cook_indexOfRefraction[] = new double[] { 0.214, 1.132, 1.150 };
	public double cook_w[] = new double[] { .4, .6 };
	public double cook_m[] = new double[] { .4, .2 };

	// Debug
	public boolean drawInPreview;

	public Material copy() {
		Material m = new Material();
		m.type = this.type;
		m.color = this.color == null ? null : new Color(this.color.getRGB());

		// Blinn Phong
		m.ambient = A.copy(this.ambient);
		m.diffuse = A.copy(this.diffuse);
		m.specular = A.copy(this.specular);
		m.shininess = this.shininess;

		// Cook Torrance
		m.cook_specular = this.cook_specular;
		m.cook_diffuse = this.cook_diffuse;
		m.cook_ambiant = this.cook_ambiant;
		m.cook_colorCoefficient = A.copy(this.cook_colorCoefficient);
		m.cook_indexOfRefraction = A.copy(this.cook_indexOfRefraction);
		m.cook_w = A.copy(this.cook_w);
		m.cook_m = A.copy(this.cook_m);

		// Debug
		m.drawInPreview = this.drawInPreview;

		return m;
	}

	public boolean equals(Material other, PrintStream out) {
		if (other == null) {
			if(out != null) out.println("Material mismatch, the other is null");
			return false;
		}
		if (other.type != this.type) {
			if(out != null) out.println("Material type mismatch " + type + " " + other.type);
			return false;
		}
		if ((other.color == null || this.color == null) && other.color != this.color) {
			if(out != null) out.println("Material color mismatch " + color + " " + other.color);
			return false;
		}
		if (!other.color.equals(this.color)) {
			if(out != null) out.println("Material color mismatch " + color + " " + other.color);
			return false;
		}

		// Blinn Phong
		if (!A.equals(other.ambient, this.ambient)) {
			if(out != null) out.println("Material ambient mismatch ");
			return false;
		}
		if (!A.equals(other.diffuse, this.diffuse)) {
			if(out != null) out.println("Material diffuse mismatch ");
			return false;
		}
		if (!A.equals(other.specular, this.specular)) {
			if(out != null) out.println("Material specular mismatch ");
			return false;
		}
		if (other.shininess != this.shininess) {
			if(out != null) out.println("Material shininess mismatch ");
			return false;
		}

		// Cook Torrance
		if (other.cook_specular != this.cook_specular) {
			if(out != null) out.println("Material cook_specular mismatch ");
			return false;
		}
		if (other.cook_diffuse != this.cook_diffuse) {
			if(out != null) out.println("Material cook_diffuse mismatch ");
			return false;
		}
		if (other.cook_ambiant != this.cook_ambiant) {
			if(out != null) out.println("Material cook_ambiant mismatch ");
			return false;
		}
		if (!A.equals(other.cook_colorCoefficient, this.cook_colorCoefficient)) {
			if(out != null) out.println("Material cook_colorCoefficient mismatch ");
			return false;
		}
		if (!A.equals(other.cook_indexOfRefraction, this.cook_indexOfRefraction)) {
			if(out != null) out.println("Material cook_indexOfRefraction mismatch ");
			return false;
		}
		if (!A.equals(other.cook_w, this.cook_w)) {
			if(out != null) out.println("Material cook_w mismatch ");
			return false;
		}
		if (!A.equals(other.cook_m, this.cook_m)) {
			if(out != null) out.println("Material cook_m mismatch ");
			return false;
		}

		// Debug
		if (other.drawInPreview != this.drawInPreview) {
			if(out != null) out.println("Material drawInPreview mismatch ");
			return false;
		}

		return true;
	}

	public boolean equals(Material other) {
		return equals(other, null);
	}

}
