package flux.material;

import java.io.PrintStream;

import flux.geo3D.Plane3D;
import flux.geo3D.Point3D;
import flux.mem.V;

public abstract class Surface {

	// Attributes
	private Material material;

	// Methods
	public Material getMaterial() {
		return material;
	}

	public void setMaterial(Material material) {
		this.material = material;
	}

	public abstract Point3D getNormal_(Point3D impact_, Point3D eye_);

	// un-volatile this surface
	public Surface copy() {
		Surface surface = this._copy();
		if (material != null) surface.setMaterial(this.material.copy());
		return surface;
	}

	protected abstract Surface _copy(); // un-volatile this surface

	public Plane3D getPlane_(Point3D impact_, Point3D eye_) {
		try {
			return V.Plane3D(impact_, getNormal_(impact_, eye_));
		} catch (Exception e) {
			return V.Plane3D(impact_, getNormal_(impact_, eye_));
		}
	}

	protected abstract boolean _equals(Surface surface, PrintStream out);

	public boolean equals(Surface other, PrintStream out) {
		if (material != null)
			return _equals(other, out) && material.equals(other.material, out);
		else {
			if(other.material != null) out.println("Other material isnt null");
			return _equals(other, out) && other.material == null;
		}
	}

	public boolean equals(Surface other) {
		return equals(other, null);
	}

}
