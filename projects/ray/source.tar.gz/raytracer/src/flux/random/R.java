/*
 * Written by David Lareau.
 * 
 * Collection of random functions that I find handy.
 */
package flux.random;

import flux.geo3D.G;
import flux.geo3D.Point3D;
import flux.geo3D.Quad;
import flux.mem.Ptr;
import flux.mem.V;

public class R {

	// Uniform Range
	public static final double uniform_exclusive_f64(double min, double max) {
		return min + (Math.random() * (max - min)); // [min, max[
	}

	public static final int uniform_inclusive_s32(int min, int max) {
		if (min > max) throw new IllegalArgumentException("k > l, " + min + " > " + max);
		return min + (int) (Math.random() * (max - min + 1)); // [min, max]
	}

	public static final int uniform_exclusive_s32(int min, int max) {
		return uniform_inclusive_s32(min, max - 1); // [min, max[
	}

	// Uniform Dice
	public static final int d(int face) {
		return uniform_inclusive_s32(1, face);
	}

	public static final int d4() {
		return d(4);
	}

	public static final int d6() {
		return d(6);
	}

	public static final int d8() {
		return d(8);
	}

	public static final int d10() {
		return d(10);
	}

	public static final int d12() {
		return d(12);
	}

	public static final int d20() {
		return d(20);
	}

	public static final int d100() {
		return d(100);
	}

	// Sphere
	public static final void sphere(Point3D out) {
		/*
		double x, y, z, w, t;
		z = 2.0 * Math.random() - 1.0;
		t = 2.0 * Math.PI * Math.random();
		w = Math.sqrt(1 - z * z);
		x = w * Math.cos(t);
		y = w * Math.sin(t);
		out.set(x, y, z);
		*/
		// Marsaglia (http://mathworld.wolfram.com/SpherePointPicking.html)

		double a, b;
		do {
			a = R.uniform_exclusive_f64(-1, 1);
			b = R.uniform_exclusive_f64(-1, 1);
		} while (a * a + b * b >= 1);
		double sqrt = Math.sqrt(1 - a * a - b * b);
		double x = 2 * a * sqrt;
		double y = 2 * b * sqrt;
		double z = 1 - 2 * (a * a + b * b);
		out.set(x, y, z);

	}

	public static final Point3D sphere_() {
		Point3D p = V.Point3D(0, 0, 0);
		sphere(p);
		return p;
	}

	public static final void sphere(Ptr<Double> elevation, Ptr<Double> azymuth) {
		Point3D p = sphere_();
		elevation.value = Math.acos(p.y);
		azymuth.value = Math.atan(p.z / p.x);
	}

	public static final void hemisphere(Ptr<Double> elevation, Ptr<Double> azymuth) {
		Point3D p = sphere_();
		elevation.value = Math.acos(Math.abs(p.y));
		azymuth.value = Math.atan(p.z / p.x);
	}

	// Quad
	public static final void quad(Quad quad, Point3D out) {
		out.set(quad_(quad));
	}

	public static final Point3D quad_(Quad quad) {
		double x = Math.random();
		double y = Math.random();
		Point3D a = quad.getA();
		Point3D b = quad.getB();
		Point3D c = quad.getC();
		Point3D v = G.sub_(b, a);
		Point3D u = G.sub_(c, a);
		return G.add_(G.add_(a, G.mul_(v, x)), G.mul_(u, y));
	}

	public static final Point3D quad(Quad quad) {
		return new Point3D(quad_(quad));
	}

}
