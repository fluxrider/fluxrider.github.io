/*
 * Written by David Lareau.
 * 
 * A box defined by 4 points (the first point is the corner, the next two form the base quad, the fourth is the top of corner)
 */
package flux.geo3D;

import flux.material.Material;
import flux.mem.V;

public class Box {

	// Constants
	public static final int FRONT = 0;
	public static final int BACK = 1;
	public static final int TOP = 2;
	public static final int BOTTOM = 3;
	public static final int LEFT = 4;
	public static final int RIGHT = 5;

	// Attributes
	protected Point3D a;
	protected Point3D b;
	protected Point3D c;
	protected Point3D d;

	private Material[] material = new Material[6];

	// Construct
	public Box() {
		this.a = new Point3D();
		this.b = new Point3D();
		this.c = new Point3D();
		this.d = new Point3D();
	}

	public Box(Point3D a_, Point3D b_, Point3D c_, Point3D d_) {
		this.a = new Point3D(a_);
		this.b = new Point3D(b_);
		this.c = new Point3D(c_);
		this.d = new Point3D(d_);
	}

	// Methods
	public Point3D getA() {
		return a;
	}

	public Point3D getB() {
		return b;
	}

	public Point3D getC() {
		return c;
	}

	public Point3D getD() {
		return d;
	}

	public Point3D getFarTopRight_() {
		return V.Point3D(d.x + (c.x - a.x), d.y + (c.y - a.y), d.z + (c.z - a.z));
	}

	public Point3D getFrontTopRight_() {
		return V.Point3D(d.x + (c.x - a.x) + (b.x - a.x), d.y + (c.y - a.y) + (b.y - a.y), d.z + (c.z - a.z) + (b.z - a.z));
	}

	public Point3D getFrontTopLeft_() {
		return V.Point3D(b.x + (d.x - a.x), b.y + (d.y - a.y), b.z + (d.z - a.z));
	}

	public Point3D getFrontBottomRight_() {
		return V.Point3D(c.x + (b.x - a.x), c.y + (b.y - a.y), c.z + (b.z - a.z));
	}

	public Quad getFront_() {
		Quad q = V.Quad(getFrontTopLeft_(), b, getFrontTopRight_());
		q.setMaterial(material[FRONT]);
		return q;
	}

	public Quad getBack_() {
		Quad q = V.Quad(d, a, getFarTopRight_());
		q.setMaterial(material[BACK]);
		return q;
	}

	public Quad getTop_() {
		Quad q = V.Quad(d, getFrontTopLeft_(), getFarTopRight_());
		q.setMaterial(material[TOP]);
		return q;
	}

	public Quad getBottom_() {
		Quad q = V.Quad(a, b, c);
		q.setMaterial(material[BOTTOM]);
		return q;
	}

	public Quad getLeft_() {
		Quad q = V.Quad(d, a, getFrontTopLeft_());
		q.setMaterial(material[LEFT]);
		return q;
	}

	public Quad getRight_() {
		Quad q = V.Quad(getFrontTopRight_(), getFrontBottomRight_(), getFarTopRight_());
		q.setMaterial(material[RIGHT]);
		return q;
	}

	// Methods
	public Material getMaterial(int position) {
		return material[position];
	}

	public void setMaterial(Material material, int position) {
		this.material[position] = material;
	}

}
