/*
 * Written by David Lareau.
 * 
 * A triangle.
 */
package flux.geo3D;

import java.io.PrintStream;

import flux.material.Surface;
import flux.math.M;

public class Triangle extends Surface {

	// Attributes
	protected Point3D a;
	protected Point3D b;
	protected Point3D c;

	// Construct
	public Triangle() {
		this.a = new Point3D();
		this.b = new Point3D();
		this.c = new Point3D();
	}

	public Triangle(Point3D a_, Point3D b_, Point3D c_) {
		this.a = new Point3D(a_);
		this.b = new Point3D(b_);
		this.c = new Point3D(c_);
	}

	public Triangle(Triangle t) {
		this.a = new Point3D(t.a);
		this.b = new Point3D(t.b);
		this.c = new Point3D(t.c);
		this.setMaterial(t.getMaterial());
	}
	
	public boolean _equals(Surface other, PrintStream out) {
		if(!(other instanceof Triangle)) {
			if(out != null) out.println("Different class: " + this.getClass() + " " + other.getClass());
			return false;
		}
		Triangle o = (Triangle)other;
		if(!a.equals(o.a)) {
			if(out != null) out.println("Triangle a mismatch: " + a + " " + o.a);
			return false;
		}
		if(!b.equals(o.b)) {
			if(out != null) out.println("Triangle b mismatch: " + b + " " + o.b);
			return false;
		}
		if(!c.equals(o.c)) {
			if(out != null) out.println("Triangle c mismatch: " + c + " " + o.c);
			return false;
		}
		return true;
	}

	// Methods
	public void set(Point3D a_, Point3D b_, Point3D c_) {
		this.a.set(a_);
		this.b.set(b_);
		this.c.set(c_);
	}

	public Point3D getA() {
		return a;
	}

	public Point3D getB() {
		return b;
	}

	public Point3D getC() {
		return c;
	}

	public Point3D getNormal_(Point3D impact_, Point3D eye_) {
		Point3D n = G.cross_(G.sub_(b, a), G.sub_(c, a));
		n.normalizeInPlace();
		// invert if on the other side
		double d1 = M.euclideanDistance2(eye_, G.add_(impact_, n));
		double d2 = M.euclideanDistance2(eye_, G.sub_(impact_, n));
		if (d1 > d2) n.invertInPlace();
		n.normalizeInPlace();
		return n;
	}

	protected Surface _copy() {
		return new Triangle(this);
	}

	public Point3D getPoint_(double beta, double gamma) {
		if ((beta < 0 || beta > 1) && !M.kindaEquals(beta, 0) && !M.kindaEquals(beta, 1)) return null;
		if ((gamma < 0 || gamma > 1) && !M.kindaEquals(gamma, 0) && !M.kindaEquals(gamma, 1)) return null;
		double alpha = 1 - beta - gamma;
		if ((alpha < 0 || alpha > 1) && !M.kindaEquals(alpha, 0) && !M.kindaEquals(alpha, 1)) return null;
		return G.add_(G.add_(G.mul_(a, alpha), G.mul_(b, beta)), G.mul_(c, gamma));
	}

}
