/*
 * Written by David Lareau.
 * 
 * A quad defined by 3 points (the first is the corner)
 */
package flux.geo3D;

import java.io.PrintStream;

import flux.material.Surface;
import flux.mem.V;

public class Quad extends Triangle {

	public Quad() {
		super();
	}

	public Quad(Point3D a_, Point3D b_, Point3D c_) {
		super(a_, b_, c_);
	}

	public Quad(Quad t) {
		super(t.a, t.b, t.c);
	}

	public boolean _equals(Surface other, PrintStream out) {
		if (!(other instanceof Quad)) {
			if (out != null) out.println("Different class: " + this.getClass() + " " + other.getClass());
			return false;
		}
		Quad o = (Quad) other;
		if(!a.equals(o.a)) {
			if(out != null) out.println("Quad a mismatch: " + a + " " + o.a);
			return false;
		}
		if(!b.equals(o.b)) {
			if(out != null) out.println("Quad b mismatch: " + b + " " + o.b);
			return false;
		}
		if(!c.equals(o.c)) {
			if(out != null) out.println("Quad c mismatch: " + c + " " + o.c);
			return false;
		}
		return true;
	}

	public Point3D getD_() {
		return V.Point3D(c.x + (b.x - a.x), c.y + (b.y - a.y), c.z + (b.z - a.z));
	}

	protected Surface _copy() {
		return new Quad(this);
	}
}
