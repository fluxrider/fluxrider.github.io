/*
 * Written by David Lareau.
 * 
 * A plane in 3D space. Different forms are supported to define the plane.
 */
package flux.geo3D;

import flux.math.M;

public class Plane3D {

	// Attributes
	private Point3D p;
	private Point3D n;

	// Construct
	public Plane3D(Point3D p_, Point3D normal_) {
		this();
		set(p_, normal_);
	}

	public Plane3D(Point3D p_, Point3D q_, Point3D r_) {
		this();
		set(p_, q_, r_);
	}

	public Plane3D(Triangle t_) {
		this();
		set(t_.getA(), t_.getB(), t_.getC());
	}

	public Plane3D(Plane3D p_) {
		this();
		set(p_);
	}

	public boolean equals(Plane3D other) {
		return p.equals(other.p) && n.equals(other.n);
	}

	// (general form)
	public Plane3D(double a, double b, double c, double d) {
		this.n = new Point3D(a, b, c);
		this.n.normalizeInPlace();
		this.p = new Point3D(0, 0, -d / c); // finding a arbitrary point on plane. I'm choosing the z-intercept.
	}

	// (Hessian Normal form)
	public Plane3D(Point3D normal_, double p) {
		this();
		if (normal_.length() != 1) throw new RuntimeException("Normal vector supplied for plane3D is not normalized: " + normal_);
		this.n.set(normal_);
		this.p = new Point3D(0, 0, -p / normal_.z); // finding a arbitrary point on plane. I'm choosing the z-intercept.
	}

	public Plane3D() {
		// empty plane, makes no sense but is used by V to create an object pool
		p = new Point3D();
		n = new Point3D();
	}

	public void set(Point3D p_, Point3D normal_) {
		if (!M.kindaEquals(normal_.length(), 1)) throw new RuntimeException("Normal vector supplied for plane3D is not normalized: " + normal_ + " " + normal_.length());
		this.p.set(p_);
		this.n.set(normal_);
	}

	public void set(Plane3D p_) {
		this.p.set(p_.p);
		this.n.set(p_.n);
	}

	public void set(Point3D p_, Point3D q_, Point3D r_) {
		this.p.set(p_);
		this.n.set(G.cross_(G.sub_(r_, p_), G.sub_(q_, p_)));
		this.n.normalizeInPlace();
	}

	public void set(Triangle t_) {
		this.set(t_.getA(), t_.getB(), t_.getC());
	}

	public String toString() {
		return String.format("%s|%n", p, n);
	}

	// Methods
	public Point3D getNormal() {
		return n;
	}

	public Point3D getPoint() {
		return p;
	}

	public double test(Point3D q) {
		return G.dot(n, G.sub_(q, p)); // ax + by + cz + d = n·(q-p) = 0 if on plane  
	}

	public Point3D project_(Point3D q) {
		double signedDistance = test(q);
		Point3D p = G.add_(q, G.mul_(n, -signedDistance));
		if (!M.kindaEquals(test(p), 0)) throw new RuntimeException("Not a good implementation: " + test(p));
		return p;
	}

	public double getA() {
		return n.x; // n = (a,b,c)
	}

	public double getB() {
		return n.y; // n = (a,b,c)
	}

	public double getC() {
		return n.z; // n = (a,b,c)
	}

	// this is the same as 	Hessian Normal form p
	public double getD() {
		return -G.dot(n, p); // d = -a*px - b*py - c*pz
	}

}
