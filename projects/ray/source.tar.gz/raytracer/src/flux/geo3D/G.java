/*
 * Written by David Lareau.
 * 
 * Collection of geometric functions.
 * 
 * Function will normally take an out buffer if necessary. 
 * Flavor that create the buffer for you, or use volatile output are also given. 
 */
package flux.geo3D;

import flux.geo2D.Point2D;
import flux.material.Surface;
import flux.math.M;
import flux.mem.Ptr;
import flux.mem.V;

public class G {

	// Point2D
	public static final double dot(Point2D p, Point2D q) {
		return p.x * q.x + p.y * q.y;
	}

	public static final void add(Point2D p, Point2D q, Point2D out) {
		out.set(p.x + q.x, p.y + q.y);
	}

	public static final void sub(Point2D p, Point2D q, Point2D out) {
		out.set(p.x - q.x, p.y - q.y);
	}

	public static final void mul(Point2D p, double scalar, Point2D out) {
		out.set(p.x * scalar, p.y * scalar);
	}

	public static final void div(Point2D p, double scalar, Point2D out) {
		out.set(p.x / scalar, p.y / scalar);
	}

	// Angle between 3D vectors
	public static final double angle(Point3D u, Point3D v) {
		// dot product the vectors gives |u||v|cos(angle)
		double dot = dot(u, v);
		double cos = dot / (u.length() * v.length());
		return Math.acos(cos);
	}

	// Angle formed by triangle at O
	public static final double angle(Point3D p, Point3D o, Point3D q) {
		return angle(sub_(p, o), sub_(q, o));
	}

	// Triangle2D
	// negative if oriented clockwise
	public static final double signedArea(Point2D a, Point2D b, Point2D c) {
		return ((b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y)) / 2;
	}
	
	public static final boolean inside(Point2D p, Point2D a, Point2D b, Point2D c) {
		// use 3D ray-triangle test
		Triangle t = V.Triangle(V.Point3D(a), V.Point3D(b), V.Point3D(c));
		Line3D line = V.Line3D(V.Point3D(p), V.Point3D(p.x, p.y, 1));
		return intersection(line, t, null);
	}
	
	// Triangle3D
	public static final double area(Triangle t) {
		return area(t.getA(), t.getB(), t.getC());
	}
	
	public static final double area(Quad q) {
		return 2* area(q.getA(), q.getB(), q.getC());
	}
	
	public static final double area(Point3D a, Point3D b, Point3D c) {
		Point3D v = sub_(b, a);
		Point3D u = sub_(c, a);
		Point3D cross = cross_(v, u);
		return cross.length() / 2;
	}

	// Point3D
	public static final double dot(Point3D p, Point3D q) {
		return p.x * q.x + p.y * q.y + p.z * q.z;
	}

	public static final void cross(Point3D p, Point3D q, Point3D out) {
		out.x = p.y * q.z - p.z * q.y;
		out.y = p.z * q.x - p.x * q.z;
		out.z = p.x * q.y - p.y * q.x;
	}

	public static final void add(Point3D p, Point3D q, Point3D out) {
		out.set(p.x + q.x, p.y + q.y, p.z + q.z);
	}

	public static final void sub(Point3D p, Point3D q, Point3D out) {
		out.set(p.x - q.x, p.y - q.y, p.z - q.z);
	}

	public static final void mul(Point3D p, double scalar, Point3D out) {
		out.set(p.x * scalar, p.y * scalar, p.z * scalar);
	}

	public static final void div(Point3D p, double scalar, Point3D out) {
		out.set(p.x / scalar, p.y / scalar, p.z / scalar);
	}

	// Plane
	public static final boolean xintercept(Plane3D plane, Point3D out) {
		return _axisIntercept(plane, plane.getC(), 0, out);
	}

	public static final boolean yintercept(Plane3D plane, Point3D out) {
		return _axisIntercept(plane, plane.getC(), 1, out);
	}

	public static final boolean zintercept(Plane3D plane, Point3D out) {
		return _axisIntercept(plane, plane.getC(), 2, out);
	}

	private static final boolean _axisIntercept(Plane3D plane, double v, int i, Point3D out) {
		out.x = 0;
		out.y = 0;
		out.z = 0;
		if (v == 0) return false;
		double d = plane.getD();
		if (i == 0)
			out.x = -d / v;
		else if (i == 1)
			out.y = -d / v;
		else
			out.z = -d / v;
		return true;
	}

	public static final void decomposeUV(Plane3D plane, Point3D outU, Point3D outV) {
		Point3D p = plane.getPoint();
		// make a line with x-intercept if possible
		Point3D intercept = V.Point3D(0, 0, 0);
		if (p.x != 0 && xintercept(plane, intercept)) {
		} else if (p.y != 0 && yintercept(plane, intercept)) {
		} else if (p.z != 0 && zintercept(plane, intercept)) {
		} else
			throw new RuntimeException("Failed to find any line with an intercept of plane " + plane);
		// make a normalized vector out of this line 
		sub(p, intercept, outU);
		outU.normalizeInPlace();
		// cross with normal
		cross(outU, plane.getNormal(), outV);
	}

	// Parametric
	public static final void parametricPoint(Line3D line, double t, Point3D out) {
		Point3D p = line.getP();
		Point3D u = line.getVectorQPUnormalized_();
		out.x = p.x + t * u.x;
		out.y = p.y + t * u.y;
		out.z = p.z + t * u.z;
	}

	// Distance
	public static final double getSignedDistance(Point3D p, Plane3D plane) {
		return plane.test(p);
	}

	public static final boolean areSameSideOf(Point3D p, Point3D q, Plane3D plane) {
		return M.sign(getSignedDistance(p, plane)) == M.sign(getSignedDistance(q, plane));
	}

	public static final boolean areSameSideOfAndBothFarEnough(Point3D p, Point3D q, Plane3D plane) {
		double d1 = getSignedDistance(p, plane);
		double d2 = getSignedDistance(q, plane);
		// far enough?
		if (M.kindaEquals(d1, 0) || M.kindaEquals(d2, 0)) return false;
		// same side?
		return M.sign(d1) == M.sign(d2);
	}

	// Intersection
	public static final boolean intersects(Point3D p, Plane3D plane) {
		return M.kindaEquals(getSignedDistance(p, plane), 0);
	}

	public static final boolean isParallel(Line3D line, Plane3D plane) {
		Point3D n = plane.getNormal();
		Point3D u = line.getVectorQPUnormalized_();
		double ndotu = dot(n, u);
		return M.kindaEquals(ndotu, 0);
	}

	public static final boolean intersection(Line3D line, Plane3D plane, Point3D out) {
		Point3D n = plane.getNormal();
		Point3D u = line.getVectorQPUnormalized_();
		Point3D p = line.getP();

		// test for parallelism
		double ndotu = dot(n, u);
		if (M.kindaEquals(ndotu, 0)) {
			// the line does not intersect the plane unless it intersects it fully, test if a point is on the plane
			if (intersects(p, plane)) {
				out.set(p); // this point is as good as any
				return true;
			}
			return false;
		}

		// find intersection point and return it
		Point3D v = plane.getPoint();
		double s = dot(n, sub_(v, p)) / ndotu;
		out.set(parametricPoint_(line, s));
		return true;
	}

	// return the number of collision, and sets the parametric t for the ray in out_t
	public static final int intersection(Line3D ray, Sphere sphere, double[] out_t) {
		Point3D p = ray.getP();
		Point3D q = ray.getQ();
		Point3D c = sphere.getCenter();
		double r = sphere.getRadius();
		Point3D p_q = sub_(p, q);
		Point3D p_c = sub_(p, c);
		double A = dot(p_q, p_q);
		double B = -2 * dot(p_q, p_c); // note: this differs in sign with the notes
		double C = dot(p_c, p_c) - (r * r);
		return M.quadraticRealRoots(A, B, C, out_t);
	}

	public static final boolean intersection(Line3D ray, Triangle triangle, Ptr<Double> t) {
		if (t != null) t.value = null;
		//if (isParallel(ray, V.Plane3D(triangle))) return false;
		Point3D A = triangle.getA();
		Point3D B = triangle.getB();
		Point3D C = triangle.getC();
		Point3D E = ray.getP();
		Point3D D = ray.getVectorQPUnormalized_();
		// Using Cramer's rule as shown in Fundamentals of Computer Graphics Second Edition by Peter Shirley p. 207
		// Build linear system
		// 3x3 column major
		double a = A.x - B.x;
		double b = A.y - B.y;
		double c = A.z - B.z;
		double d = A.x - C.x;
		double e = A.y - C.y;
		double f = A.z - C.z;
		double g = D.x;
		double h = D.y;
		double i = D.z;
		// 3x1 column major
		double j = A.x - E.x;
		double k = A.y - E.y;
		double l = A.z - E.z;
		// Cramer's rule
		double ei_minus_hf = e * i - h * f;
		double gf_minus_di = g * f - d * i;
		double dh_minus_eg = d * h - e * g;
		double ak_minus_jb = a * k - j * b;
		double jc_minus_al = j * c - a * l;
		double bl_minus_kc = b * l - k * c;
		double M = a * ei_minus_hf + b * gf_minus_di + c * dh_minus_eg;
		if (flux.math.M.kindaEquals(M, 0)) return false; // parralel test
		double gamma = (i * ak_minus_jb + h * jc_minus_al + g * bl_minus_kc) / M;
		// Note: the kindaEquals tests prevent ray to pass through the edge of triangle when the intersection is very close (this is necessary since my quad intersection uses triangles)
		if (gamma < 0 || gamma > 1 && !flux.math.M.kindaEquals(gamma, 0) && !flux.math.M.kindaEquals(gamma, 1)) return false;
		double beta = (j * ei_minus_hf + k * gf_minus_di + l * dh_minus_eg) / M;
		if (beta < 0 || beta > 1 - gamma && !flux.math.M.kindaEquals(beta, 0) && !flux.math.M.kindaEquals(beta, 1 - gamma)) return false;
		if (t != null) t.value = (f * ak_minus_jb + e * jc_minus_al + d * bl_minus_kc) / -M;
		return true;
	}

	public static final boolean intersection(Line3D ray, Quad quad, Ptr<Double> t) {
		// Divide the quad into two triangles and do the intersection with those
		if (G.intersection(ray, V.Triangle(quad.getA(), quad.getB(), quad.getC()), t)) return true;
		return G.intersection(ray, V.Triangle(quad.getB(), quad.getD_(), quad.getC()), t);
	}

	public static final int intersection(Line3D ray, Box box, double[] out_t, Surface[] out_surf_) {
		// Dive Box in 6 quads, and do the intersection with those
		int count = 0;
		Ptr<Double> ptr = V.PtrDouble();
		Quad tmp;
		if (G.intersection(ray, tmp = box.getFront_(), ptr)) {
			out_t[count] = ptr.value;
			out_surf_[count] = tmp;
			count++;
		}
		if (G.intersection(ray, tmp = box.getBack_(), ptr)) {
			out_t[count] = ptr.value;
			out_surf_[count] = tmp;
			count++;
		}
		if (G.intersection(ray, tmp = box.getLeft_(), ptr)) {
			out_t[count] = ptr.value;
			out_surf_[count] = tmp;
			count++;
		}
		if (G.intersection(ray, tmp = box.getRight_(), ptr)) {
			out_t[count] = ptr.value;
			out_surf_[count] = tmp;
			count++;
		}
		if (G.intersection(ray, tmp = box.getBottom_(), ptr)) {
			out_t[count] = ptr.value;
			out_surf_[count] = tmp;
			count++;
		}
		if (G.intersection(ray, tmp = box.getTop_(), ptr)) {
			out_t[count] = ptr.value;
			out_surf_[count] = tmp;
			count++;
		}
		return count;
	}

	// ==== Flavor: Allocates Memory === 
	public static final Point2D add(Point2D p, Point2D q) {
		Point2D out = new Point2D();
		add(p, q, out);
		return out;
	}

	public static final Point2D sub(Point2D p, Point2D q) {
		Point2D out = new Point2D();
		sub(p, q, out);
		return out;
	}

	public static final Point2D mul(Point2D p, double scalar) {
		Point2D out = new Point2D();
		mul(p, scalar, out);
		return out;
	}

	public static final Point2D div(Point2D p, double scalar) {
		Point2D out = new Point2D();
		div(p, scalar, out);
		return out;
	}

	public static final Point3D cross(Point3D p, Point3D q) {
		Point3D out = new Point3D();
		cross(p, q, out);
		return out;
	}

	public static final Point3D add(Point3D p, Point3D q) {
		Point3D out = new Point3D();
		add(p, q, out);
		return out;
	}

	public static final Point3D sub(Point3D p, Point3D q) {
		Point3D out = new Point3D();
		sub(p, q, out);
		return out;
	}

	public static final Point3D mul(Point3D p, double scalar) {
		Point3D out = new Point3D();
		mul(p, scalar, out);
		return out;
	}

	public static final Point3D div(Point3D p, double scalar) {
		Point3D out = new Point3D();
		div(p, scalar, out);
		return out;
	}

	public static final Point3D parametricPoint(Line3D line, double t) {
		Point3D out = new Point3D();
		parametricPoint(line, t, out);
		return out;
	}

	public static final Point3D intersection(Line3D line, Plane3D plane) {
		Point3D out = new Point3D();
		if (intersection(line, plane, out)) return out;
		return null;
	}

	public static final Point3D xintercept(Plane3D plane) {
		Point3D out = new Point3D();
		if (xintercept(plane, out)) return out;
		return null;
	}

	public static final Point3D yintercept(Plane3D plane) {
		Point3D out = new Point3D();
		if (yintercept(plane, out)) return out;
		return null;
	}

	public static final Point3D zintercept(Plane3D plane) {
		Point3D out = new Point3D();
		if (zintercept(plane, out)) return out;
		return null;
	}

	// === Flavor: Returns a volatile ===
	public static final Point2D add_(Point2D p, Point2D q) {
		Point2D out = V.Point2D(0, 0);
		add(p, q, out);
		return out;
	}

	public static final Point2D sub_(Point2D p, Point2D q) {
		Point2D out = V.Point2D(0, 0);
		sub(p, q, out);
		return out;
	}

	public static final Point2D mul_(Point2D p, double scalar) {
		Point2D out = V.Point2D(0, 0);
		mul(p, scalar, out);
		return out;
	}

	public static final Point2D div_(Point2D p, double scalar) {
		Point2D out = V.Point2D(0, 0);
		div(p, scalar, out);
		return out;
	}

	public static final Point3D cross_(Point3D p, Point3D q) {
		Point3D out = V.Point3D(0, 0, 0);
		cross(p, q, out);
		return out;
	}

	public static final Point3D add_(Point3D p, Point3D q) {
		Point3D out = V.Point3D(0, 0, 0);
		add(p, q, out);
		return out;
	}

	public static final Point3D sub_(Point3D p, Point3D q) {
		Point3D out = V.Point3D(0, 0, 0);
		sub(p, q, out);
		return out;
	}

	public static final Point3D mul_(Point3D p, double scalar) {
		Point3D out = V.Point3D(0, 0, 0);
		mul(p, scalar, out);
		return out;
	}

	public static final Point3D div_(Point3D p, double scalar) {
		Point3D out = V.Point3D(0, 0, 0);
		div(p, scalar, out);
		return out;
	}

	public static final Point3D parametricPoint_(Line3D line, double t) {
		Point3D out = V.Point3D(0, 0, 0);
		parametricPoint(line, t, out);
		return out;
	}

	public static final Point3D intersection_(Line3D line, Plane3D plane) {
		Point3D out = V.Point3D(0, 0, 0);
		if (intersection(line, plane, out)) return out;
		return null;
	}

	public static final Point3D xintercept_(Plane3D plane) {
		Point3D out = V.Point3D(0, 0, 0);
		if (xintercept(plane, out)) return out;
		return null;
	}

	public static final Point3D yintercept_(Plane3D plane) {
		Point3D out = V.Point3D(0, 0, 0);
		if (yintercept(plane, out)) return out;
		return null;
	}

	public static final Point3D zintercept_(Plane3D plane) {
		Point3D out = V.Point3D(0, 0, 0);
		if (zintercept(plane, out)) return out;
		return null;
	}

}
