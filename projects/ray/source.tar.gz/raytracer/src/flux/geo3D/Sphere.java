/*
 * Written by David Lareau.
 * 
 * A sphere.
 */
package flux.geo3D;

import java.io.PrintStream;

import flux.material.Surface;

public class Sphere extends Surface {

	// Attributes
	private Point3D center;
	private double radius;

	// Construct
	public Sphere(Point3D center_, double radius) {
		this.center = new Point3D(center_);
		this.radius = radius;
	}

	public Sphere(Sphere copy) {
		this.center = new Point3D(copy.center);
		this.radius = copy.radius;
		this.setMaterial(copy.getMaterial());
	}

	public boolean _equals(Surface other, PrintStream out) {
		if (!(other instanceof Sphere)) {
			if (out != null) out.println("Different class: " + this.getClass() + " " + other.getClass());
			return false;
		}
		Sphere o = (Sphere) other;
		if (!center.equals(o.center)) {
			if(out != null) out.println("Sphere center mismatch: " + center + " " + o.center);
			return false;
		}
		if (radius != o.radius) {
			if(out != null) out.println("Sphere radius mismatch: " + radius + " " + o.radius);
			return false;
		}
		return true;
	}

	// Methods
	public Point3D getCenter() {
		return center;
	}

	public double getRadius() {
		return radius;
	}

	public Point3D getNormal_(Point3D impact_, Point3D eye_) {
		// ignore eye, assume the impact point is in direction of eye
		Point3D n = G.sub_(impact_, center);
		n.normalizeInPlace();
		return n;
	}

	protected Surface _copy() {
		return new Sphere(this);
	}

}
