package flux.text;

import java.awt.Color;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import flux.geo3D.Point3D;
import flux.material.Material;
import flux.mem.V;
import flux.util.C;

public class Parse {

	public static Point3D point3D_(String input) {
		// Input: "(1.2,3.5,5.5)"
		Pattern pattern = Pattern.compile("\\((.*),(.*),(.*)\\)");
		Matcher matcher = pattern.matcher(input);
		boolean matchFound = matcher.find();
		if (!matchFound) throw new RuntimeException("Malformed Point3D: " + input);
		double x = Double.parseDouble(matcher.group(1));
		double y = Double.parseDouble(matcher.group(2));
		double z = Double.parseDouble(matcher.group(3));
		return V.Point3D(x, y, z);
	}

	public static int color(String input) {
		// Input: "rgb(255,0,0)"
		Pattern pattern = Pattern.compile("rgb\\((.*),(.*),(.*)\\)");
		Matcher matcher = pattern.matcher(input);
		boolean matchFound = matcher.find();
		if (!matchFound) throw new RuntimeException("Malformed color: " + input);
		int r = Integer.parseInt(matcher.group(1));
		int g = Integer.parseInt(matcher.group(2));
		int b = Integer.parseInt(matcher.group(3));
		return C.rgb(r, g, b);
	}

	public static boolean isMaterial(String input) {
		return input.startsWith("rgb(") || input.startsWith("phong(");
	}

	public static Material material(String input) {
		Material material = new Material();
		if (input.startsWith("rgb(")) {
			material.color = new Color(Parse.color(input));
			material.type = Material.SIMPLE;
		}
		else if (input.startsWith("phong(")) {
			Pattern pattern = Pattern.compile("phong\\((.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)\\)");
			Matcher matcher = pattern.matcher(input);
			boolean matchFound = matcher.find();
			if (!matchFound) throw new RuntimeException("Malformed phong: " + input);
			material.ambient = new double[] { Double.parseDouble(matcher.group(1)), Double.parseDouble(matcher.group(2)), Double.parseDouble(matcher.group(3)) };
			material.diffuse = new double[] { Double.parseDouble(matcher.group(4)), Double.parseDouble(matcher.group(5)), Double.parseDouble(matcher.group(6)) };
			material.specular = new double[] { Double.parseDouble(matcher.group(7)), Double.parseDouble(matcher.group(8)), Double.parseDouble(matcher.group(9)) };
			material.shininess = Double.parseDouble(matcher.group(10));
			material.type = Material.PHONG;
			// for debug purposes I also set color
			material.color = new Color(C.rgbNormalizedInput(material.diffuse[0], material.diffuse[1], material.diffuse[2]));
		}
		else if (input.startsWith("cook(")) {
			Pattern pattern = Pattern.compile("cook\\((.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*),(.*)\\)");
			Matcher matcher = pattern.matcher(input);
			boolean matchFound = matcher.find();
			if (!matchFound) throw new RuntimeException("Malformed cook: " + input);
			material.cook_ambiant = Double.parseDouble(matcher.group(1));
			material.cook_diffuse = Double.parseDouble(matcher.group(2));
			material.cook_specular = Double.parseDouble(matcher.group(3));
			material.cook_colorCoefficient = new double[] { Double.parseDouble(matcher.group(4)), Double.parseDouble(matcher.group(5)), Double.parseDouble(matcher.group(6)) };
			material.cook_indexOfRefraction = new double[] { Double.parseDouble(matcher.group(7)), Double.parseDouble(matcher.group(8)), Double.parseDouble(matcher.group(9)) };
			material.cook_w = new double[] { Double.parseDouble(matcher.group(10)), Double.parseDouble(matcher.group(12)) };
			material.cook_m = new double[] { Double.parseDouble(matcher.group(11)), Double.parseDouble(matcher.group(13)) };
			material.type = Material.COOK;
			// for debug purposes I also set color
			material.color = new Color(C.rgbNormalizedInput(material.cook_colorCoefficient[0], material.cook_colorCoefficient[1], material.cook_colorCoefficient[2]));
		}

		return material;
	}
}
