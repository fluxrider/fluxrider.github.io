/* 
 * Written by David Lareau on May 8, 2009
 * 
 * Simply filters supported image file format.
 * 
 * Note: I'd would have prefered if parent class would have been an interface.
 */

package flux.ui;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.filechooser.FileFilter;

public class ImageFileFilter extends FileFilter {

	// Attributes
	private List<String> extensions;
	private boolean acceptDirectories;

	// Construct
	public ImageFileFilter(boolean acceptDirectories) {
		this.acceptDirectories = acceptDirectories;
		extensions = Arrays.asList(ImageIO.getReaderFileSuffixes());
	}

	// FileFilter
	public boolean accept(File f) {
		if (f.isDirectory()) return acceptDirectories;
		String name = f.getName().toLowerCase();
		for (String extension : extensions) {
			if (name.endsWith(extension)) return true;
		}
		return false;
	}

	public String getDescription() {
		return "Images";
	}

}
