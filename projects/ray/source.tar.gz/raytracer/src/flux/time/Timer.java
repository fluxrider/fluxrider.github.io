/* 
 * Written by David Lareau on June 29, 2009
 *
 * Small utility that helps with indicating how much time has passed
 */
package flux.time;

public class Timer {

	// Attributes
	public long t0;

	public long lastCheck;

	public Timer() {
		reset();
	}

	public void reset() {
		t0 = System.currentTimeMillis();
		lastCheck = t0;
	}

	public boolean lastCheck(long interval) {
		long now = System.currentTimeMillis();
		if (lastCheck + interval > now) return false;
		lastCheck = now;
		return true;
	}

	public long deltaCheck() {
		long now = System.currentTimeMillis();
		long delta = now - lastCheck;
		lastCheck = now;
		return delta;
	}
	
	public long deltaCheckPassive() {
		long now = System.currentTimeMillis();
		long delta = now - lastCheck;
		return delta;
	}

	public long elapsed() {
		return System.currentTimeMillis() - t0;
	}

	public String toString() {
		long t = elapsed();
		return T.minutes(t, false) + ":" + T.seconds(t, true);
	}

}
