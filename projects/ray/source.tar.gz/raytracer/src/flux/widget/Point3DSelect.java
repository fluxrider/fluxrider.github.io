/*
 * Written by David Lareau on February 12, 2012.
 * 
 * A widget to select the coordinated of a point in 3D space.
 * Currently, its a x/z 2D selection + a y slider.
 * The values are bounded. 
 */
package flux.widget;

import java.awt.BorderLayout;
import java.util.LinkedList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import flux.geo2D.Point2D;
import flux.geo3D.Point3D;

public class Point3DSelect extends JPanel implements ChangeListener, SimpleNoticeListener {

	// Attributes
	private Point2DSelect xz;
	private JSlider y;
	private double minY;
	private double maxY;
	private int sliderFixedPoint = 100;

	private Point3D p;

	public List<SimpleNoticeListener> listeners = new LinkedList<SimpleNoticeListener>();

	// Construct
	public Point3DSelect(double x, double y, double z, double minX, double maxX, double minY, double maxY, double minZ, double maxZ) {
		this.p = new Point3D();

		// Create
		this.xz = new Point2DSelect(x, z, minX, maxX, minZ, maxZ);
		this.y = new JSlider(JSlider.VERTICAL, (int) (minY * sliderFixedPoint), (int) (maxY * sliderFixedPoint), (int) (y * sliderFixedPoint)); // since JSlider use int only, I'm faking double with it by adding fixed size multiplier
		this.y.addChangeListener(this);
		this.xz.listeners.add(this);

		// Layout
		this.setLayout(new BorderLayout());
		this.add(this.xz, BorderLayout.CENTER);
		this.add(this.y, BorderLayout.EAST);
	}

	// Methods	
	public void set(double x, double y, double z) {
		this.xz.set(x, z);
		this.y.setValue((int) (y * sliderFixedPoint));
		for (SimpleNoticeListener listener : listeners) {
			listener.simpleNotice(this);
		}
	}

	public void set(Point3D p_) {
		set(p_.x, p_.y, p_.z);
	}

	public Point3D get() {
		p.set(xz.get().x, y.getValue() / (double) sliderFixedPoint, xz.get().y);
		return p;
	}

	public void stateChanged(ChangeEvent e) {
		simpleNotice(e.getSource());
	}

	// SimpleNoticeListener
	public void simpleNotice(Object source) {
		// just warn all my listeners
		for (SimpleNoticeListener listener : listeners) {
			listener.simpleNotice(this);
		}
	}

	// Main
	public static void main(String[] args) {
		JFrame frame = new JFrame("Point3DSelect");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(100, 100, 800, 600);
		frame.setContentPane(new Point3DSelect(0, 0, 0, 0, 10, 0, 10, 0, 10));
		frame.setVisible(true);
	}

}
