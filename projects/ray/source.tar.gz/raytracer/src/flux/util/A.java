package flux.util;

public class A {

	public static final double[] copy(double[] t) {
		if (t == null) return null;
		double[] v = new double[t.length];
		for (int i = 0; i < t.length; i++) {
			v[i] = t[i];
		}
		return v;
	}

	public static final boolean equals(double[] a, double[] b) {
		if (a == null && b == null) return true;
		if (a == null || b == null) return false;
		if (a.length != b.length) return false;
		for (int i = 0; i < a.length; i++) {
			if (a[i] != b[i]) return false;
		}
		return true;
	}

}
