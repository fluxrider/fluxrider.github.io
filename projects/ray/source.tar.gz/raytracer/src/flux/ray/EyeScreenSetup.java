/*
 * Written by David Lareau on February 13, 2012.
 * 
 * A basic eye, screen setup for ray tracing.
 * The positions are set with widgets, and the setup preview is shown in a panel.
 * 
 * Note: The Geo3DFramework I wrote in the past, and that I am reusing here is kinda weird. The framework itself is neither a panel nor a frame
 */
package flux.ray;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;

import javax.imageio.ImageIO;
import javax.media.opengl.GL2;
import javax.media.opengl.awt.GLJPanel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import flux.geo3D.Box;
import flux.geo3D.G;
import flux.geo3D.Line3D;
import flux.geo3D.Plane3D;
import flux.geo3D.Point3D;
import flux.geo3D.Quad;
import flux.geo3D.Sphere;
import flux.geo3D.Triangle;
import flux.material.Material;
import flux.material.Surface;
import flux.math.M;
import flux.mem.Ptr;
import flux.mem.V;
import flux.opengl.Geo3DFramework;
import flux.random.R;
import flux.ray.scene.PointLight;
import flux.ray.scene.QuadLight;
import flux.ray.scene.Scene;
import flux.text.Parse;
import flux.time.T;
import flux.time.Timer;
import flux.ui.UI;
import flux.util.C;
import flux.widget.Point3DSelect;
import flux.widget.SimpleNoticeListener;

public class EyeScreenSetup extends Geo3DFramework implements KeyEventDispatcher, SimpleNoticeListener, ActionListener {

	// Attributes
	private JFrame frame;
	private Point3DSelect eye;
	private Point3DSelect screenTopLeft;
	private Point3DSelect screenTopRight;
	private Point3DSelect screenBottomLeft;
	private JTextField previewW, previewH;
	private JTextField W, H;
	private JButton render;
	private JButton open;
	private JCheckBox perspective;
	private JCheckBox attenuate;
	private JTextField bounce;
	private JTextField monte;

	// Scene
	//private Sphere sphere;
	//private Triangle triangle;
	//private Quad quad;
	//private Box box;
	private Scene scene;

	// Construct
	public EyeScreenSetup(GLJPanel glPanel) {
		super(glPanel, true);

		// Create
		eye = new Point3DSelect(0, 0, 7, -10, 10, -10, 10, -10, 10);
		screenTopLeft = new Point3DSelect(-.5, .5, 4, -10, 10, -10, 10, -10, 10);
		screenTopRight = new Point3DSelect(.5, .5, 4, -10, 10, -10, 10, -10, 10);
		screenBottomLeft = new Point3DSelect(-.5, -.5, 4, -10, 10, -10, 10, -10, 10);
		W = new JTextField("256");
		H = new JTextField("256");
		previewW = new JTextField("5");
		previewH = new JTextField("5");
		open = new JButton("Open");
		render = new JButton("Render");
		perspective = new JCheckBox("Perspective", true);
		attenuate = new JCheckBox("Attenuate", true);
		bounce = new JTextField("0");
		monte = new JTextField("35");

		// Layout
		JPanel eyeScreen = new JPanel(new GridLayout(2, 2));
		eyeScreen.add(eye);
		eyeScreen.add(screenTopLeft);
		eyeScreen.add(screenTopRight);
		eyeScreen.add(screenBottomLeft);
		JPanel resolution = new JPanel(new GridLayout(1, 2));
		resolution.add(W);
		resolution.add(H);
		JPanel resolutionPreview = new JPanel(new GridLayout(1, 2));
		resolutionPreview.add(previewW);
		resolutionPreview.add(previewH);
		JPanel controls = new JPanel(new BorderLayout());
		controls.add(resolution, BorderLayout.SOUTH);
		controls.add(eyeScreen, BorderLayout.CENTER);
		controls.add(resolutionPreview, BorderLayout.NORTH);

		JPanel southland = new JPanel(new FlowLayout());
		southland.add(open);
		southland.add(render);
		southland.add(perspective);
		southland.add(attenuate);
		southland.add(bounce);
		southland.add(monte);

		JPanel panel = new JPanel(new BorderLayout());
		panel.add(glPanel, BorderLayout.CENTER);
		panel.add(controls, BorderLayout.EAST);
		panel.add(southland, BorderLayout.SOUTH);

		// Events
		eye.listeners.add(this);
		screenTopLeft.listeners.add(this);
		screenTopRight.listeners.add(this);
		screenBottomLeft.listeners.add(this);
		open.addActionListener(this);
		render.addActionListener(this);

		// Frame
		frame = new JFrame("Simple Eye Screen Setup");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		UI.setCenteredBounds(frame, .55, -.20);
		frame.setContentPane(panel);
		frame.setVisible(true);

		// Scene
		this.scale = .2;
		//this.sphere = new Sphere(V.Point3D(0, 0, 0), .5);
		//this.triangle = new Triangle(V.Point3D(0, .5, 0), V.Point3D(-.5, -.5, 0), V.Point3D(.5, -.5, 0));
		//this.quad = new Quad(V.Point3D(0, .5, 0), V.Point3D(-.5, -.5, 0), V.Point3D(.5, -.5, 0));
		//this.box = new Box(V.Point3D(0, 0, 0), V.Point3D(0, 0, .5), V.Point3D(.5, 0, 0), V.Point3D(0, .5, 0));
		this.scene = new Scene();
	}

	public void open() {
		try {
			// OpenFile Dialog
			JFileChooser chooser = new JFileChooser("./res");
			FileNameExtensionFilter filter = new FileNameExtensionFilter("Scene files", "scene");
			chooser.setFileFilter(filter);
			int returnVal = chooser.showOpenDialog(frame);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				File file = chooser.getSelectedFile();
				BufferedReader in = new BufferedReader(new InputStreamReader(new FileInputStream(file)));

				String line;
				while ((line = in.readLine()) != null) {
					// Parse SCENE
					if (line.equals("SCENE")) {
						scene.reset();
						line = scene.parse(in);
					}
					if (line == null) break;

					// Parse CAMERA
					String[] parts = line.split("\\s");
					if (line.startsWith("eye ")) {
						Point3D p = Parse.point3D_(parts[1]);
						eye.set(p);
					} else if (line.startsWith("screenTopLeft ")) {
						Point3D p = Parse.point3D_(parts[1]);
						screenTopLeft.set(p);
					} else if (line.startsWith("screenTopRight ")) {
						Point3D p = Parse.point3D_(parts[1]);
						screenTopRight.set(p);
					} else if (line.startsWith("screenBottomLeft ")) {
						Point3D p = Parse.point3D_(parts[1]);
						screenBottomLeft.set(p);
					} else if (line.startsWith("perspective ")) {
						this.perspective.setSelected(Boolean.parseBoolean(parts[1]));
					} else {
						System.err.println("Unhandled line while parsing file: " + line);
					}

				}

				repaint();

			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Geo3DFramework
	protected void render(GL2 gl) {
		Point3D realEye = this.eye.get();
		Point3D screenTopLeft = this.screenTopLeft.get();
		Point3D screenBottomLeft = this.screenBottomLeft.get();
		Point3D screenTopRight = this.screenTopRight.get();
		int H = Integer.parseInt(this.previewH.getText());
		int W = Integer.parseInt(this.previewW.getText());

		// Eye
		point(gl, realEye, Color.BLUE, 5);

		// Screen
		this.quad(gl, screenTopLeft, screenBottomLeft, screenTopRight, Color.CYAN, Color.ORANGE);

		// Scene Preview
		//this.box(gl, V.Point3D(0, 0, 0), V.Point3D(0, 0, 1), V.Point3D(1, 0, 0), V.Point3D(0, 1, 0), Color.RED, Color.GREEN, Color.BLUE, Color.CYAN, Color.YELLOW, Color.MAGENTA);
		//sphere(gl, sphere, Color.RED);
		//triangle(gl, triangle, Color.RED, Color.GREEN);
		//quad(gl, quad, Color.RED, Color.GREEN);
		//box(gl, box, Color.RED, Color.GREEN, Color.BLUE, Color.CYAN, Color.YELLOW, Color.MAGENTA);
		for (Object object : scene.getObjects()) {
			if (object instanceof Sphere) {
				Sphere surface = (Sphere) object;
				sphere(gl, surface, surface.getMaterial().color);
			} else if (object instanceof Quad) {
				Quad surface = (Quad) object;
				Color color = surface.getMaterial().color;
				quad(gl, surface, color, color);
			} else if (object instanceof Triangle) {
				Triangle surface = (Triangle) object;
				Color color = surface.getMaterial().color;
				triangle(gl, surface, color, color);
			} else if (object instanceof Box) {
				Box box = (Box) object;
				Color front = box.getMaterial(Box.FRONT).drawInPreview ? box.getMaterial(Box.FRONT).color : null;
				Color back = box.getMaterial(Box.BACK).drawInPreview ? box.getMaterial(Box.BACK).color : null;
				Color top = box.getMaterial(Box.TOP).drawInPreview ? box.getMaterial(Box.TOP).color : null;
				Color bottom = box.getMaterial(Box.BOTTOM).drawInPreview ? box.getMaterial(Box.BOTTOM).color : null;
				Color left = box.getMaterial(Box.LEFT).drawInPreview ? box.getMaterial(Box.LEFT).color : null;
				Color right = box.getMaterial(Box.RIGHT).drawInPreview ? box.getMaterial(Box.RIGHT).color : null;
				box(gl, box, front, back, top, bottom, left, right);
			}
		}

		for (Object light : scene.getLights()) {
			if (light instanceof Point3D) {
				point(gl, (Point3D) light, Color.YELLOW, 50);
			}
		}

		// Ray
		Line3D dx = new Line3D(screenTopLeft, screenTopRight);
		Line3D dy = new Line3D(screenTopLeft, screenBottomLeft);
		Ptr<Double> ptrT = new Ptr<Double>();
		Ptr<Surface> ptrSurface = new Ptr<Surface>();
		Point3D p = new Point3D();
		Point3D normal = new Point3D();

		// Orthographic 
		boolean orthographic = !perspective.isSelected();
		Point3D orthoEye = new Point3D();
		Point3D orthoNormal = G.cross(G.sub_(screenBottomLeft, screenTopLeft), G.sub_(screenTopRight, screenTopLeft));
		orthoNormal.normalizeInPlace();

		for (int y = 1; y <= H; y++) {
			for (int x = 1; x <= W; x++) {
				Point3D screen = G.sub_(G.add_(G.parametricPoint_(dx, x / (double) (W + 1)), G.parametricPoint_(dy, y / (double) (H + 1))), screenTopLeft);
				point(gl, screen, Color.RED, 10);
				if (orthographic) orthoEye.set(G.add_(screen, orthoNormal));
				Point3D eye = orthographic ? orthoEye : realEye;
				Line3D ray = V.Line3D(eye, screen);

				// Test where ray intersects first in scene
				if (scene.hit(ray, 1, ptrT, ptrSurface, null)) {
					double t = ptrT.value;
					Surface _surface = ptrSurface.value;
					Surface surface = _surface.copy(); // mimic copy from real render function

					// Draw ray to object 
					Point3D impact = G.parametricPoint(ray, t);
					point(gl, impact, Color.GRAY, 10);
					line(gl, eye, impact, Color.GREEN, 1);
					p.set(impact);
					normal.set(surface.getNormal_(impact, eye));

					line(gl, p, G.add_(p, normal), Color.BLACK, 1);

					// Test if impact point can see a point light
					for (Object light_ : scene.getLights()) {
						if (light_ instanceof PointLight) {
							Point3D light = (Point3D) light_;
							ray = V.Line3D(p, light);
							Plane3D plane = surface.getPlane_(p, eye);

							boolean inDirectIllumination = G.areSameSideOfAndBothFarEnough(eye, light, plane) && (!scene.hit(ray, M.EPSILON, ptrT, ptrSurface, surface) || M.kindaGreaterOrEqual(ptrT.value, 1));

							// Draw the ray from the impact point to the light if in direct illumination
							if (inDirectIllumination) {
								line(gl, p, light, Color.YELLOW, 1);
								//System.out.println("direct: " + ray);
								// what is elevation?
								//Point3D in = G.sub_(light, impact);
								//in.normalizeInPlace();
								//double elevationIn = G.angle(light, impact, G.add_(impact, normal));
								//double c = Math.cos(elevationIn) * 255;
								//line(gl, p, light, new Color(255, (int) c, (int) c), 1);

							} else {
								//line(gl, p, light, Color.MAGENTA, 1);
								//if (!(ptrT.value > 0.001 && ptrT.value < 0.999)) {
								//	System.out.println("no: " + ray);
								//	System.out.println(" t: " + ptrT.value);
								//	System.out.println(" o: " + ptrSurface.value);
								//}
							}
						}
					}

					// Gen 5 random rays from this impact point, to visualize the indirect lighting rays
					// only do this for impact points that are on the grounds
					/*
					if (M.kindaEquals(impact.y, 0)) {
						Plane3D plane = new Plane3D(surface.getPlane_(impact, eye));
						Point3D n = plane.getNormal();
						Point3D incomingPoint = new Point3D();
						for (int m = 0; m < 500; m++) {
							// generate a random ray from this impact point (in impact hemisphere)
							Point3D r;
							do {
								r = R.sphere_();
							} while (!G.areSameSideOf(G.add_(impact, r), G.add_(impact, n), plane));
							Line3D incomingRay = new Line3D(impact, r);
							if (scene.hit(incomingRay, M.EPSILON, _getPower_ptrT, _getPower_ptrSurface, surface)) {
								incomingPoint.set(G.parametricPoint_(incomingRay, _getPower_ptrT.value));
								line(gl, incomingPoint, impact, Color.MAGENTA, 1);
							}
						}
					}
					*/

				}

			}
		}
	}

	public void render() {
		Point3D realEye = this.eye.get();
		Point3D screenTopLeft = this.screenTopLeft.get();
		Point3D screenBottomLeft = this.screenBottomLeft.get();
		Point3D screenTopRight = this.screenTopRight.get();
		int H = Integer.parseInt(this.H.getText());
		int W = Integer.parseInt(this.W.getText());

		// Ray Tracing
		Line3D dx = new Line3D(screenTopLeft, screenTopRight);
		Line3D dy = new Line3D(screenTopLeft, screenBottomLeft);
		Ptr<Double> ptrT = new Ptr<Double>();
		Ptr<Surface> ptrSurface = new Ptr<Surface>();
		Point3D impact = new Point3D();

		// Orthographic 
		boolean orthographic = !perspective.isSelected();
		Point3D orthoEye = new Point3D();
		Point3D orthoNormal = G.cross(G.sub_(screenBottomLeft, screenTopLeft), G.sub_(screenTopRight, screenTopLeft));
		orthoNormal.normalizeInPlace();

		// Color (I'm using an array of wavelenghts, which I will combine later to make the final image assuming they are r,g,b.
		// I won't run the ray tracer three times, I'll let the getPower function deal with all wavelenghts at once
		double wavelenghts[] = new double[3];
		wavelenghts[0] = 650; // red
		wavelenghts[1] = 510; // green
		wavelenghts[2] = 475; // blue
		double powers[] = new double[wavelenghts.length];
		double directPowers[] = new double[wavelenghts.length];
		double indirectPowers[] = new double[wavelenghts.length];

		// create render surface
		BufferedImage image = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
		BufferedImage channels[] = new BufferedImage[wavelenghts.length];
		for (int i = 0; i < wavelenghts.length; i++) {
			channels[i] = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
		}
		BufferedImage direct = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
		BufferedImage indirect = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);

		Timer timer = new Timer();
		for (int y = 1; y <= H; y++) {
			for (int x = 1; x <= W; x++) {
				// Progress
				int step = (y - 1) * W + (x - 1);
				int total = W * H;
				double progress = step / (double) total;
				if (timer.lastCheck(1000)) {
					long estimateDuration = (long) (timer.elapsed() / progress);
					System.out.println(T.text(timer.elapsed()) + "   (" + (x - 1) + "," + (y - 1) + ")   progress=" + progress + " estimateTotal=" + T.text(estimateDuration) + " remaining=" + T.text(estimateDuration - timer.elapsed()));
				}

				// Build Ray
				Point3D screen = G.sub_(G.add_(G.parametricPoint_(dx, x / (double) (W + 1)), G.parametricPoint_(dy, y / (double) (H + 1))), screenTopLeft);
				if (orthographic) orthoEye.set(G.add_(screen, orthoNormal));
				Point3D eye = orthographic ? orthoEye : realEye;
				Line3D ray = V.Line3D(eye, screen);

				// Test where ray intersects first in scene
				if (scene.hit(ray, 1, ptrT, ptrSurface, null)) {
					double t = ptrT.value;
					Surface surface = ptrSurface.value;
					impact.set(G.parametricPoint_(ray, t));

					//Material material = surface.getMaterial();
					//Color materialColor = material.getColor();

					// == 0) No lights: output color is material color ==
					//Color color = material.getColor();

					// == 0.5) Cheap Direction Illumination: output color is material color only if surface is under direct illumination
					// Test if impact point can see a point light
					/*
					color = Color.BLACK;
					for (Object light_ : scene.getLights()) {
						Point3D light = (Point3D) light_;
						ray = V.Line3D(impact, light);
						Plane3D plane = surface.getPlane_(impact, eye);
						boolean inDirectIllumination = G.areSameSideOfAndBothFarEnough(eye, light, plane) && (!scene.hit(ray, M.EPSILON, ptrT, ptrSurface, surface) || M.kindaGreaterOrEqual(ptrT.value, 1));
						if (inDirectIllumination) {
							color = material.getColor();
						}
					}
					*/

					// Looking at an object (light or not)
					int ttl = Integer.parseInt(bounce.getText());
					getPower(impact, surface, eye, ttl, wavelenghts, directPowers, indirectPowers);
					for (int i = 0; i < wavelenghts.length; i++) {
						powers[i] = directPowers[i] + indirectPowers[i];
					}

					// output on my different images
					image.setRGB(x - 1, y - 1, C.rgbNormalizedInputDX(powers));
					for (int i = 0; i < wavelenghts.length; i++) {
						channels[i].setRGB(x - 1, y - 1, C.rgbNormalizedInputDX(powers[i], powers[i], powers[i]));
					}
					direct.setRGB(x - 1, y - 1, C.rgbNormalizedInputDX(directPowers));
					indirect.setRGB(x - 1, y - 1, C.rgbNormalizedInputDX(indirectPowers));

				} else {
					// background color for ray that reach the nothing
					image.setRGB(x - 1, y - 1, C.rgb(100, 100, 255));
					direct.setRGB(x - 1, y - 1, C.rgb(100, 100, 255));
					indirect.setRGB(x - 1, y - 1, C.rgb(100, 100, 255));
					for (int i = 0; i < wavelenghts.length; i++) {
						channels[i].setRGB(x - 1, y - 1, C.rgb(100, 100, 255));
					}
				}

			}
		}

		// Save image
		try {
			StringBuilder filename = new StringBuilder();
			filename.append("out/");
			filename.append(System.currentTimeMillis());
			filename.append("_");
			filename.append(W);
			filename.append("x");
			filename.append(H);
			filename.append("_ttl");
			filename.append(bounce.getText());
			filename.append("_m");
			filename.append(monte.getText());
			if (attenuate.isSelected()) filename.append("_a");
			if (!perspective.isSelected()) filename.append("_o");
			filename.append("_");
			String tmp = filename.toString();
			filename.append(T.minutes(timer.elapsed(), false));
			filename.append("m");
			filename.append(T.seconds(timer.elapsed(), true));
			filename.append("s");
			filename.append(".png");

			File file = new File(filename.toString());
			System.out.println("Saving file to: " + file.getName());
			ImageIO.write(image, "png", new FileOutputStream(file));
			System.out.println("DONE");
			System.out.println("Saving aux files");
			ImageIO.write(direct, "png", new FileOutputStream(new File(tmp + "direct.png")));
			ImageIO.write(indirect, "png", new FileOutputStream(new File(tmp + "indirect.png")));
			for (int i = 0; i < wavelenghts.length; i++) {
				ImageIO.write(channels[i], "png", new FileOutputStream(new File(tmp + "channel" + i + ".png")));
			}
			System.out.println("DONE");
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println(T.text(timer.elapsed()));
	}

	// Buffers for getPower
	private Ptr<Double> _getPower_ptrT = new Ptr<Double>();
	private Ptr<Surface> _getPower_ptrSurface = new Ptr<Surface>();
	private Ptr<Double> _getPower_elevation = new Ptr<Double>();
	private Ptr<Double> _getPower_azymuth = new Ptr<Double>();

	private void getPower(Point3D impact, Surface surface_, Point3D outPoint, int ttl, double wavelenghts[], double outDirectPowers[], double outIndirectPowers[]) {
		Arrays.fill(outDirectPowers, 0);
		Arrays.fill(outIndirectPowers, 0);

		// Special case, looking directly at a light (a quad light, since its the only physical light I support)
		if (surface_.getMaterial().type == Material.LIGHT) {
			QuadLight light = (QuadLight) surface_;
			double power = light.getPointPower();
			for (int i = 0; i < wavelenghts.length; i++) {
				outDirectPowers[i] = power;
			}
			return;
		}

		Surface surface = surface_.copy(); // Bizarly enough, the surface changes in some loops, but I can't pinpoint where, so I'm making a copy

		boolean attenuate = this.attenuate.isSelected();

		Material material = surface.getMaterial();

		Plane3D plane = new Plane3D(surface.getPlane_(impact, outPoint));
		Point3D n = plane.getNormal();

		// compute elevation and azymuth of outgoing ray
		Point3D out = G.sub(outPoint, impact);
		out.normalizeInPlace();
		double elevationOut = G.angle(outPoint, impact, G.add_(impact, n));
		double azymuthOut = 0; // I don't have any idea how to normalize this, so I'm going to say that the outgoing azymuth is always 0, and incoming is relative to outgoing
		Point3D projOut = new Point3D(plane.project_(outPoint));

		// buffer
		double brdf[] = new double[wavelenghts.length];
		double dout[] = new double[wavelenghts.length];

		// == 1) Direct Illumination
		// for each light in the scene
		for (Object light_ : scene.getLights()) {
			// Point Light
			if (light_ instanceof PointLight) {
				PointLight light = (PointLight) light_;
				double lightPower = light.getPower();
				if (attenuate) lightPower = PointLight.attenuatePower(lightPower, light, impact);
				directIllumination(impact, light, out, plane, surface, n, dout, attenuate, brdf, wavelenghts, elevationOut, azymuthOut, projOut, lightPower);
				for (int i = 0; i < wavelenghts.length; i++) {
					outDirectPowers[i] += dout[i];
				}
			}
			// Rectangular Light
			else if (light_ instanceof QuadLight) {
				QuadLight light = (QuadLight) light_;
				// I will sample some point light from this quad light and compute the integral using monte carle integration to estimate all the sample contributions
				double lightPower = light.getPointPower();

				int monteCarloN = Integer.parseInt(monte.getText()); // number of monte carlo iteration (number of random rays)
				double monteCarloSum[] = new double[wavelenghts.length];
				double probOfRay = 1 / G.area(light);

				for (int m = 0; m < monteCarloN; m++) {
					Point3D pointLight = R.quad_(light);
					directIllumination(impact, pointLight, out, plane, surface, n, dout, false, brdf, wavelenghts, elevationOut, azymuthOut, projOut, lightPower);
					for (int i = 0; i < wavelenghts.length; i++) {
						monteCarloSum[i] += dout[i] / probOfRay;
					}
				}
				// add estimate integral value to power
				for (int i = 0; i < wavelenghts.length; i++) {
					outDirectPowers[i] += monteCarloSum[i] / monteCarloN;
				}
			}

		}

		// == 2) Indirect Illumination: use monte carlo integration to find the power transfered to this point from all surface around me
		if (ttl > 0) {
			double bouncePower[] = new double[wavelenghts.length];
			double bounceDirectPower[] = new double[wavelenghts.length];
			double bounceIndirectPower[] = new double[wavelenghts.length];

			int monteCarloN = Integer.parseInt(monte.getText()); // number of monte carlo iteration (number of random rays)
			double monteCarloSum[] = new double[wavelenghts.length];
			//double probOfRay = 1 / (2 * Math.PI); // hemisphere surface area
			//double probOfRay = 1 / (Math.PI); // hemisphere surface area (2d function: azymuth x elevation = 2Pi x 1/2Pi = PI
			double probOfRay = 1; // ... I don't understand the probability anymore. I thought I needed to dive by the area of the surface (in this case the hemisphere) but results say otherwise

			Point3D incomingPoint = new Point3D();
			int lostInSpace = 0;

			double localPower[] = new double[wavelenghts.length];
			int ignoredRay = 0;
			for (int m = 0; m < monteCarloN; m++) {
				// generate a random ray from this impact point (in impact hemisphere)
				Point3D r;
				do {
					r = R.sphere_();
				} while (!G.areSameSideOf(G.add_(impact, r), G.add_(impact, n), plane));
				Line3D incomingRay = new Line3D(impact, r);

				// if this ray hits something, what is the power at that other impact point, and how much is transfered to me?
				if (scene.hit(incomingRay, M.EPSILON, _getPower_ptrT, _getPower_ptrSurface, surface)) {
					Surface indirectSurface = _getPower_ptrSurface.value;

					// ignore rays that hit lights
					if (indirectSurface instanceof QuadLight) {
						ignoredRay++;
						for (int i = 0; i < wavelenghts.length; i++) {
							localPower[i] = 0;
						}
					} else {
						incomingPoint.set(G.parametricPoint_(incomingRay, _getPower_ptrT.value));
						// first thing, we compute elevation and azymuth of this ray
						Point3D in = G.sub_(incomingPoint, impact);
						in.normalizeInPlace();
						double elevationIn = G.angle(incomingPoint, impact, G.add_(impact, n));
						Point3D projIn = plane.project_(incomingPoint);
						double azymuthIn = G.angle(projOut, impact, projIn);

						// recursive call to know what is the power at that other impact point
						getPower(incomingPoint, indirectSurface, impact, ttl - 1, wavelenghts, bounceDirectPower, bounceIndirectPower);
						for (int i = 0; i < wavelenghts.length; i++) {
							bouncePower[i] = bounceDirectPower[i] + bounceIndirectPower[i];

							// Don't attenuate bounced light, just direct point light
							// TEST: I'm trying to see the effect of attenuating anyway
							//bouncePower[i] = PointLight.attenuatePower(bouncePower[i], incomingPoint, impact);
						}

						// compute brdf
						computeBRDF(impact, surface, n, in, out, elevationIn, azymuthIn, elevationOut, azymuthOut, wavelenghts, brdf);

						// part of rendering equation
						for (int i = 0; i < wavelenghts.length; i++) {
							localPower[i] = brdf[i] * bouncePower[i] * Math.cos(elevationIn);
						}
					}

				} else {
					lostInSpace++;
				}

				// monte carlo integration
				for (int i = 0; i < wavelenghts.length; i++) {
					monteCarloSum[i] += localPower[i] / probOfRay;
				}
			}

			if (lostInSpace > 0) System.err.println("Lost in Space: " + lostInSpace);
			// add estimate integral value to power
			for (int i = 0; i < wavelenghts.length; i++) {
				int N = monteCarloN - ignoredRay;
				if (N >= 1) {
					outIndirectPowers[i] += monteCarloSum[i] / monteCarloN;
				}
				if (N < monteCarloN / 2) System.err.println("Mostly ignored rays: " + N);
			}

		}
	}

	private void directIllumination(Point3D impact, Point3D light, Point3D eye, Plane3D plane, Surface surface, Point3D normal, double out[], boolean attenuate, double brdf[], double wavelenghts[], double elevationOut, double azymuthOut, Point3D projOut, double lightPower) {
		for (int i = 0; i < wavelenghts.length; i++) {
			out[i] = 0;
		}

		Line3D rayToLight = V.Line3D(impact, light);
		// does the light directly sees the impact point
		boolean inDirectIllumination = (surface instanceof Sphere || G.areSameSideOfAndBothFarEnough(eye, light, plane)) && (!scene.hit(rayToLight, M.EPSILON, _getPower_ptrT, _getPower_ptrSurface, surface) || M.kindaGreaterOrEqual(_getPower_ptrT.value, 1));
		// if so, compute elevation and azymuth of incoming ray
		if (inDirectIllumination) {
			Point3D in = G.sub_(light, impact);
			in.normalizeInPlace();
			double elevationIn = G.angle(light, impact, G.add_(impact, normal));
			Point3D projIn = plane.project_(light);
			double azymuthIn = G.angle(projOut, impact, projIn);

			// compute brdf
			computeBRDF(impact, surface, normal, in, eye, elevationIn, azymuthIn, elevationOut, azymuthOut, wavelenghts, brdf);

			// compute power of the light reaching this impact point (distance dependant)
			for (int i = 0; i < wavelenghts.length; i++) {
				// sum part of the rendering equation 
				out[i] = brdf[i] * lightPower * Math.cos(elevationIn);
			}
		} else {
			/*
			// TODO debuging
			if (surface instanceof Sphere) {
				boolean a = G.areSameSideOfAndBothFarEnough(eye, light, plane);
				boolean b = (!scene.hit(rayToLight, M.EPSILON, _getPower_ptrT, _getPower_ptrSurface, surface) || M.kindaGreaterOrEqual(_getPower_ptrT.value, 1));
				out[0] = a && b ? 1 : 0;
				out[1] = a ? 1 : 0;
				out[2] = b ? 1 : 0;
			}
			*/
		}
	}

	public Double snellGetAngle2(double n1, double angle1, double n2) {
		// Snell law: n1*sin(angle1) = n2*sin(angle2);
		double argument = n1 * Math.sin(angle1) / n2;
		if (Math.abs(argument) < 1) return Math.asin(argument);
		return null; // total internal reflection 
	}

	public void computeBRDF(Point3D impact, Surface surface, Point3D normal, Point3D in, Point3D out, double elevationIn, double azymuthIn, double elevationOut, double azymuthOut, double wavelenght[], double brdfOut[]) {
		for (int i = 0; i < wavelenght.length; i++) {
			brdfOut[i] = 0;
		}
		switch (surface.getMaterial().type) {
			case Material.SIMPLE:
				brdfSimple(impact, surface, normal, in, out, elevationIn, azymuthIn, elevationOut, azymuthOut, wavelenght, brdfOut);
				break;
			case Material.PHONG:
				blinnPhong(impact, surface, normal, in, out, elevationIn, azymuthIn, elevationOut, azymuthOut, wavelenght, brdfOut);
				break;
			case Material.COOK:
				cookTorrance(impact, surface, normal, in, out, elevationIn, azymuthIn, elevationOut, azymuthOut, wavelenght, brdfOut);
				break;
			default:
				throw new RuntimeException("Unsupported material type: " + surface.getMaterial().type);
		}
	}

	public void brdfSimple(Point3D impact, Surface surface, Point3D normal, Point3D in, Point3D out, double elevationIn, double azymuthIn, double elevationOut, double azymuthOut, double wavelenght[], double brdfOut[]) {
		Material material = surface.getMaterial();
		for (int i = 0; i < wavelenght.length; i++) {
			if (wavelenght[i] == 650)
				brdfOut[i] = material.color.getRed() / 255.0;
			else if (wavelenght[i] == 510)
				brdfOut[i] = material.color.getGreen() / 255.0;
			else if (wavelenght[i] == 475)
				brdfOut[i] = material.color.getBlue() / 255.0;
			else
				throw new RuntimeException("brdfSimple only works with rgb wavelenghts");
		}
	}

	public void blinnPhong(Point3D impact, Surface surface, Point3D normal, Point3D in, Point3D out, double elevationIn, double azymuthIn, double elevationOut, double azymuthOut, double wavelenght[], double brdfOut[]) {
		Material material = surface.getMaterial();
		Point3D halfway = G.add_(in, out);
		halfway.normalizeInPlace();

		// test copper for everybody
		//material.ambient = new double[] { 0.19,0.07,0.02 };
		//material.diffuse = new double[] { 0.7,0.27,0.08 };
		//material.specular = new double[] { 0.26,0.14,0.09 };
		//material.shininess = 13;

		// Note: assumes wavelenghts are r, g, b 
		double dotNormalIn = Math.max(0.0, G.dot(normal, in));
		double dotNormalHalf = Math.max(0.0, G.dot(normal, halfway));
		for (int i = 0; i < wavelenght.length; i++) {
			double ambient = material.ambient[i];
			double diffuse = material.diffuse[i] * dotNormalIn;
			double specular = material.specular[i] * Math.pow(dotNormalHalf, material.shininess);
			brdfOut[i] = ambient + diffuse + specular;
		}

	}

	public void cookTorrance(Point3D impact, Surface surface, Point3D normal, Point3D in, Point3D out, double elevationIn, double azymuthIn, double elevationOut, double azymuthOut, double wavelenght[], double brdfOut[]) {
		Material material = surface.getMaterial();
		// normalize vectors and initialize some variables that will be usuful during computation
		Point3D N = normal;
		Point3D L = in;
		Point3D V = out;
		Point3D H = G.add_(in, out);
		H.normalizeInPlace();
		double NL = G.dot(N, L);
		double NV = G.dot(N, V);
		double NH = G.dot(N, H);
		double VH = G.dot(V, H);
		double a = Math.acos(NH);
		//float t = acos(VH);
		double PI = Math.PI;

		// Test Copper
		/*
		double specular = 1;
		double diffuse = 0;
		double ambiant = 0.01;
		//double colorCoefficient[] = new double[] { .75, .25, .16 };
		double colorCoefficient[] = new double[] { .50, .18, .156 };
		// Index of refraction and extinction approximated from graph at from http://www.filmetrics.com/refractive-index-database/Cu/Copper
		double indexOfRefraction[] = new double[] { 0.214, 1.132, 1.150 };
		//double indexOfExtinction[] = new double[] { 3.670, 2.590, 2.504 }; // unused
		// Beckman weights and value
		double w[] = new double[] { .4, .6 };
		double m[] = new double[] { .4, .2 };
		*/

		// sum of Beckman (D) wavelength independant
		double cos4a = NH * NH * NH * NH; // NH*NH*NH*NH = cos^4(a)
		double tan_a = Math.tan(a);
		double D = 0;
		for (int i = 0; i < material.cook_m.length; i++) {
			D += material.cook_w[i] * (Math.exp(-(tan_a / material.cook_m[i]) * (tan_a / material.cook_m[i])) / (material.cook_m[i] * material.cook_m[i] * cos4a));
		}

		// geometric term (G) wavelength independant
		double G = Math.min(Math.min(1, (2 * NH * NV) / VH), (2 * NH * NL) / VH);

		// wavelength dependant
		for (int i = 0; i < wavelenght.length; i++) {

			// Fresnel term (F)
			double nt = material.cook_indexOfRefraction[i];
			// Schlick approximation (counldn't find example to help me with the real fresnel term...)
			double R0 = ((nt - 1) / (nt + 1)) * ((nt - 1) / (nt + 1)); // ((nt - 1)/(nt + 1))^2
			//double F = R0 + (1 - R0) * Math.pow(1 - NV, 5);
			double F = R0 + (1 - R0) * Math.pow(1 - VH, 5);
			/*
			double cosTheta = VH; // Note: in the class notes, it says NV or NL since they are the same but those are not the same value! only VH and LH are the same, so I'm assuming that is what was meant. Theta is arccos(VH) in cook paper, which supports my claim.
			double theta = Math.acos(cosTheta);
			//double cosOther = Math.cos(Math.asin(Math.sin(Math.acos(cosTheta)) / nt)); // Snell's law with n = 1
			Double other = snellGetAngle2(1, theta, nt);
			double cosOther = other == null ? 0 : Math.cos(other); // take into account total internal reflection
			double F;
			if (M.kindaEquals(cosTheta, 0) && M.kindaEquals(cosOther, 0)) {
				F = 1;
			} else {
				double r1 = (cosTheta - nt * cosOther) / (cosTheta + nt * cosOther);
				double r2 = (nt * cosTheta - cosOther) / (nt * cosTheta + cosOther);
				F = (r1 * r1 + r2 * r2) / 2;
			}
			*/

			// Specular term (Rs)
			double Rs = (F / PI) * ((D * G) / (NL * NV));

			// Diffuse term (Rd)
			double Rd = (R0 + (1 - R0)) / PI; // Rd = F0 / PI where F0 is the fresnel term if the angle would be zero
			Rd /= PI;

			// Output (R)
			double R = material.cook_ambiant + material.cook_diffuse * Rd + material.cook_specular * Rs;

			// for the color coefficient, I have estimated very rough values by looking at figure 4b of the reference paper for this assignment (R.L. Cook and K.E. Torrance. A reflectance model for computer graphics. In Computer Graphics, Annual Conference Series, pages 307-316, Dallas, USA, Aug 1981. ACM SIGGRAPH)
			brdfOut[i] = material.cook_colorCoefficient[i] * R;
		}
	}

	// KeyEventDispatcher
	public boolean dispatchKeyEvent(KeyEvent e) {
		switch (e.getID()) {
			case KeyEvent.KEY_TYPED:
				keyTyped(e);
				break;
			case KeyEvent.KEY_PRESSED:
				keyPressed(e);
				break;
			case KeyEvent.KEY_RELEASED:
				keyReleased(e);
				break;
		}
		if (e.getSource() instanceof JTextField) return false;
		return true; // false=broadcast event, true=discard event
	}

	// SimpleNoticeListener
	public void simpleNotice(Object source) {
		repaint();
		Point3D eye = this.eye.get();
		Point3D screenTopLeft = this.screenTopLeft.get();
		Point3D screenBottomLeft = this.screenBottomLeft.get();
		Point3D screenTopRight = this.screenTopRight.get();
		System.out.println("eye: " + eye);
		System.out.println("screenTopLeft: " + screenTopLeft);
		System.out.println("screenTopRight: " + screenTopRight);
		System.out.println("screenBottomLeft: " + screenBottomLeft);
	}

	// ActionListener
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == render) {
			render();
		} else if (source == open) {
			open();
		}
	}

	// Main
	public static void main(String[] args) {
		GLJPanel glPanel = createPanel();
		EyeScreenSetup framework = new EyeScreenSetup(glPanel);
		KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(framework);
	}
}
