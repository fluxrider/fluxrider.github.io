package flux.ray.scene;

import flux.geo3D.G;
import flux.geo3D.Quad;
import flux.material.Surface;

public class QuadLight extends Quad {

	// Attributes
	private double power; // already divided by 4PI

	// Construct
	public QuadLight(QuadLight q_) {
		super(q_);
		this.power = q_.power;
	}
	
	public QuadLight(Quad q_) {
		super(q_);
	}

	// Methods
	public void setPower(double power) {
		this.power = power;
	}

	public double getPower() {
		return power;
	}

	public double getPointPower() {
		return power / G.area(this);
	}
	
	protected Surface _copy() {
		return new QuadLight(this);
	}

}
