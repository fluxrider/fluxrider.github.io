/*
 * Written by David Lareau.
 * 
 * A scene contains box or surfaces (sphere, triangle, quads)
 * and light sources.
 */
package flux.ray.scene;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import flux.geo3D.Box;
import flux.geo3D.G;
import flux.geo3D.Line3D;
import flux.geo3D.Point3D;
import flux.geo3D.Quad;
import flux.geo3D.Sphere;
import flux.geo3D.Triangle;
import flux.material.Material;
import flux.material.Surface;
import flux.mem.Ptr;
import flux.mem.V;
import flux.text.Parse;

public class Scene {

	// Attributes
	private List<Object> objects = new LinkedList<Object>();
	private List<Object> lights = new LinkedList<Object>();

	// Construct

	// Methods
	public void reset() {
		objects.clear();
		lights.clear();
	}

	public boolean hit(Line3D ray, double minT, Ptr<Double> t_out, Ptr<Surface> surface_out, Object blacklist) {
		t_out.value = null;
		surface_out.value = null;
		
		double[] doubleBuffer = V.getDoubleBuffer();
		Surface[] surfaceBuffer = V.getSurfaceBuffer();

		// for each objects
		for (Object object : getObjects()) {
			if (object == blacklist) continue;
			// ray-sphere
			if (object instanceof Sphere) {
				Sphere surface = (Sphere) object;
				int nRoots = G.intersection(ray, surface, doubleBuffer);
				if (nRoots >= 1) candidate(doubleBuffer[0], surface, minT, t_out, surface_out);
				if (nRoots >= 2) candidate(doubleBuffer[1], surface, minT, t_out, surface_out);
			}
			// ray-quad
			else if (object instanceof Quad) {
				Quad surface = (Quad) object;
				Ptr<Double> ptr = V.PtrDouble();
				if (G.intersection(ray, surface, ptr)) {
					candidate(ptr.value, surface, minT, t_out, surface_out);
				}
			}
			// ray-triangle
			else if (object instanceof Triangle) {
				Triangle surface = (Triangle) object;
				Ptr<Double> ptr = V.PtrDouble();
				if (G.intersection(ray, surface, ptr)) {
					candidate(ptr.value, surface, minT, t_out, surface_out);
				}
			}
			// ray-box
			else if (object instanceof Box) {
				Box box = (Box) object;
				int nIntersections = G.intersection(ray, box, doubleBuffer, surfaceBuffer);
				if (nIntersections > 0) {
					for (int i = 0; i < nIntersections; i++) {
						candidate(doubleBuffer[i], surfaceBuffer[i], minT, t_out, surface_out);
					}
				}
			}
		}

		return t_out.value != null;
	}

	private void candidate(double t, Surface surface, double minT, Ptr<Double> t_out, Ptr<Surface> surface_out) {
		if (t > minT) {
			if (t_out.value == null || t < t_out.value) {
				t_out.value = t;
				surface_out.value = surface;
			}
		}
	}

	public List<Object> getObjects() {
		return objects;
	}

	public List<Object> getLights() {
		return lights;
	}

	public String parse(BufferedReader in) throws IOException {
		/*
		==Example input==
		sphere (0,0,0) .5 rgb(255,0,0)
		triangle (0, .5, 0) (-.5, -.5, 0) (.5, -.5, 0) rgb(255,0,0)
		quad (0, .5, 0) (-.5, -.5, 0) (.5, -.5, 0) rgb(255,0,0)
		box (0, 0, 0) (0, 0, .5) (.5, 0, 0) (0, .5, 0) rgb(255,0,0) rgb(255,0,0) rgb(255,0,0) rgb(255,0,0) rgb(255,0,0) rgb(255,0,0)
		box (0, 0, 0) (0, 0, .5) (.5, 0, 0) (0, .5, 0) rgb(255,0,0) boxdrawdebug(n,y,y,y,y,y)
		// the parse stops when the input line doesn't fit any of its parsable syntax, and return that line or null if eof
		*/
		String line;
		while ((line = in.readLine()) != null) {
			String[] parts = line.split("\\s");
			// == Sphere ==
			if (line.startsWith("sphere ")) {
				// formal parameters
				Point3D center = Parse.point3D_(parts[1]);
				double radius = Double.parseDouble(parts[2]);
				Sphere sphere = new Sphere(center, radius);
				// material parameters
				sphere.setMaterial(Parse.material(parts[3]));
				// add to scene
				objects.add(sphere);
			}
			// == Triangle ==
			else if (line.startsWith("triangle ")) {
				// formal parameters
				Point3D a = Parse.point3D_(parts[1]);
				Point3D b = Parse.point3D_(parts[2]);
				Point3D c = Parse.point3D_(parts[3]);
				Triangle triangle = new Triangle(a, b, c);
				// material parameters
				triangle.setMaterial(Parse.material(parts[4]));
				// add to scene
				objects.add(triangle);
			}
			// == Quad ==
			else if (line.startsWith("quad ")) {
				// formal parameters
				Point3D a = Parse.point3D_(parts[1]);
				Point3D b = Parse.point3D_(parts[2]);
				Point3D c = Parse.point3D_(parts[3]);
				Quad quad = new Quad(a, b, c);
				// material parameters
				quad.setMaterial(Parse.material(parts[4]));
				// add to scene
				objects.add(quad);
			}
			// == Box ==
			else if (line.startsWith("box ")) {
				// formal parameters
				Point3D a = Parse.point3D_(parts[1]);
				Point3D b = Parse.point3D_(parts[2]);
				Point3D c = Parse.point3D_(parts[3]);
				Point3D d = Parse.point3D_(parts[4]);
				Box box = new Box(a, b, c, d);
				// material parameters
				int face = 0;
				int i = 5;
				while (i < parts.length && Parse.isMaterial(parts[i])) {
					box.setMaterial(Parse.material(parts[i]), face);
					box.getMaterial(face).drawInPreview = true;
					face++;
					i++;
				}
				// find in other faces with front face material properties
				while (face != 6) {
					box.setMaterial(box.getMaterial(0), face++);
				}
				// debuging preview options
				if (i < parts.length && parts[i].startsWith("boxdrawdebug")) {
					for (int j = 0; j < 6; j++) {
						box.getMaterial(j).drawInPreview = parts[i].charAt(13 + j * 2) == 'y';
					}
				}
				// add to scene
				objects.add(box);
			}
			// == Point Light ==
			else if (line.startsWith("pointlight")) {
				PointLight point = new PointLight(Parse.point3D_(parts[1]));
				point.setPower(Double.parseDouble(parts[2]));
				lights.add(point);
			}
			// == Point Light ==
			else if (line.startsWith("quadlight")) {
				// formal parameters
				Point3D a = Parse.point3D_(parts[1]);
				Point3D b = Parse.point3D_(parts[2]);
				Point3D c = Parse.point3D_(parts[3]);
				QuadLight quad = new QuadLight(new Quad(a, b, c));
				// material parameters for debug view
				Material material = new Material();
				material.color = Color.WHITE;
				material.type = Material.LIGHT;
				quad.setMaterial(material);
				// set light power
				quad.setPower(Double.parseDouble(parts[4]));
				// add quad light both to scene and light list
				objects.add(quad);
				lights.add(quad);
			}
			// == UNKNOWN (stop) ==
			else {
				return line;
			}
		}
		return line;
	}
}
