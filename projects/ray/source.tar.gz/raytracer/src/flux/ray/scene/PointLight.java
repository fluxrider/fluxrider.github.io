package flux.ray.scene;

import flux.geo3D.Point3D;
import flux.math.M;

public class PointLight extends Point3D {

	// Attributes
	private double power; // already divided by 4PI

	// Construct
	public PointLight(Point3D p_) {
		super(p_);
	}

	// Methods
	public void setPower(double power) {
		this.power = power;
	}

	//public double getPower(double wavelength) {
	//	return power; // Note: I'm making my lights the same power no matter which wavelength we are asking for, this means my lights are white
	//}

	public double getPower() {
		return power;
	}

	//public double getPower(Point3D to) {
	//	return attenuatePower(power, this, to);
	//}

	public static double attenuatePower(double power, Point3D from, Point3D to) {
		double r2 = M.euclideanDistance2(from, to);
		return power / (r2 + 1); // Here I do + 1 to avoid super bright points if the distance is below 1. This choice is not justified by theory :(
	}

}
