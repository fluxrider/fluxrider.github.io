#!/bin/sh
mkdir bin
javac -d bin -cp src:lib/jogl.all.jar:lib/newt.all.jar:lib/nativewindow.all.jar:lib/gluegen-rt.jar src/flux/ray/EyeScreenSetup.java