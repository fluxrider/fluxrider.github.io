#!/bin/sh
mkdir out
java -cp bin:lib/jogl.all.jar:lib/newt.all.jar:lib/nativewindow.all.jar:lib/gluegen-rt.jar -Djava.library.path=lib/linux-i586/ flux.ray.EyeScreenSetup

