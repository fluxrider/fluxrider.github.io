/*
 * TODO Copyright (c)
 */

package flux.card.tarot;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * This class loads a spread description to be used by the tarot application.
 * 
 * @author David Lareau
 */

public class Spread {

	// Inner Class
	public class Item {
		public final int x;
		public final int y;
		public final int w;
		public final int h;
		public final String label;

		public Item(int x, int y, int w, int h, String label) {
			this.x = x;
			this.y = y;
			this.w = w;
			this.h = h;
			this.label = label;
		}
	}

	// Attributes
	public final String name;
	public final int width;
	public final int height;
	public final List<Item> items;

	// Construct
	public Spread(String spreadFilename) {
		items = new LinkedList<Item>();
		try {
			// Parse deck description file
			{
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document document = builder.parse(new File(spreadFilename));
				Element root = document.getDocumentElement();
				this.name = root.getAttributes().getNamedItem("name").getNodeValue();
				this.width = Integer.parseInt(root.getAttributes().getNamedItem("width").getNodeValue());
				this.height = Integer.parseInt(root.getAttributes().getNamedItem("height").getNodeValue());
				NodeList cards = root.getChildNodes();
				// Create a Card object for each card in the deck
				for (int i = 0; i < cards.getLength(); i++) {
					Node node = cards.item(i);
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element card = (Element) node;
						String label = card.getAttributes().getNamedItem("label").getNodeValue();
						int x = Integer.parseInt(card.getAttributes().getNamedItem("x").getNodeValue());
						int y = Integer.parseInt(card.getAttributes().getNamedItem("y").getNodeValue());
						int w = Integer.parseInt(card.getAttributes().getNamedItem("w").getNodeValue());
						int h = Integer.parseInt(card.getAttributes().getNamedItem("h").getNodeValue());
						Item item = new Item(x, y, w, h, label);
						items.add(item);
					}
				}
			}
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e);
		} catch (SAXException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

}
