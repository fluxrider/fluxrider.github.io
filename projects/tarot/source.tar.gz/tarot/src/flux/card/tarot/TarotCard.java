package flux.card.tarot;

import java.awt.image.BufferedImage;
import java.util.List;

import flux.card.Card;
import flux.util.U;

public class TarotCard {

	public final Card card;
	public final String name;
	public BufferedImage image;
	public final String arcana;
	public final String suit;
	public final List<String> keywords;

	public TarotCard(Card card) {
		this.card = card;
		this.name = card.getString("name");
		this.keywords = card.getStrings("keywords");
		this.arcana = card.getString("arcana");
		this.suit = card.getString("suit");

		// image = U.load(U.path(resFolder, card.getString("imagePath")));
		U.loadAsync(U.path(Tarot.resFolder, card.getString("imagePath")), new U.LoadAsyncCallback() {
			public void loadAsyncCallback(String filename, BufferedImage loaded, Throwable error) {
				image = loaded;
				if (error != null) throw new RuntimeException(filename, error);
			}
		});
	}

}
