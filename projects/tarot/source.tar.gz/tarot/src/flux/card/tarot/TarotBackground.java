/*
 * TODO Copyright (c)
 */

package flux.card.tarot;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import flux.image.I;
import flux.math.M;
import flux.math.M.TimingFunction;
import flux.util.Transition;
import flux.util.U;

/**
 * Tiled Background that can change main icon (depending on the suit of tarot).
 * 
 * Because of the transitions (especially hue transition), it is meant to be painted regularly.
 * 
 * @author David Lareau
 */

public class TarotBackground {

	// Attributes
	private BufferedImage bgTile;
	private BufferedImage texture;
	private BufferedImage logo;
	private BufferedImage logoTo;
	private BufferedImage logoTrumps, logoSwords, logoWands, logoCups, logoPentacles;
	private Transition logoRotation;
	private Transition logoScale;
	private Transition hue;

	// Construct
	public TarotBackground(int tileWidth, int tileHeight) {
		// preload images and buffer
		bgTile = new BufferedImage(tileWidth, tileHeight, BufferedImage.TYPE_INT_RGB);

		texture = U.load(U.path(Tarot.resFolder, "icons/texture.png"));
		logoTrumps = U.load(U.path(Tarot.resFolder, "icons/trumps.png"));
		logoSwords = U.load(U.path(Tarot.resFolder, "icons/swords.png"));
		logoWands = U.load(U.path(Tarot.resFolder, "icons/wands.png"));
		logoCups = U.load(U.path(Tarot.resFolder, "icons/cups.png"));
		logoPentacles = U.load(U.path(Tarot.resFolder, "icons/pentacles.png"));

		logo = logoTrumps;

		logoRotation = new Transition(0);
		logoScale = new Transition(0.5);
		hue = new Transition(0, 1, 10000, 0, M.TimingFunction.LINEAR, Transition.LOOP_UNLIMITED, false);
	}

	// Paint
	public void paint(Graphics g, int X, int Y, int W, int H) {
		int tileW = bgTile.getWidth();
		int tileH = bgTile.getHeight();
		Color bg = new Color(Color.HSBtoRGB((float) hue.get(), (float) .4, (float) 1));
		double textureOpacity = .2;
		double logoOpacity = .3;
		int centerLogo = 5;
		if (logoRotation.getTotalRatio() > 0.5) logo = logoTo;
		I.paintSingleBackgroundTile((Graphics2D) bgTile.getGraphics(), 0, 0, tileW, tileH, bg, texture, textureOpacity, logo, logoOpacity, logoRotation.get(), centerLogo, logoScale.get());
		for (int r = 0; r * tileH < H; r++) {
			for (int c = 0; c * tileW < W; c++) {
				g.drawImage(bgTile, X + c * tileW, Y + r * tileH, null);
			}
		}
	}

	// Methods
	public void changeLogo(String suit) {
		// start animations
		BufferedImage oldLogoTo = logoTo;
		if (suit.equals("Trumps")) logoTo = logoTrumps;
		else if (suit.equals("Wands")) logoTo = logoWands;
		else if (suit.equals("Swords")) logoTo = logoSwords;
		else if (suit.equals("Cups")) logoTo = logoCups;
		else if (suit.equals("Pentacles")) logoTo = logoPentacles;
		else throw new RuntimeException("Unrocognized suit: " + suit);
		if (logoTo != logo && oldLogoTo != logoTo) {
			logoRotation.start(0, 2 * Math.PI, 500, 0, TimingFunction.EASE, 1, true);
			logoScale.start(.5, 0, 500, 0, TimingFunction.EASE, 1, true);
		}
	}
}
