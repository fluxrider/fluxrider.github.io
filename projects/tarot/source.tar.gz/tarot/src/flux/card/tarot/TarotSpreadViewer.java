/*
 * TODO Copyright (c)
 */

package flux.card.tarot;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JPanel;

import flux.card.Card;
import flux.card.Deck;
import flux.card.tarot.Spread.Item;
import flux.data.CountMap;
import flux.image.I;
import flux.input.EventBasedKeyboard;
import flux.math.M;
import flux.math.M.TimingFunction;
import flux.util.FPS;
import flux.util.Transition2D;
import flux.util.TransitionND;
import flux.util.U;

/**
 * This class is a stand-alone gui application to view a tarot spread.
 * 
 * @author David Lareau
 */

public class TarotSpreadViewer extends JPanel implements Runnable, KeyListener {

	// Attributes
	private TarotBackground bg;
	private Thread paintThread;
	private Font labelFont, cardNameFont;
	private FPS fps;

	private Spread spread;
	private TarotCard cards[];
	private Transition2D cardTransitions[]; // units of transition are in spread dimension
	private int revealed;
	private boolean showName;

	private TransitionND panTransition; // 4D camera
	private double panBuffer[] = new double[4];
	private boolean zoomed;
	private int zoomedCard;

	// Construct
	public TarotSpreadViewer() {
		// load the spread description file
		spread = Tarot.loadSpread("three");
		revealed = 0;
		showName = true;

		// load the deck of card
		Map<String, Card> deck = Tarot.loadDeck();
		Deque<Card> stack = Deck.cloneToShuffledStack(deck);
		List<Card> hand = new ArrayList<Card>(stack.size());
		Deck.takeCards(stack, hand, spread.items.size());

		// preload graphics related resource
		bg = new TarotBackground(128, 128);
		labelFont = new Font(Font.SANS_SERIF, Font.PLAIN, 18);
		cardNameFont = new Font(Font.SANS_SERIF, Font.PLAIN, 12);
		cards = new TarotCard[hand.size()];
		cardTransitions = new Transition2D[cards.length];
		for (int i = 0; i < cards.length; i++) {
			cards[i] = new TarotCard(hand.get(i));
			cardTransitions[i] = new Transition2D(spread.width / 2.0, spread.height);
		}

		panTransition = new TransitionND(new double[] { 0, 0, 1, 1 });

		// start paint thread
		fps = new FPS();
		paintThread = new Thread(this);
		paintThread.start();
	}

	// Paint
	synchronized public void paint(Graphics g) {
		int W = getWidth();
		int H = getHeight();

		bg.paint(g, 0, 0, W, H);

		int margin = 5;
		panTransition.get(panBuffer);
		paintSpreadBoardSection(g, margin, margin, W - 2 * margin, H - 2 * margin, panBuffer[0], panBuffer[1], panBuffer[2], panBuffer[3]);

		fps.frame();
	}

	private void paintSpreadBoardSection(Graphics g, int X, int Y, int W, int H, double panX1, double panY1, double panX2, double panY2) {
		g.clipRect(X, Y, W, H);

		double panW = panX2 - panX1;
		double panH = panY2 - panY1;
		double unitX = W / (spread.width * panW);
		double unitY = H / (spread.height * panH);
		X -= M.r(unitX * (panX1 * spread.width));
		Y -= M.r(unitY * (panY1 * spread.height));

		// draw each spread item regions
		int order = 0;
		for (Spread.Item item : spread.items) {
			// compute item region
			int outerMargin = 2;

			// box
			Point2D p = cardTransitions[order].get();
			int cardX = X + outerMargin + M.r(p.getX() * unitX);
			int cardY = Y + outerMargin + M.r(p.getY() * unitY);
			int boxX = cardX; // X + outerMargin + M.r(item.x * unitX);
			int boxY = cardY; // Y + outerMargin + M.r(item.y * unitY);
			int boxW = M.r(item.w * unitX) - 2 * outerMargin;
			int boxH = M.r(item.h * unitY) - 2 * outerMargin;
			g.setColor(Color.BLACK);
			g.drawRect(boxX, boxY, boxW - 1, boxH - 1);
			int innerMargin = 2; // note that the box itself is part of the region, so a inner margin of 0 would cover the box

			// label (centered, bottom)
			g.setFont(labelFont);
			FontMetrics metrics = g.getFontMetrics();
			int dy = metrics.getHeight();
			int labelHeight = dy + metrics.getDescent();
			int labelWidth = metrics.stringWidth(item.label);
			g.drawString(item.label, boxX + (boxW - labelWidth) / 2, boxY + boxH - innerMargin - metrics.getDescent());

			// card
			paintCard(g, cards[order], showName, cardX + innerMargin, cardY + innerMargin, boxW - 2 * innerMargin, boxH - 2 * innerMargin - labelHeight);
			order++;
		}
	}

	private void paintCard(Graphics g, TarotCard card, boolean showName, int X, int Y, int W, int H) {
		int th = 0;
		// name
		if (showName) {
			g.setFont(cardNameFont);
			FontMetrics metrics = g.getFontMetrics();
			int dy = metrics.getHeight();
			th = dy + metrics.getDescent();
			int tw = metrics.stringWidth(card.name);
			g.drawString(card.name, X + (W - tw) / 2, Y + H - metrics.getDescent());
		}
		// image
		I.drawImage((Graphics2D) g, X, Y, W, H - th, card.image, null, true, false, null);
	}

	// Paint Thread
	public void run() {
		while (paintThread == Thread.currentThread()) {
			repaint();
			U.yieldForRepaint();
		}
	}

	// KeyListener
	synchronized public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
			case KeyEvent.VK_LEFT:
				if (zoomed) {
					zoomedCard = M.previousIndex(zoomedCard, revealed);
					panTransition.start(panTransition.get(panBuffer), getCurrentCardPan(), 1000, 0, TimingFunction.EASE, 0, false);
				}
				break;
			case KeyEvent.VK_RIGHT:
				if (zoomed) {
					zoomedCard = M.nextIndex(zoomedCard, revealed);
					panTransition.start(panTransition.get(panBuffer), getCurrentCardPan(), 1000, 0, TimingFunction.EASE, 0, false);
				}
				break;
			case KeyEvent.VK_N:
				showName = !showName;
				break;
			case KeyEvent.VK_Z: {
				zoomed = revealed > 0 ? !zoomed : zoomed;
				panTransition.get(panBuffer);
				double to[] = (zoomed ? getCurrentCardPan() : new double[] { 0, 0, 1, 1 });
				panTransition.start(panBuffer, to, 1000, 0, TimingFunction.EASE, 0, false);
			}
				break;
			case KeyEvent.VK_ENTER:
				if (revealed < cardTransitions.length) {
					Point2D p = cardTransitions[revealed].get();
					cardTransitions[revealed].start(p.getX(), p.getY(), spread.items.get(revealed).x, spread.items.get(revealed).y, 1000, 0, TimingFunction.EASE, 0, false);
					revealed++;
					updateBackground();
				}
				break;
		}
	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {
	}

	// Private Methods
	private double[] getCurrentCardPan() {
		Item item = spread.items.get(zoomedCard);
		double x1 = item.x / (double) spread.width;
		double y1 = item.y / (double) spread.height;
		double x2 = (item.x + item.w) / (double) spread.width;
		double y2 = (item.y + item.h) / (double) spread.height;
		return new double[] { x1, y1, x2, y2 };
	}

	private void updateBackground() {
		// Heuristic to determine if a 'suit' is dominating the reading, if so, change the background to it.
		if (revealed > spread.items.size() / 2) {
			CountMap<String> count = new CountMap<String>();
			for (int i = 0; i < revealed; i++) {
				count.increment(cards[i].suit);
			}
			String max = count.getMax();
			if (count.getCount(max) > revealed / 2) bg.changeLogo(max);
			else bg.changeLogo("Trumps");
		}
	}

	// Main
	public static void main(String[] args) {
		EventBasedKeyboard.init();
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(10, 10, 800, 600);
		frame.setContentPane(new TarotSpreadViewer());
		frame.setVisible(true);
		EventBasedKeyboard.addListener((KeyListener) frame.getContentPane());
	}

}
