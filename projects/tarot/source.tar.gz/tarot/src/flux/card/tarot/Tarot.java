/*
 * TODO Copyright (c)
 */

package flux.card.tarot;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.swing.JFrame;
import javax.swing.JPanel;

import flux.card.Card;
import flux.card.Deck;
import flux.card.tarot.Spread.Item;
import flux.data.CountMap;
import flux.image.I;
import flux.input.EventBasedKeyboard;
import flux.math.M;
import flux.math.M.TimingFunction;
import flux.util.FPS;
import flux.util.ToStringer;
import flux.util.Transition;
import flux.util.Transition2D;
import flux.util.TransitionND;
import flux.util.U;
import flux.widget.FList;

/**
 * Entry point of Tarot application. Handles loading a tarot deck, and manages shared resources.
 * 
 * @author David Lareau
 */

public class Tarot extends JPanel implements Runnable, KeyListener {

	// Constant
	public static final String resFolder = "res/";

	// Shared resources
	public static final BufferedImage up = U.load(U.path(resFolder, "icons/arrow_up.png"));
	public static final BufferedImage down = U.load(U.path(resFolder, "icons/arrow_down.png"));
	public static final BufferedImage left = U.load(U.path(resFolder, "icons/arrow_left.png"));
	public static final BufferedImage right = U.load(U.path(resFolder, "icons/arrow_right.png"));
	public static final BufferedImage[] arrows = new BufferedImage[] { up, down, left, right };

	// Supported Features
	public static final String[] spreads = new String[] { "three", "celtic", "one", "seven", "cross" };
	public static final String[] languages = new String[] { "en", "fr" };
	public static final String[] decks = new String[] { "rider_png", "davids" };

	// Parameters
	public static String language = languages[0];
	public static String deck = decks[0];

	// Menu by supported languages
	public static final Map<String, Map<String, String>> menuItems;
	static {
		// english menu
		Map<String, String> en = new TreeMap<String, String>();
		en.put("spread", "Tarot Reading");
		en.put("browse", "Browse Deck");
		en.put("deck", "Deck: ");
		en.put("language", "Language: ");
		// french menu
		Map<String, String> fr = new TreeMap<String, String>();
		fr.put("spread", "Lecture de Tarot");
		fr.put("browse", "Regarder le Paquet");
		fr.put("deck", "Paquet :");
		fr.put("language", "Langue :");
		// menus
		Map<String, Map<String, String>> items = new HashMap<String, Map<String, String>>();
		items.put("en", en);
		items.put("fr", fr);
		menuItems = Collections.unmodifiableMap(items);
	}

	// Load the deck
	public static Map<String, Card> loadDeck() {
		String deckFilename = resFolder + "tarot.deck";
		String tarotdataFilename = resFolder + "tarot.data";
		String imagedataFilename = resFolder + "tarot.deck." + deck + ".data";
		String languagedataFilename = resFolder + "tarot." + language + ".data";
		Map<String, Card> deck = Deck.load(new ToStringer<Card>() {
			public String toString(Card card) {
				return card.getString("name");
			}
		}, deckFilename, tarotdataFilename, imagedataFilename, languagedataFilename);
		return deck;
	}

	public static Spread loadSpread(String spread) {
		return new Spread(resFolder + "spreads/" + spread + "." + language + ".spread");
	}

	// Main
	public static void main(String[] args) {
		EventBasedKeyboard.init();
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(10, 10, 800, 600);
		frame.setContentPane(new Tarot());
		frame.setVisible(true);
		EventBasedKeyboard.addListener((KeyListener) frame.getContentPane());
	}

	// Enums
	private enum Context {
		MAIN_MENU, SPREAD_MENU, DECK_VIEW, SPREAD_VIEW
	}

	private final int FULLSCREEN_IMAGE = 0;
	private final int IMAGE_AND_NAME = 1;
	private final int IMAGE_AND_FULL_DETAILS = 2;
	private final int ZOOM_STATE_COUNT = 3;

	// Attributes (general)
	private TarotBackground bg;
	private Thread paintThread;
	private Font font, cardNameFont;
	private FPS fps;

	private Context context;
	private FList mainMenu;
	private FList spreadMenu;
	private Spread loadedSpreads[] = new Spread[spreads.length];
	public Spread spread;
	public Map<String, Card> loadedDeck;

	// Attributes (Spread View)
	private TarotCard cards[];
	private Transition2D cardTransitions[]; // units of transition are in spread dimension
	private int revealed;
	private boolean showName = true;
	private TransitionND panTransition; // 4D camera
	private double panBuffer[] = new double[4];
	private boolean zoomed;
	private int zoomedCard;
	private boolean showKeywords;

	// Attributes (Deck View)
	private List<Card> hand;
	private TarotCard current, next, previous;
	private TarotCard goner, newcomer;
	private int currentIndex;
	private FList keywordList; // re-used in spread view
	private FList menu;
	private Transition offset;
	private Transition zoom;
	private boolean showMenu;
	private int zoomState;

	// Construct
	public Tarot() {
		// preload graphics related resource
		bg = new TarotBackground(128, 128);
		font = new Font(Font.SANS_SERIF, Font.PLAIN, 18);
		cardNameFont = new Font(Font.SANS_SERIF, Font.PLAIN, 12);

		// load menus
		mainMenu = new FList(this, true);
		spreadMenu = new FList(this, true);

		// set the context
		changeContext(Context.MAIN_MENU);

		// start paint thread
		fps = new FPS(10, false);
		paintThread = new Thread(this);
		paintThread.start();
	}

	// Context
	synchronized public void changeContext(Context context) {
		this.context = context;
		switch (context) {
			case MAIN_MENU:
				loadMainMenu();
				break;
			case SPREAD_MENU:
				loadSpreadMenu();
				break;
			case DECK_VIEW:
				hand = null;
				current = next = previous = null;
				goner = newcomer = null;
				currentIndex = 0;
				showMenu = false;
				loadedDeck = Tarot.loadDeck();
				menu = new FList(this, true);
				keywordList = new FList(this, false);
				zoomState = IMAGE_AND_FULL_DETAILS;
				zoom = new Transition(1);
				initializeHand();
				offset = new Transition(0);
				changeCard(0);
				break;
			case SPREAD_VIEW:
				revealed = 0;
				zoomed = false;
				zoomedCard = 0;
				// Note: showName value persists
				keywordList = new FList(this, false);
				showKeywords = false;
				loadedDeck = Tarot.loadDeck();
				Deque<Card> stack = Deck.cloneToShuffledStack(loadedDeck);
				List<Card> hand = new ArrayList<Card>(stack.size());
				Deck.takeCards(stack, hand, spread.items.size());
				cards = new TarotCard[hand.size()];
				cardTransitions = new Transition2D[cards.length];
				for (int i = 0; i < cards.length; i++) {
					cards[i] = new TarotCard(hand.get(i));
					cardTransitions[i] = new Transition2D(spread.width / 2.0, spread.height);
				}
				keywordList.setItems(true, cards[zoomedCard].keywords.toArray());
				panTransition = new TransitionND(new double[] { 0, 0, 1, 1 });
				break;
		}
	}

	// Main Menu
	private void loadMainMenu() {
		Map<String, String> items = menuItems.get(language);
		mainMenu.setItems(false, new String[] { items.get("spread"), items.get("browse"), items.get("deck") + deck, items.get("language") + language });
	}

	private void nextLanguage() {
		language = languages[M.nextIndex(U.find(languages, language), languages.length)];
	}

	private void nextDeck() {
		deck = decks[M.nextIndex(U.find(decks, deck), decks.length)];
	}

	// Spread Menu
	private void loadSpreadMenu() {
		String names[] = new String[spreads.length];
		// Preload all the spread files for this language
		for (int i = 0; i < spreads.length; i++) {
			loadedSpreads[i] = loadSpread(spreads[i]);
			names[i] = loadedSpreads[i].name;
		}
		spreadMenu.setItems(false, names);
	}

	// Paint
	synchronized public void paint(Graphics g) {
		int W = getWidth();
		int H = getHeight();
		bg.paint(g, 0, 0, W, H);

		switch (context) {
			case MAIN_MENU:
				mainMenu.draw(g, font, 0, 0, W, H, Tarot.arrows);
				break;
			case SPREAD_MENU:
				spreadMenu.draw(g, font, 0, 0, W, H, Tarot.arrows);
				break;
			case DECK_VIEW:
				paintDeckView(g);
				break;
			case SPREAD_VIEW:
				int margin = 5;
				panTransition.get(panBuffer);
				paintSpreadBoardSection(g, margin, margin, W - 2 * margin, H - 2 * margin, panBuffer[0], panBuffer[1], panBuffer[2], panBuffer[3]);
				break;
		}

		fps.frame();
	}

	public void run() {
		while (paintThread == Thread.currentThread()) {
			repaint();
			U.yieldForRepaint();
		}
	}

	// Spread View
	private void paintSpreadBoardSection(Graphics g, int X, int Y, int W, int H, double panX1, double panY1, double panX2, double panY2) {
		g.clipRect(X, Y, W, H);

		double panW = panX2 - panX1;
		double panH = panY2 - panY1;
		double unitX = W / (spread.width * panW);
		double unitY = H / (spread.height * panH);
		X -= M.r(unitX * (panX1 * spread.width));
		Y -= M.r(unitY * (panY1 * spread.height));

		// draw each spread item regions
		int order = 0;
		for (Spread.Item item : spread.items) {
			// compute item region
			int outerMargin = 2;

			// box
			Point2D p = cardTransitions[order].get();
			int cardX = X + outerMargin + M.r(p.getX() * unitX);
			int cardY = Y + outerMargin + M.r(p.getY() * unitY);
			int boxX = cardX; // X + outerMargin + M.r(item.x * unitX);
			int boxY = cardY; // Y + outerMargin + M.r(item.y * unitY);
			int boxW = M.r(item.w * unitX) - 2 * outerMargin;
			int boxH = M.r(item.h * unitY) - 2 * outerMargin;
			g.setColor(Color.BLACK);
			g.drawRect(boxX, boxY, boxW - 1, boxH - 1);
			int innerMargin = 2; // note that the box itself is part of the region, so a inner margin of 0 would cover the box

			// label (centered, bottom)
			g.setFont(font);
			FontMetrics metrics = g.getFontMetrics();
			int dy = metrics.getHeight();
			int labelHeight = dy + metrics.getDescent();
			int labelWidth = metrics.stringWidth(item.label);
			g.drawString(item.label, boxX + (boxW - labelWidth) / 2, boxY + boxH - innerMargin - metrics.getDescent());

			// card
			paintCard(g, cards[order], showName, cardX + innerMargin, cardY + innerMargin, boxW - 2 * innerMargin, boxH - 2 * innerMargin - labelHeight, showKeywords && zoomed && order == zoomedCard);
			order++;
		}
	}

	private void paintCard(Graphics g, TarotCard card, boolean showName, int X, int Y, int W, int H, boolean showKeywords) {
		int th = 0;
		// name
		if (showName) {
			g.setFont(cardNameFont);
			FontMetrics metrics = g.getFontMetrics();
			int dy = metrics.getHeight();
			th = dy + metrics.getDescent();
			int tw = metrics.stringWidth(card.name);
			g.drawString(card.name, X + (W - tw) / 2, Y + H - metrics.getDescent());
		}
		// image
		if (showKeywords) {
			keywordList.draw(g, font, X, Y, W, H - th, Tarot.arrows);
		} else {
			if (card.image != null) I.drawImage((Graphics2D) g, X, Y, W, H - th, card.image, null, true, false, null);
		}
	}

	private double[] getCurrentCardPan() {
		Item item = spread.items.get(zoomedCard);
		double x1 = item.x / (double) spread.width;
		double y1 = item.y / (double) spread.height;
		double x2 = (item.x + item.w) / (double) spread.width;
		double y2 = (item.y + item.h) / (double) spread.height;
		return new double[] { x1, y1, x2, y2 };
	}

	private void updateBackground() {
		// Heuristic to determine if a 'suit' is dominating the reading, if so, change the background to it.

		// if more than half the cards are out
		if (revealed > spread.items.size() / 2) {
			CountMap<String> count = new CountMap<String>();
			for (int i = 0; i < revealed; i++) {
				count.increment(cards[i].suit);
			}
			String max = count.getMax();

			// if more than half of the cards revealed are part of a suit, change the background
			if (count.getCount(max) > revealed / 2) bg.changeLogo(max);
			// else bg.changeLogo("Trumps");
		}
	}

	// Deck View
	private void paintDeckView(Graphics g) {
		int _W = getWidth();
		int _H = getHeight();
		g.setFont(font);
		FontMetrics metrics = g.getFontMetrics();
		int dy = metrics.getHeight();

		int marginX = 5;
		int marginY = 5;
		int X = marginX;
		int Y = marginY;
		int W = _W - marginX * 2;
		int H = _H - marginY * 2;

		if (showMenu) {
			menu.draw(g, font, X, Y, W, H, Tarot.arrows);
		} else {
			{
				int cardHeights[] = new int[3];
				cardHeights[FULLSCREEN_IMAGE] = H;
				cardHeights[IMAGE_AND_FULL_DETAILS] = H - 7 * dy;
				cardHeights[IMAGE_AND_NAME] = H - dy;
				int fromCardHeight = cardHeights[M.previousIndex(zoomState, ZOOM_STATE_COUNT)];
				int toCardHeight = cardHeights[zoomState];

				double a = offset.get();
				int dx = M.r(M.sign(a) * W - a * W);
				int cardHeight = M.r(M.linearBezier(zoom.get(), fromCardHeight, toCardHeight));

				// previous card
				if (goner != null && offset.getTotalRatio() < 1) {
					int gdx = M.r(-W * a);
					if (goner.image != null) I.drawImage((Graphics2D) g, X + gdx, Y, W, cardHeight, goner.image, null, true, true, null);
				}

				// current card
				TarotCard card = newcomer;
				int nameY = cardHeight + dy;
				int nameX = X + dx + (W - metrics.stringWidth(card.name)) / 2;
				int listY = Y + nameY + metrics.getDescent();
				int listH = H - listY;
				g.setColor(Color.BLACK);
				if (zoomState != FULLSCREEN_IMAGE) g.drawString(card.name, nameX, nameY);
				if (zoomState == IMAGE_AND_FULL_DETAILS) keywordList.draw(g, font, X + dx, listY, W, listH, Tarot.arrows);

				if (card.image != null) I.drawImage((Graphics2D) g, X + dx, Y, W, cardHeight, card.image, null, true, true, null);
			}
		}

	}

	private void changeCard(Card card) {
		changeCard(hand.indexOf(card));
	}

	private void changeCard(int newIndex) {
		goner = current;
		int c = newIndex;
		int p = M.previousIndex(newIndex, hand.size());
		int n = M.nextIndex(newIndex, hand.size());

		int direction = 1;
		// forward change
		if (c == M.nextIndex(currentIndex, hand.size())) {
			previous = current;
			current = next;
			next = new TarotCard(hand.get(n));
		}
		// backward change
		else if (c == M.previousIndex(currentIndex, hand.size())) {
			direction = -1;
			next = current;
			current = previous;
			previous = new TarotCard(hand.get(p));
		}
		// jump
		else if (c != currentIndex) {
			current = new TarotCard(hand.get(c));
			next = new TarotCard(hand.get(n));
			previous = new TarotCard(hand.get(p));
		}

		if (current == null) current = new TarotCard(hand.get(c));
		if (next == null) next = new TarotCard(hand.get(n));
		if (previous == null) previous = new TarotCard(hand.get(p));

		currentIndex = newIndex;
		keywordList.setItems(true, current.keywords.toArray());
		bg.changeLogo(current.suit);

		// slide card
		newcomer = current;
		if (goner != newcomer) offset.start(0, direction, 1000, 0, TimingFunction.EASE, 0, false);
	}

	private void initializeHand() {
		// Get a copy of this deck in the form of a stack of card
		Deque<Card> stack = Deck.cloneToStack(loadedDeck);
		// Take all the card to a hand of cards
		this.hand = new ArrayList<Card>(stack.size());
		Deck.takeCards(stack, hand, stack.size());
		// Sort the hand
		Collections.sort(hand);

		// Initialize menu items
		List<Card> trumps = new ArrayList<Card>(22);
		List<Card> swords = new ArrayList<Card>(14);
		List<Card> wands = new ArrayList<Card>(14);
		List<Card> pentacles = new ArrayList<Card>(14);
		List<Card> cups = new ArrayList<Card>(14);
		for (Card card : hand) {
			if (card.getString("suit").equals("Trumps")) trumps.add(card);
			else if (card.getString("suit").equals("Wands")) wands.add(card);
			else if (card.getString("suit").equals("Swords")) swords.add(card);
			else if (card.getString("suit").equals("Cups")) cups.add(card);
			else if (card.getString("suit").equals("Pentacles")) pentacles.add(card);
		}
		menu.setItems(true, trumps.toArray(), wands.toArray(), pentacles.toArray(), cups.toArray(), swords.toArray());
	}

	// KeyListener
	synchronized public void keyPressed(KeyEvent e) {
		// Global Input
		switch (e.getKeyCode()) {
		// Take a screenshot
			case KeyEvent.VK_F8:
				U.screenshot(this);
				break;
		}
		// Context Specific Input
		switch (context) {
			case MAIN_MENU:
				mainMenu.keyPressed(e);
				switch (e.getKeyCode()) {
					case KeyEvent.VK_ENTER:
						switch (mainMenu.getSelectedRow()) {
							case 0:
								// Spread
								changeContext(Context.SPREAD_MENU);
								break;
							case 1:
								// Browse Deck
								changeContext(Context.DECK_VIEW);
								break;
							case 2:
								// Change Deck
								nextDeck();
								loadMainMenu();
								break;
							case 3:
								// Change Language
								nextLanguage();
								loadMainMenu();
								break;
						}
						break;
					case KeyEvent.VK_ESCAPE:
						System.exit(1);
						break;
				}
				break;
			case SPREAD_MENU:
				spreadMenu.keyPressed(e);
				switch (e.getKeyCode()) {
					case KeyEvent.VK_ENTER:
						spread = loadedSpreads[spreadMenu.getSelectedRow()];
						changeContext(Context.SPREAD_VIEW);
						break;
					case KeyEvent.VK_ESCAPE:
						changeContext(Context.MAIN_MENU);
						break;
				}
				break;
			case DECK_VIEW:
				switch (e.getKeyCode()) {
					case KeyEvent.VK_ESCAPE:
						changeContext(Context.MAIN_MENU);
						break;
				}

				// Menu Mode (list of cards in deck per suit)
				if (showMenu) {
					menu.keyPressed(e); // let the menu handle all the directional events itself
					switch (e.getKeyCode()) {
						case KeyEvent.VK_M:
							showMenu = !showMenu;
							break;
						case KeyEvent.VK_ENTER:
							changeCard((Card) menu.getSelected());
							showMenu = false;
							break;
					}
				}
				// Regular Card View Mode
				else {
					switch (e.getKeyCode()) {
						case KeyEvent.VK_RIGHT:
							changeCard(M.nextIndex(currentIndex, hand.size()));
							break;
						case KeyEvent.VK_LEFT:
							changeCard(M.previousIndex(currentIndex, hand.size()));
							break;
						case KeyEvent.VK_UP:
							keywordList.up();
							break;
						case KeyEvent.VK_DOWN:
							keywordList.down();
							break;
						case KeyEvent.VK_Z:
							zoomState = M.nextIndex(zoomState, ZOOM_STATE_COUNT);
							zoom.start(0, 1, 1000, 0, TimingFunction.EASE, 0, false);
							break;
						case KeyEvent.VK_M:
							// find tarot specific row/col indices in menu ordered
							int row,
							col;
							if (currentIndex < 22) {
								col = 0;
								row = currentIndex;
							} else {
								int i = currentIndex - 22;
								col = 1 + (i / 14);
								row = i % 14;
							}
							menu.setSelected(row, col);
							showMenu = !showMenu;
							break;
					}
				}

				break;
			case SPREAD_VIEW:
				switch (e.getKeyCode()) {
					case KeyEvent.VK_ESCAPE:
						changeContext(Context.SPREAD_MENU);
						break;
					case KeyEvent.VK_LEFT:
						if (zoomed) {
							zoomedCard = M.previousIndex(zoomedCard, revealed);
							keywordList.setItems(true, cards[zoomedCard].keywords.toArray());
							panTransition.start(panTransition.get(panBuffer), getCurrentCardPan(), 1000, 0, TimingFunction.EASE, 0, false);
						}
						break;
					case KeyEvent.VK_RIGHT:
						if (zoomed) {
							zoomedCard = M.nextIndex(zoomedCard, revealed);
							keywordList.setItems(true, cards[zoomedCard].keywords.toArray());
							panTransition.start(panTransition.get(panBuffer), getCurrentCardPan(), 1000, 0, TimingFunction.EASE, 0, false);
						}
						break;
					case KeyEvent.VK_UP:
						keywordList.up();
						break;
					case KeyEvent.VK_DOWN:
						keywordList.down();
						break;
					case KeyEvent.VK_N:
						showName = !showName;
						break;
					case KeyEvent.VK_D:
						showKeywords = !showKeywords;
						break;
					case KeyEvent.VK_Z: {
						zoomed = revealed > 0 ? !zoomed : zoomed;
						panTransition.get(panBuffer);
						double to[] = (zoomed ? getCurrentCardPan() : new double[] { 0, 0, 1, 1 });
						panTransition.start(panBuffer, to, 1000, 0, TimingFunction.EASE, 0, false);
					}
						break;
					case KeyEvent.VK_ENTER:
						if (revealed < cardTransitions.length) {
							Point2D p = cardTransitions[revealed].get();
							cardTransitions[revealed].start(p.getX(), p.getY(), spread.items.get(revealed).x, spread.items.get(revealed).y, 1000, 0, TimingFunction.EASE, 0, false);
							revealed++;
							updateBackground();
						}
						break;
				}
				break;
		}
	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {
	}

}
