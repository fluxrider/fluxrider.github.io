/*
 * TODO Copyright (c)
 */

package flux.card.tarot;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JPanel;

import flux.card.Card;
import flux.card.Deck;
import flux.image.I;
import flux.input.EventBasedKeyboard;
import flux.math.M;
import flux.math.M.TimingFunction;
import flux.util.FPS;
import flux.util.ToStringer;
import flux.util.Transition;
import flux.util.U;
import flux.widget.FList;

/**
 * This class is a stand-alone gui application to browser a deck of Tarot cards. It relies on Tarot specific attributes.
 * 
 * <p>
 * It loads a deck of card, makes a stack out of it, grab all the cards into a hand, and sort them. Afterwhich the user is free to browser the hand.
 * 
 * <p>
 * TODO <br>
 * better icons <br>
 * better cards <br>
 * code needs to be super clean and without hardcoded stuff: this project is meant to be a base for successive card projects<br>
 * background could change when navigating main menu<br>
 * BUG: hardcoded values for layout that crap on different dimension
 * 
 * @author David Lareau
 */

public class TarotDeckViewer extends JPanel implements KeyListener, Runnable, ToStringer<Card> {

	// Attributes
	private TarotBackground bg;
	private Thread paintThread;
	private Font font;
	private FPS fps;

	private List<Card> hand;
	private TarotCard current, next, previous;
	private TarotCard goner, newcomer;
	private int currentIndex;

	private FList keywordList;
	private FList menu;

	private Transition offset;
	private Transition zoom;

	private enum ZoomState {
		// Unfortunatly, font metrics are only available when paint, so the screen coverage zoom parameter are hardcoded
		// BUG: these don't work in different screen size!
		FULLSCREEN_IMAGE(1),
		IMAGE_AND_NAME(.95),
		IMAGE_AND_FULL_DETAILS(.75);

		private double zoom;

		private ZoomState(double zoom) {
			this.zoom = zoom;
		}

		public double getZoom() {
			return zoom;
		}

		public ZoomState next() {
			switch (this) {
				case FULLSCREEN_IMAGE:
					return IMAGE_AND_NAME;
				case IMAGE_AND_NAME:
					return IMAGE_AND_FULL_DETAILS;
				case IMAGE_AND_FULL_DETAILS:
				default:
					return FULLSCREEN_IMAGE;
			}
		}
	};

	private ZoomState zoomState;

	private boolean showMenu;

	// Construct
	public TarotDeckViewer() {
		menu = new FList(this, true);
		keywordList = new FList(this, false);

		zoomState = ZoomState.IMAGE_AND_FULL_DETAILS;
		zoom = new Transition(zoomState.getZoom());
		paintThread = new Thread(this);
		paintThread.start();

		fps = new FPS();

		initializeHand();

		font = new Font(Font.SANS_SERIF, Font.PLAIN, 18);

		bg = new TarotBackground(128, 128);
		offset = new Transition(0);

		changeCard(0);
	}

	// Paint
	synchronized public void paint(Graphics g) {
		int _W = getWidth();
		int _H = getHeight();
		g.setFont(font);
		FontMetrics metrics = g.getFontMetrics();
		int dy = metrics.getHeight();

		bg.paint(g, 0, 0, _W, _H);

		int marginX = 5;
		int marginY = 5;
		int X = marginX;
		int Y = marginY;
		int W = _W - marginX * 2;
		int H = _H - marginY * 2;

		if (showMenu) {
			menu.draw(g, font, X, Y, W, H, Tarot.arrows);
		} else {
			{
				double a = offset.get();
				int dx = M.r(M.sign(a) * W - a * W);
				int cardHeight = M.r(H * zoom.get());

				// previous card
				if (goner != null && offset.getTotalRatio() < 1) {
					int gdx = M.r(-W * a);
					if (goner.image != null) I.drawImage((Graphics2D) g, X + gdx, Y, W, cardHeight, goner.image, null, true, true, null);
				}

				// current card
				TarotCard card = newcomer;
				int nameY = cardHeight + dy;
				int nameX = X + dx + (W - metrics.stringWidth(card.name)) / 2;
				int listY = Y + nameY + metrics.getDescent();
				int listH = H - listY;
				g.setColor(Color.BLACK);
				if (zoomState != ZoomState.FULLSCREEN_IMAGE) g.drawString(card.name, nameX, nameY);
				if (zoomState == ZoomState.IMAGE_AND_FULL_DETAILS) keywordList.draw(g, font, X + dx, listY, W, listH, Tarot.arrows);

				if (card.image != null) I.drawImage((Graphics2D) g, X + dx, Y, W, cardHeight, card.image, null, true, true, null);
			}
		}

		fps.frame();
	}

	// Private Methods
	private void changeCard(Card card) {
		changeCard(hand.indexOf(card));
	}

	private void changeCard(int newIndex) {
		goner = current;
		int c = newIndex;
		int p = M.previousIndex(newIndex, hand.size());
		int n = M.nextIndex(newIndex, hand.size());

		int direction = 1;
		// forward change
		if (c == M.nextIndex(currentIndex, hand.size())) {
			previous = current;
			current = next;
			next = new TarotCard(hand.get(n));
		}
		// backward change
		else if (c == M.previousIndex(currentIndex, hand.size())) {
			direction = -1;
			next = current;
			current = previous;
			previous = new TarotCard(hand.get(p));
		}
		// jump
		else if (c != currentIndex) {
			current = new TarotCard(hand.get(c));
			next = new TarotCard(hand.get(n));
			previous = new TarotCard(hand.get(p));
		}

		if (current == null) current = new TarotCard(hand.get(c));
		if (next == null) next = new TarotCard(hand.get(n));
		if (previous == null) previous = new TarotCard(hand.get(p));

		currentIndex = newIndex;
		keywordList.setItems(true, current.keywords.toArray());
		bg.changeLogo(current.suit);

		// slide card
		newcomer = current;
		if (goner != newcomer) offset.start(0, direction, 1000, 0, TimingFunction.EASE, 0, false);
	}

	public void run() {
		while (paintThread == Thread.currentThread()) {
			repaint();
			U.yieldForRepaint();
		}
	}

	private void initializeHand() {
		// Load the deck of card
		Map<String, Card> deck = Tarot.loadDeck();
		// Get a copy of this deck in the form of a stack of card
		Deque<Card> stack = Deck.cloneToStack(deck);
		// Take all the card to a hand of cards
		this.hand = new ArrayList<Card>(stack.size());
		Deck.takeCards(stack, hand, stack.size());
		// Sort the hand
		Collections.sort(hand);

		// Initialize menu items
		List<Card> trumps = new ArrayList<Card>(22);
		List<Card> swords = new ArrayList<Card>(14);
		List<Card> wands = new ArrayList<Card>(14);
		List<Card> pentacles = new ArrayList<Card>(14);
		List<Card> cups = new ArrayList<Card>(14);
		for (Card card : hand) {
			if (card.getString("suit").equals("Trumps")) trumps.add(card);
			else if (card.getString("suit").equals("Wands")) wands.add(card);
			else if (card.getString("suit").equals("Swords")) swords.add(card);
			else if (card.getString("suit").equals("Cups")) cups.add(card);
			else if (card.getString("suit").equals("Pentacles")) pentacles.add(card);
		}
		menu.setItems(true, trumps.toArray(), wands.toArray(), pentacles.toArray(), cups.toArray(), swords.toArray());
	}

	synchronized public void keyPressed(KeyEvent e) {
		// Menu Mode (list of cards in deck per suit)
		if (showMenu) {
			menu.keyPressed(e); // let the menu handle all the directional events itself
			switch (e.getKeyCode()) {
				case KeyEvent.VK_ESCAPE:
					showMenu = !showMenu;
					break;
				case KeyEvent.VK_ENTER:
					changeCard((Card) menu.getSelected());
					showMenu = false;
					break;
			}
		}
		// Regular Card View Mode
		else {
			switch (e.getKeyCode()) {
				case KeyEvent.VK_RIGHT:
					changeCard(M.nextIndex(currentIndex, hand.size()));
					break;
				case KeyEvent.VK_LEFT:
					changeCard(M.previousIndex(currentIndex, hand.size()));
					break;
				case KeyEvent.VK_UP:
					keywordList.up();
					break;
				case KeyEvent.VK_DOWN:
					keywordList.down();
					break;
				case KeyEvent.VK_Z:
					zoomState = zoomState.next();
					zoom.start(zoom.get(), zoomState.getZoom(), 1000, 0, TimingFunction.EASE, 0, false);
					break;
				case KeyEvent.VK_ESCAPE:
					// find tarot specific row/col indices in menu ordered
					int row,
					col;
					if (currentIndex < 22) {
						col = 0;
						row = currentIndex;
					} else {
						int i = currentIndex - 22;
						col = 1 + (i / 14);
						row = i % 14;
					}
					menu.setSelected(row, col);
					showMenu = !showMenu;
					break;
			}
		}

	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {
	}

	// Main
	public static void main(String[] args) {
		EventBasedKeyboard.init();
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(10, 10, 800, 600);
		frame.setContentPane(new TarotDeckViewer());
		frame.setVisible(true);
		EventBasedKeyboard.addListener((KeyListener) frame.getContentPane());
	}

	public String toString(Card card) {
		return card.getString("name");
	}

}
