/*
 * TODO Copyright (c)
 */

package flux.card;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import flux.util.ToStringer;

/**
 * This class represents a Card.
 * <p>
 * Cards belong to a deck, and have an implicit order value used for sorting the deck. (Note that this value may not be sequential).
 * <p>
 * All other attributes are considered too specific thus stored as user-content in a dynamic Map.
 * <p>
 * Example of possible user attributes are name, value, suit, description, imageFile.
 * 
 * @author David Lareau
 */

public class Card implements Comparable<Card> {

	// Attributes
	private int deckOrder;
	private Map<String, Object> attributes;
	private ToStringer<Card> toStringer;

	// Construct
	public Card(int deckOrder, ToStringer<Card> toStringer) {
		this.toStringer = toStringer;
		this.deckOrder = deckOrder;
		this.attributes = new TreeMap<String, Object>();
	}

	// Methods
	public void set(String attribute, Object value) {
		attributes.put(attribute, value);
	}

	public void setString(String attribute, String value) {
		set(attribute, value);
	}

	public void setInt(String attribute, int value) {
		set(attribute, value);
	}

	public void addString(String listAttribute, String value) {
		List<String> list = getStrings(listAttribute);
		list.add(value);
	}

	public Object get(String attribute) {
		return attributes.get(attribute);
	}

	public String getString(String attribute) {
		return (String) get(attribute);
	}

	public int getInt(String attribute) {
		return (Integer) get(attribute);
	}

	public List<String> getStrings(String listAttribute) {
		List<String> list = (List<String>) get(listAttribute);
		if (list == null) {
			list = new LinkedList<String>();
			set(listAttribute, list);
		}
		return list;
	}

	// Comparable
	public int compareTo(Card o) {
		return deckOrder - o.deckOrder;
	}

	// ToString
	public String toString() {
		if (toStringer != null) return toStringer.toString(this);
		StringBuilder s = new StringBuilder();
		s.append("Card(");
		s.append(deckOrder);
		s.append(",");
		s.append(attributes);
		s.append(")");
		return s.toString();
	}

}
