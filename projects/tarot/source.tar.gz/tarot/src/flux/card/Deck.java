/*
 * TODO Copyright (c)
 */

package flux.card;

import java.io.File;
import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.Map;
import java.util.TreeMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import flux.util.ToStringer;

/**
 * This class loads a deck of card to be used by the application.
 * 
 * @author David Lareau
 */

public class Deck {

	public static Map<String, Card> load(ToStringer<Card> toStringer, String deckFilename, String... userdataFilenames) {
		Map<String, Card> deck = new TreeMap<String, Card>();

		try {
			// Parse deck description file
			{
				// <deck>
				// <card id="fool"/>
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document document = builder.parse(new File(deckFilename));
				Element root = document.getDocumentElement();
				NodeList cards = root.getChildNodes();
				// Create a Card object for each card in the deck
				for (int i = 0; i < cards.getLength(); i++) {
					Node node = cards.item(i);
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element card = (Element) node;
						String id = card.getAttributes().getNamedItem("id").getNodeValue();
						if (deck.containsKey(id)) throw new RuntimeException("Duplicate card id at item " + i + ": " + id); // detect duplicate id
						deck.put(id, new Card(i, toStringer));
					}
				}
			}

			// Parse userdata description files
			for (String userdataFilename : userdataFilenames) {
				// <userdata>
				// <data key="name" type="String" card="fool" value="0 - The Fool"/>
				// type="String List"
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
				DocumentBuilder builder = factory.newDocumentBuilder();
				Document document = builder.parse(new File(userdataFilename));
				Element root = document.getDocumentElement();
				NodeList entries = root.getChildNodes();
				// Parse each data entry, and add the user data to the appropriate card of the deck
				for (int i = 0; i < entries.getLength(); i++) {
					Node node = entries.item(i);
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element data = (Element) node;
						String id = data.getAttributes().getNamedItem("card").getNodeValue();
						String key = data.getAttributes().getNamedItem("key").getNodeValue();
						String type = data.getAttributes().getNamedItem("type").getNodeValue();
						String value = data.getAttributes().getNamedItem("value").getNodeValue();
						if (type.equals("String")) {
							Card card = deck.get(id);
							card.setString(key, value); // I support overwriting values, it is not an error if a subsequent file reinitializes a value
						} else if (type.equals("String List")) {
							Card card = deck.get(id);
							card.addString(key, value); // I only support appending, there is no support for overwriting lists at this time
						}
					}
				}
			}
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e);
		} catch (SAXException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return deck;
	}

	public static Deque<Card> cloneToStack(Map<String, Card> deck) {
		Deque<Card> stack = new ArrayDeque<Card>(deck.size());
		stack.addAll(deck.values());
		return stack;
	}

	public static Deque<Card> cloneToShuffledStack(Map<String, Card> deck) {
		ArrayList<Card> list = new ArrayList<Card>(deck.size());
		list.addAll(deck.values());
		Collections.shuffle(list);
		Deque<Card> stack = new ArrayDeque<Card>(deck.size());
		stack.addAll(list);
		return stack;
	}

	public static void takeCards(Deque<Card> fromStack, Collection<Card> to, int n) {
		for (int i = 0; i < n; i++)
			to.add(fromStack.pop());
	}

}
