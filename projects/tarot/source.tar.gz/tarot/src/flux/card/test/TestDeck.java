/*
 * TODO Copyright (c)
 */

package flux.card.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.Map;

import flux.card.Card;
import flux.card.Deck;

/**
 * This class is a stand-alone text application that loads a deck of card, make a stack out of it, grab all the cards into a hand, sort them and call
 * the toString of each cards in the hand.
 * 
 * @author David Lareau
 */

public class TestDeck {

	public static void main(String[] args) {
		// Load the deck of card
		System.out.print("Loading deck...");
		System.out.flush();
		String resFolder = "/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/";
		String deckFilename = "tarot.deck";
		String userdataFilename = "tarot.en.data";
		Map<String, Card> deck = Deck.load(null, resFolder + deckFilename, resFolder + userdataFilename);
		System.out.println("Done");

		// Get a copy of this deck in the form of a stack of card
		Deque<Card> stack = Deck.cloneToStack(deck);

		// Take all the card to a hand of cards
		List<Card> hand = new ArrayList<Card>(stack.size());
		Deck.takeCards(stack, hand, stack.size());

		// Sort the hand (TODO shuffle as a test, and TODO resort as a test)
		Collections.sort(hand);
		// Collections.shuffle(hand);
		// Collections.sort(hand);

		// Let the user cycle through his hand with left/right keys, and display the card info on screen
		for (Card card : hand) {
			System.out.println(card);
		}
	}
}
