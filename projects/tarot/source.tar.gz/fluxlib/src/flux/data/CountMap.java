/*
 * TODO Copyright (c)
 */

package flux.data;

import java.util.Map;
import java.util.TreeMap;

/**
 * This class associated a count value to each key. And then support giving the keys back sorted by count. TODO this class isn't complete yet, I'm not
 * sure what's the best approach
 * 
 * @author David Lareau
 */

public class CountMap<T> {

	// Attributes
	private Map<T, Integer> map;

	// Construct
	public CountMap() {
		map = new TreeMap<T, Integer>();
	}

	// Methods
	public void increment(T key) {
		Integer count = map.get(key);
		if (count == null) count = new Integer(0);
		map.put(key, count + 1);
	}

	public int getCount(T key) {
		return map.get(key);
	}
	
	public T getMax() {
		T max = null;
		int value = 0;
		for (T key : map.keySet()) {
			if (max == null || map.get(key) > value) {
				max = key;
				value = map.get(key);
			}
		}
		return max;
	}

}
