/*
 * Written by David Lareau on February 24, 2010.
 * 
 * Circular list of double that overwrites old values as new values are added
 *  (set does not refresh the freshness of a value)
 */
package flux.data;

public class OverwriteCircularArray_double {

	// Attributes
	private int capacity;
	private int length;
	private int cursor; // points at position that will be overwritten next
	private double t[];

	// Construct
	public OverwriteCircularArray_double(int capacity) {
		this.capacity = capacity;
		t = new double[capacity];
	}

	// Methods
	public void add(double x) {
		t[cursor] = x;
		cursor = (cursor + 1) % capacity;
		length = Math.min(length + 1, capacity);
	}

	public void set(int i, double x) {
		if (i >= length || i < 0) throw new ArrayIndexOutOfBoundsException(i);
		t[index(i)] = x;
	}

	public void remove(int i) {
		if (i >= length || i < 0) throw new ArrayIndexOutOfBoundsException(i);
		if (length == 0) return;
		// remove last
		if (i == length - 1) {
			length--;
			cursor--;
			if (cursor < 0) cursor = capacity - 1;
		}
		// remove first
		else if (i == 0) {
			length--;
		}
		// remove any other
		else {
			int previous = index(i);
			for (int j = (previous + 1) % capacity; j != cursor; j = (j + 1) % capacity) {
				t[previous] = t[j];
				previous = j;
			}
			length--;
			cursor = previous;
		}
	}

	public void clear() {
		length = 0;
	}

	public double get(int i) {
		if (i >= length || i < 0) throw new ArrayIndexOutOfBoundsException(i);
		return t[index(i)];
	}

	public int size() {
		return length;
	}

	public boolean full() {
		return length == capacity;
	}

	public boolean empty() {
		return length == 0;
	}

	// Private Methods
	private int index(int i) {
		int first = cursor - length;
		if (first < 0) first += capacity;
		return (first + i) % capacity;
	}

	// Test
	public String toString() {
		StringBuilder s = new StringBuilder();
		s.append("Size ");
		s.append(size());
		s.append(": ");
		for (int i = 0; i < size(); i++) {
			s.append(get(i));
			if (i != size() - 1) s.append(' ');
		}
		return s.toString();
	}

	public static void main(String[] args) {
		OverwriteCircularArray_double t = new OverwriteCircularArray_double(5);
		System.out.println(t);
		for (int i = 1; i <= 10; i++) {
			t.add(i);
			System.out.println(t);
		}
	}

}
