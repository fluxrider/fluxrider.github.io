/*
 * Written by David Lareau on February 26, 2010.
 * 
 * Generic Circular list that overwrites old values as new values are added
 *  (set does not refresh the freshness of a value)
 */
package flux.data;

public class OverwriteCircularArray<T> {

	// Attributes
	private int capacity;
	private int length;
	private int cursor; // points at position that will be overwritten next
	private T t[];

	// Construct
	@SuppressWarnings("unchecked")
	public OverwriteCircularArray(int capacity) {
		this.capacity = capacity;
		t = (T[]) new Object[capacity];
	}

	// Methods
	public void add(T x) {
		t[cursor] = x;
		cursor = (cursor + 1) % capacity;
		length = Math.min(length + 1, capacity);
	}

	public void set(int i, T x) {
		if (i >= length || i < 0) throw new ArrayIndexOutOfBoundsException(i);
		t[index(i)] = x;
	}

	public void remove(int i) {
		if (i >= length || i < 0) throw new ArrayIndexOutOfBoundsException(i);
		if (length == 0) return;
		// remove last
		if (i == length - 1) {
			length--;
			cursor--;
			if (cursor < 0) cursor = capacity - 1;
		}
		// remove first
		else if (i == 0) {
			length--;
		}
		// remove any other
		else {
			int previous = index(i);
			for (int j = (previous + 1) % capacity; j != cursor; j = (j + 1) % capacity) {
				t[previous] = t[j];
				previous = j;
			}
			length--;
			cursor = previous;
		}
	}

	public void clear() {
		length = 0;
	}

	public T get(int i) {
		if (i >= length || i < 0) throw new ArrayIndexOutOfBoundsException(i);
		return t[index(i)];
	}

	public int size() {
		return length;
	}

	public boolean full() {
		return length == capacity;
	}

	public boolean empty() {
		return length == 0;
	}

	// Private Methods
	private int index(int i) {
		int first = cursor - length;
		if (first < 0) first += capacity;
		return (first + i) % capacity;
	}

}
