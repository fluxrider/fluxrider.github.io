package flux.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import junit.framework.Assert;

import org.junit.Test;

import flux.math.M;
import flux.random.R;

public class TestM {

	@Test
	public void test_normalized() {
		assertTrue(M.isNormalized(0));
		assertTrue(M.isNormalized(0.5));
		assertTrue(M.isNormalized(1));
		assertTrue(M.isNormalized(0.988));
		assertFalse(M.isNormalized(1.00001));
		assertFalse(M.isNormalized(-0.00001));
		assertFalse(M.isNormalized(2));
		assertFalse(M.isNormalized(-1));
	}

	@Test
	public void test_round() {
		Assert.assertEquals(0.2145, 0.2145);
		Assert.assertEquals(0.2145, M.round(0.2145, 4));
		Assert.assertEquals(0.215, M.round(0.2145, 3));
		Assert.assertEquals(0.21, M.round(0.2145, 2));
		Assert.assertEquals(0.2, M.round(0.2145, 1));
		Assert.assertEquals(0.0, M.round(0.2145, 0));
		Assert.assertEquals(0.2145, M.round(0.2145, 10));
	}

	@Test
	public void test_bound() {
		// [0, 1] capped
		Assert.assertEquals(0.0, M.boundCropNormalized(0));
		Assert.assertEquals(1.0, M.boundCropNormalized(1));
		Assert.assertEquals(0.0, M.boundCropNormalized(-0.0001));
		Assert.assertEquals(1.0, M.boundCropNormalized(1.343));
		Assert.assertEquals(0.0, M.boundCropNormalized(-1));
		Assert.assertEquals(1.0, M.boundCropNormalized(2));
		for (int i = 0; i < 100; i++) {
			double r = R.uniform_exclusive_normalized();
			Assert.assertEquals(r, M.boundCropNormalized(r));
		}

		// [0, 1[ cyclic
		Assert.assertEquals(0.0, M.boundCyclicNormalized(0));
		Assert.assertEquals(0.0, M.boundCyclicNormalized(1));
		Assert.assertEquals(0.9, M.round(M.boundCyclicNormalized(-0.1), 1));
		Assert.assertEquals(0.9, M.round(M.boundCyclicNormalized(-1.1), 1));
		Assert.assertEquals(0.0, M.round(M.boundCyclicNormalized(-1), 1));
		Assert.assertEquals(0.0, M.round(M.boundCyclicNormalized(-2), 1));
		Assert.assertEquals(0.0, M.round(M.boundCyclicNormalized(2), 1));
		for (int i = 0; i < 100; i++) {
			double r = R.uniform_exclusive_normalized();
			int offset = R.uniform_inclusive_s32(-10, 10);
			Assert.assertEquals(M.round(r, 4), M.round(M.boundCyclicNormalized(offset + r), 4));
		}

		// [0, 1] cyclic back and forth
		Assert.assertEquals(0.0, M.boundCyclicBackAndForthNormalized(0));
		Assert.assertEquals(1.0, M.boundCyclicBackAndForthNormalized(1));
		Assert.assertEquals(0.0, M.round(M.boundCyclicBackAndForthNormalized(2), 1));
		Assert.assertEquals(1.0, M.round(M.boundCyclicBackAndForthNormalized(3), 1));

		Assert.assertEquals(0.1, M.boundCyclicBackAndForthNormalized(0.1));
		Assert.assertEquals(0.9, M.round(M.boundCyclicBackAndForthNormalized(1.1), 4));
		Assert.assertEquals(0.1, M.round(M.boundCyclicBackAndForthNormalized(2.1), 4));

		Assert.assertEquals(0.1, M.boundCyclicBackAndForthNormalized(-0.1));
		Assert.assertEquals(1.0, M.round(M.boundCyclicBackAndForthNormalized(-1), 1));
		Assert.assertEquals(0.9, M.round(M.boundCyclicBackAndForthNormalized(-1.1), 1));
		Assert.assertEquals(0.0, M.round(M.boundCyclicBackAndForthNormalized(-2), 1));

		Assert.assertEquals(4.0, M.boundCrop(8, 2, 4));
		Assert.assertEquals(4.0, M.boundCyclic(7, 2, 5));
		Assert.assertEquals(4.0, M.boundCyclicBackAndForth(8, 2, 4));

		for (int i = 0; i < 15; i++) {
			Assert.assertEquals(i % 3, M.boundCyclicCapacity(i, 3));
		}
		Assert.assertEquals(2, M.boundCyclicCapacity(-1, 3));
		Assert.assertEquals(1, M.boundCyclicCapacity(-2, 3));
		Assert.assertEquals(0, M.boundCyclicCapacity(-3, 3));
		Assert.assertEquals(2, M.boundCyclicCapacity(-4, 3));
		Assert.assertEquals(1, M.boundCyclicCapacity(-5, 3));
		Assert.assertEquals(0, M.boundCyclicCapacity(-6, 3));
		Assert.assertEquals(2, M.boundCyclicCapacity(-7, 3));
		Assert.assertEquals(1, M.boundCyclicCapacity(-8, 3));
		Assert.assertEquals(0, M.boundCyclicCapacity(-9, 3));
		Assert.assertEquals(3, M.boundCyclicCapacity(-1, 4));
		Assert.assertEquals(2, M.boundCyclicCapacity(-2, 4));
		Assert.assertEquals(1, M.boundCyclicCapacity(-3, 4));
		Assert.assertEquals(0, M.boundCyclicCapacity(-4, 4));
		Assert.assertEquals(3, M.boundCyclicCapacity(-5, 4));
		Assert.assertEquals(2, M.boundCyclicCapacity(-6, 4));

		for (int offset = -3; offset < 3; offset++) {
			int range = 8;
			Assert.assertEquals(-5, M.boundCyclicInt(-5 + offset*range, -5, 2));
			Assert.assertEquals(-4, M.boundCyclicInt(-4 + offset*range, -5, 2));
			Assert.assertEquals(-3, M.boundCyclicInt(-3 + offset*range, -5, 2));
			Assert.assertEquals(-2, M.boundCyclicInt(-2 + offset*range, -5, 2));
			Assert.assertEquals(-1, M.boundCyclicInt(-1 + offset*range, -5, 2));
			Assert.assertEquals(0, M.boundCyclicInt(0 + offset*range, -5, 2));
			Assert.assertEquals(1, M.boundCyclicInt(1 + offset*range, -5, 2));
			Assert.assertEquals(2, M.boundCyclicInt(2 + offset*range, -5, 2));
		}
	}

}
