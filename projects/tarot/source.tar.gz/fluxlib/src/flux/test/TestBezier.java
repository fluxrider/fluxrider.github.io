package flux.test;

import junit.framework.Assert;

import org.junit.Test;

import flux.math.Bezier;
import flux.math.M;

public class TestBezier {

	public void myAssertEquals(double expected, double actual) {
		expected = M.round(expected, 4);
		actual = M.round(actual, 4);
		Assert.assertTrue("Expected <" + expected + "> actual <" + actual + ">", M.isInside(actual, expected - 0.0002, expected + 0.0002));
		// Assert.assertEquals(expected, actual);
	}

	// Tests
	@Test
	public void test_parametric() {

		double x0 = 0, y0 = 0;
		double x3 = 1, y3 = 1;

		// linear
		{
			int N = 101;
			double x1 = 0, y1 = 0;
			double x2 = 1, y2 = 1;
			for (int i = 0; i < N; i++) {
				double t = i / (double) (N - 1);
				double x = M.cubicBezier(t, x0, x1, x2, x3);
				double y = M.cubicBezier(t, y0, y1, y2, y3);
				// System.out.println("B(" + t + ") = (" + x + "," + y + ")");
				myAssertEquals(x, y);
			}
		}

		// ease
		{
			double x1 = .25, y1 = .1;
			double x2 = .25, y2 = 1;
			myAssertEquals(0.0, M.cubicBezier(0, x0, x1, x2, x3));
			myAssertEquals(0.0, M.cubicBezier(0, y0, y1, y2, y3));
			myAssertEquals(1.0, M.cubicBezier(1, x0, x1, x2, x3));
			myAssertEquals(1.0, M.cubicBezier(1, y0, y1, y2, y3));
			myAssertEquals(0.0685, M.cubicBezier(0.1, x0, x1, x2, x3));
			myAssertEquals(0.0523, M.cubicBezier(0.1, y0, y1, y2, y3));
			myAssertEquals(0.1280, M.cubicBezier(0.2, x0, x1, x2, x3));
			myAssertEquals(0.1424, M.cubicBezier(0.2, y0, y1, y2, y3));
			myAssertEquals(0.1845, M.cubicBezier(0.3, x0, x1, x2, x3));
			myAssertEquals(0.2601, M.cubicBezier(0.3, y0, y1, y2, y3));
			myAssertEquals(0.2440, M.cubicBezier(0.4, x0, x1, x2, x3));
			myAssertEquals(0.3952, M.cubicBezier(0.4, y0, y1, y2, y3));
			myAssertEquals(0.3125, M.cubicBezier(0.5, x0, x1, x2, x3));
			myAssertEquals(0.5375, M.cubicBezier(0.5, y0, y1, y2, y3));
			myAssertEquals(0.3960, M.cubicBezier(0.6, x0, x1, x2, x3));
			myAssertEquals(0.6768, M.cubicBezier(0.6, y0, y1, y2, y3));
			myAssertEquals(0.5005, M.cubicBezier(0.7, x0, x1, x2, x3));
			myAssertEquals(0.8029, M.cubicBezier(0.7, y0, y1, y2, y3));
			myAssertEquals(0.6320, M.cubicBezier(0.8, x0, x1, x2, x3));
			myAssertEquals(0.9056, M.cubicBezier(0.8, y0, y1, y2, y3));
			myAssertEquals(0.7965, M.cubicBezier(0.9, x0, x1, x2, x3));
			myAssertEquals(0.9747, M.cubicBezier(0.9, y0, y1, y2, y3));
		}
		// ease-in
		{
			double x1 = .42, y1 = 0;
			double x2 = 1, y2 = 1;
			myAssertEquals(0.0, M.cubicBezier(0, x0, x1, x2, x3));
			myAssertEquals(0.0, M.cubicBezier(0, y0, y1, y2, y3));
			myAssertEquals(1.0, M.cubicBezier(1, x0, x1, x2, x3));
			myAssertEquals(1.0, M.cubicBezier(1, y0, y1, y2, y3));
			myAssertEquals(0.1301, M.cubicBezier(0.1, x0, x1, x2, x3));
			myAssertEquals(0.0280, M.cubicBezier(0.1, y0, y1, y2, y3));
			myAssertEquals(0.2653, M.cubicBezier(0.2, x0, x1, x2, x3));
			myAssertEquals(0.1040, M.cubicBezier(0.2, y0, y1, y2, y3));
			myAssertEquals(0.4012, M.cubicBezier(0.3, x0, x1, x2, x3));
			myAssertEquals(0.2160, M.cubicBezier(0.3, y0, y1, y2, y3));
			myAssertEquals(0.5334, M.cubicBezier(0.4, x0, x1, x2, x3));
			myAssertEquals(0.3520, M.cubicBezier(0.4, y0, y1, y2, y3));
			myAssertEquals(0.6575, M.cubicBezier(0.5, x0, x1, x2, x3));
			myAssertEquals(0.5000, M.cubicBezier(0.5, y0, y1, y2, y3));
			myAssertEquals(0.7690, M.cubicBezier(0.6, x0, x1, x2, x3));
			myAssertEquals(0.6480, M.cubicBezier(0.6, y0, y1, y2, y3));
			myAssertEquals(0.8634, M.cubicBezier(0.7, x0, x1, x2, x3));
			myAssertEquals(0.7840, M.cubicBezier(0.7, y0, y1, y2, y3));
			myAssertEquals(0.9363, M.cubicBezier(0.8, x0, x1, x2, x3));
			myAssertEquals(0.8960, M.cubicBezier(0.8, y0, y1, y2, y3));
			myAssertEquals(0.9833, M.cubicBezier(0.9, x0, x1, x2, x3));
			myAssertEquals(0.9720, M.cubicBezier(0.9, y0, y1, y2, y3));
		}
		// ease-out
		{
			double x1 = 0, y1 = 0;
			double x2 = .58, y2 = 1;
			myAssertEquals(0.0, M.cubicBezier(0, x0, x1, x2, x3));
			myAssertEquals(0.0, M.cubicBezier(0, y0, y1, y2, y3));
			myAssertEquals(1.0, M.cubicBezier(1, x0, x1, x2, x3));
			myAssertEquals(1.0, M.cubicBezier(1, y0, y1, y2, y3));
			myAssertEquals(0.0167, M.cubicBezier(0.1, x0, x1, x2, x3));
			myAssertEquals(0.0280, M.cubicBezier(0.1, y0, y1, y2, y3));
			myAssertEquals(0.0637, M.cubicBezier(0.2, x0, x1, x2, x3));
			myAssertEquals(0.1040, M.cubicBezier(0.2, y0, y1, y2, y3));
			myAssertEquals(0.1366, M.cubicBezier(0.3, x0, x1, x2, x3));
			myAssertEquals(0.2160, M.cubicBezier(0.3, y0, y1, y2, y3));
			myAssertEquals(0.2310, M.cubicBezier(0.4, x0, x1, x2, x3));
			myAssertEquals(0.3520, M.cubicBezier(0.4, y0, y1, y2, y3));
			myAssertEquals(0.3425, M.cubicBezier(0.5, x0, x1, x2, x3));
			myAssertEquals(0.5000, M.cubicBezier(0.5, y0, y1, y2, y3));
			myAssertEquals(0.4666, M.cubicBezier(0.6, x0, x1, x2, x3));
			myAssertEquals(0.6480, M.cubicBezier(0.6, y0, y1, y2, y3));
			myAssertEquals(0.5988, M.cubicBezier(0.7, x0, x1, x2, x3));
			myAssertEquals(0.7840, M.cubicBezier(0.7, y0, y1, y2, y3));
			myAssertEquals(0.7347, M.cubicBezier(0.8, x0, x1, x2, x3));
			myAssertEquals(0.8960, M.cubicBezier(0.8, y0, y1, y2, y3));
			myAssertEquals(0.8699, M.cubicBezier(0.9, x0, x1, x2, x3));
			myAssertEquals(0.9720, M.cubicBezier(0.9, y0, y1, y2, y3));
		}
		// ease-in-out
		{
			double x1 = .42, y1 = 0;
			double x2 = .58, y2 = 1;
			myAssertEquals(0.0, M.cubicBezier(0, x0, x1, x2, x3));
			myAssertEquals(0.0, M.cubicBezier(0, y0, y1, y2, y3));
			myAssertEquals(1.0, M.cubicBezier(1, x0, x1, x2, x3));
			myAssertEquals(1.0, M.cubicBezier(1, y0, y1, y2, y3));
			myAssertEquals(0.1187, M.cubicBezier(0.1, x0, x1, x2, x3));
			myAssertEquals(0.0280, M.cubicBezier(0.1, y0, y1, y2, y3));
			myAssertEquals(0.2250, M.cubicBezier(0.2, x0, x1, x2, x3));
			myAssertEquals(0.1040, M.cubicBezier(0.2, y0, y1, y2, y3));
			myAssertEquals(0.3218, M.cubicBezier(0.3, x0, x1, x2, x3));
			myAssertEquals(0.2160, M.cubicBezier(0.3, y0, y1, y2, y3));
			myAssertEquals(0.4125, M.cubicBezier(0.4, x0, x1, x2, x3));
			myAssertEquals(0.3520, M.cubicBezier(0.4, y0, y1, y2, y3));
			myAssertEquals(0.5000, M.cubicBezier(0.5, x0, x1, x2, x3));
			myAssertEquals(0.5000, M.cubicBezier(0.5, y0, y1, y2, y3));
			myAssertEquals(0.5875, M.cubicBezier(0.6, x0, x1, x2, x3));
			myAssertEquals(0.6480, M.cubicBezier(0.6, y0, y1, y2, y3));
			myAssertEquals(0.6782, M.cubicBezier(0.7, x0, x1, x2, x3));
			myAssertEquals(0.7840, M.cubicBezier(0.7, y0, y1, y2, y3));
			myAssertEquals(0.7750, M.cubicBezier(0.8, x0, x1, x2, x3));
			myAssertEquals(0.8960, M.cubicBezier(0.8, y0, y1, y2, y3));
			myAssertEquals(0.8813, M.cubicBezier(0.9, x0, x1, x2, x3));
			myAssertEquals(0.9720, M.cubicBezier(0.9, y0, y1, y2, y3));
		}
	}

	@Test
	public void test_solve() {
		// linear
		{
			int N = 101;
			double x1 = 0, y1 = 0;
			double x2 = 1, y2 = 1;
			for (int i = 0; i < N; i++) {
				double time = i / (double) (N - 1);
				double progress = Bezier.CubicBezierAtTime(time, x1, y1, x2, y2, 100);
				// System.out.println("f(" + time + ") = " + progress);
				myAssertEquals(time, progress);
			}
		}

		// ease
		{
			double x1 = .25, y1 = .1;
			double x2 = .25, y2 = 1;
			myAssertEquals(0.0, Bezier.CubicBezierAtTime(0, x1, y1, x2, y2, 100));
			myAssertEquals(1.0, Bezier.CubicBezierAtTime(1, x1, y1, x2, y2, 100));
			myAssertEquals(0.0948, Bezier.CubicBezierAtTime(0.1, x1, y1, x2, y2, 100));
			myAssertEquals(0.2952, Bezier.CubicBezierAtTime(0.2, x1, y1, x2, y2, 100));
			myAssertEquals(0.5133, Bezier.CubicBezierAtTime(0.3, x1, y1, x2, y2, 100));
			myAssertEquals(0.6825, Bezier.CubicBezierAtTime(0.4, x1, y1, x2, y2, 100));
			myAssertEquals(0.8024, Bezier.CubicBezierAtTime(0.5, x1, y1, x2, y2, 100));
			myAssertEquals(0.8852, Bezier.CubicBezierAtTime(0.6, x1, y1, x2, y2, 100));
			myAssertEquals(0.9408, Bezier.CubicBezierAtTime(0.7, x1, y1, x2, y2, 100));
			myAssertEquals(0.9756, Bezier.CubicBezierAtTime(0.8, x1, y1, x2, y2, 100));
			myAssertEquals(0.9943, Bezier.CubicBezierAtTime(0.9, x1, y1, x2, y2, 100));
		}
		// ease-in
		{
			double x1 = .42, y1 = 0;
			double x2 = 1, y2 = 1;
			myAssertEquals(0.0, Bezier.CubicBezierAtTime(0, x1, y1, x2, y2, 100));
			myAssertEquals(1.0, Bezier.CubicBezierAtTime(1, x1, y1, x2, y2, 100));
			myAssertEquals(0.017, Bezier.CubicBezierAtTime(0.1, x1, y1, x2, y2, 100));
			myAssertEquals(0.0623, Bezier.CubicBezierAtTime(0.2, x1, y1, x2, y2, 100));
			myAssertEquals(0.1296, Bezier.CubicBezierAtTime(0.3, x1, y1, x2, y2, 100));
			myAssertEquals(0.2149, Bezier.CubicBezierAtTime(0.4, x1, y1, x2, y2, 100));
			myAssertEquals(0.3153, Bezier.CubicBezierAtTime(0.5, x1, y1, x2, y2, 100));
			myAssertEquals(0.4291, Bezier.CubicBezierAtTime(0.6, x1, y1, x2, y2, 100));
			myAssertEquals(0.5548, Bezier.CubicBezierAtTime(0.7, x1, y1, x2, y2, 100));
			myAssertEquals(0.6916, Bezier.CubicBezierAtTime(0.8, x1, y1, x2, y2, 100));
			myAssertEquals(0.8394, Bezier.CubicBezierAtTime(0.9, x1, y1, x2, y2, 100));

		}
		// ease-out
		{
			double x1 = 0, y1 = 0;
			double x2 = .58, y2 = 1;
			myAssertEquals(0.0, Bezier.CubicBezierAtTime(0, x1, y1, x2, y2, 100));
			myAssertEquals(1.0, Bezier.CubicBezierAtTime(1, x1, y1, x2, y2, 100));
			myAssertEquals(0.1606, Bezier.CubicBezierAtTime(0.1, x1, y1, x2, y2, 100));
			myAssertEquals(0.3084, Bezier.CubicBezierAtTime(0.2, x1, y1, x2, y2, 100));
			myAssertEquals(0.4452, Bezier.CubicBezierAtTime(0.3, x1, y1, x2, y2, 100));
			myAssertEquals(0.5709, Bezier.CubicBezierAtTime(0.4, x1, y1, x2, y2, 100));
			myAssertEquals(0.6847, Bezier.CubicBezierAtTime(0.5, x1, y1, x2, y2, 100));
			myAssertEquals(0.7851, Bezier.CubicBezierAtTime(0.6, x1, y1, x2, y2, 100));
			myAssertEquals(0.8704, Bezier.CubicBezierAtTime(0.7, x1, y1, x2, y2, 100));
			myAssertEquals(0.9377, Bezier.CubicBezierAtTime(0.8, x1, y1, x2, y2, 100));
			myAssertEquals(0.983, Bezier.CubicBezierAtTime(0.9, x1, y1, x2, y2, 100));

		}
		// ease-in-out
		{
			double x1 = .42, y1 = 0;
			double x2 = .58, y2 = 1;
			myAssertEquals(0.0, Bezier.CubicBezierAtTime(0, x1, y1, x2, y2, 100));
			myAssertEquals(1.0, Bezier.CubicBezierAtTime(1, x1, y1, x2, y2, 100));
			myAssertEquals(0.0197, Bezier.CubicBezierAtTime(0.1, x1, y1, x2, y2, 100));
			myAssertEquals(0.0817, Bezier.CubicBezierAtTime(0.2, x1, y1, x2, y2, 100));
			myAssertEquals(0.1874, Bezier.CubicBezierAtTime(0.3, x1, y1, x2, y2, 100));
			myAssertEquals(0.3318, Bezier.CubicBezierAtTime(0.4, x1, y1, x2, y2, 100));
			myAssertEquals(0.5, Bezier.CubicBezierAtTime(0.5, x1, y1, x2, y2, 100));
			myAssertEquals(0.6682, Bezier.CubicBezierAtTime(0.6, x1, y1, x2, y2, 100));
			myAssertEquals(0.8126, Bezier.CubicBezierAtTime(0.7, x1, y1, x2, y2, 100));
			myAssertEquals(0.9183, Bezier.CubicBezierAtTime(0.8, x1, y1, x2, y2, 100));
			myAssertEquals(0.9803, Bezier.CubicBezierAtTime(0.9, x1, y1, x2, y2, 100));
		}
	}

	@Test
	public void test_search() {
		// linear
		{
			int N = 101;
			double x1 = 0, y1 = 0;
			double x2 = 1, y2 = 1;
			for (int i = 0; i < N; i++) {
				double time = i / (double) (N - 1);
				double progress = Bezier.cubicBezierTimingFunctionBinarySearch(time, x1, y1, x2, y2);
				// System.out.println("f(" + time + ") = " + progress);
				myAssertEquals(time, progress);
			}
		}

		// ease
		{
			double x1 = .25, y1 = .1;
			double x2 = .25, y2 = 1;
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionBinarySearch(0, x1, y1, x2, y2));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionBinarySearch(1, x1, y1, x2, y2));
			myAssertEquals(0.0948, Bezier.cubicBezierTimingFunctionBinarySearch(0.1, x1, y1, x2, y2));
			myAssertEquals(0.2952, Bezier.cubicBezierTimingFunctionBinarySearch(0.2, x1, y1, x2, y2));
			myAssertEquals(0.5133, Bezier.cubicBezierTimingFunctionBinarySearch(0.3, x1, y1, x2, y2));
			myAssertEquals(0.6825, Bezier.cubicBezierTimingFunctionBinarySearch(0.4, x1, y1, x2, y2));
			myAssertEquals(0.8024, Bezier.cubicBezierTimingFunctionBinarySearch(0.5, x1, y1, x2, y2));
			myAssertEquals(0.8852, Bezier.cubicBezierTimingFunctionBinarySearch(0.6, x1, y1, x2, y2));
			myAssertEquals(0.9408, Bezier.cubicBezierTimingFunctionBinarySearch(0.7, x1, y1, x2, y2));
			myAssertEquals(0.9756, Bezier.cubicBezierTimingFunctionBinarySearch(0.8, x1, y1, x2, y2));
			myAssertEquals(0.9943, Bezier.cubicBezierTimingFunctionBinarySearch(0.9, x1, y1, x2, y2));
		}
		// ease-in
		{
			double x1 = .42, y1 = 0;
			double x2 = 1, y2 = 1;
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionBinarySearch(0, x1, y1, x2, y2));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionBinarySearch(1, x1, y1, x2, y2));
			myAssertEquals(0.017, Bezier.cubicBezierTimingFunctionBinarySearch(0.1, x1, y1, x2, y2));
			myAssertEquals(0.0623, Bezier.cubicBezierTimingFunctionBinarySearch(0.2, x1, y1, x2, y2));
			myAssertEquals(0.1296, Bezier.cubicBezierTimingFunctionBinarySearch(0.3, x1, y1, x2, y2));
			myAssertEquals(0.2149, Bezier.cubicBezierTimingFunctionBinarySearch(0.4, x1, y1, x2, y2));
			myAssertEquals(0.3153, Bezier.cubicBezierTimingFunctionBinarySearch(0.5, x1, y1, x2, y2));
			myAssertEquals(0.4291, Bezier.cubicBezierTimingFunctionBinarySearch(0.6, x1, y1, x2, y2));
			myAssertEquals(0.5548, Bezier.cubicBezierTimingFunctionBinarySearch(0.7, x1, y1, x2, y2));
			myAssertEquals(0.6916, Bezier.cubicBezierTimingFunctionBinarySearch(0.8, x1, y1, x2, y2));
			myAssertEquals(0.8394, Bezier.cubicBezierTimingFunctionBinarySearch(0.9, x1, y1, x2, y2));

		}
		// ease-out
		{
			double x1 = 0, y1 = 0;
			double x2 = .58, y2 = 1;
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionBinarySearch(0, x1, y1, x2, y2));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionBinarySearch(1, x1, y1, x2, y2));
			myAssertEquals(0.1606, Bezier.cubicBezierTimingFunctionBinarySearch(0.1, x1, y1, x2, y2));
			myAssertEquals(0.3084, Bezier.cubicBezierTimingFunctionBinarySearch(0.2, x1, y1, x2, y2));
			myAssertEquals(0.4452, Bezier.cubicBezierTimingFunctionBinarySearch(0.3, x1, y1, x2, y2));
			myAssertEquals(0.5709, Bezier.cubicBezierTimingFunctionBinarySearch(0.4, x1, y1, x2, y2));
			myAssertEquals(0.6847, Bezier.cubicBezierTimingFunctionBinarySearch(0.5, x1, y1, x2, y2));
			myAssertEquals(0.7851, Bezier.cubicBezierTimingFunctionBinarySearch(0.6, x1, y1, x2, y2));
			myAssertEquals(0.8704, Bezier.cubicBezierTimingFunctionBinarySearch(0.7, x1, y1, x2, y2));
			myAssertEquals(0.9377, Bezier.cubicBezierTimingFunctionBinarySearch(0.8, x1, y1, x2, y2));
			myAssertEquals(0.983, Bezier.cubicBezierTimingFunctionBinarySearch(0.9, x1, y1, x2, y2));

		}
		// ease-in-out
		{
			double x1 = .42, y1 = 0;
			double x2 = .58, y2 = 1;
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionBinarySearch(0, x1, y1, x2, y2));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionBinarySearch(1, x1, y1, x2, y2));
			myAssertEquals(0.0197, Bezier.cubicBezierTimingFunctionBinarySearch(0.1, x1, y1, x2, y2));
			myAssertEquals(0.0817, Bezier.cubicBezierTimingFunctionBinarySearch(0.2, x1, y1, x2, y2));
			myAssertEquals(0.1874, Bezier.cubicBezierTimingFunctionBinarySearch(0.3, x1, y1, x2, y2));
			myAssertEquals(0.3318, Bezier.cubicBezierTimingFunctionBinarySearch(0.4, x1, y1, x2, y2));
			myAssertEquals(0.5, Bezier.cubicBezierTimingFunctionBinarySearch(0.5, x1, y1, x2, y2));
			myAssertEquals(0.6682, Bezier.cubicBezierTimingFunctionBinarySearch(0.6, x1, y1, x2, y2));
			myAssertEquals(0.8126, Bezier.cubicBezierTimingFunctionBinarySearch(0.7, x1, y1, x2, y2));
			myAssertEquals(0.9183, Bezier.cubicBezierTimingFunctionBinarySearch(0.8, x1, y1, x2, y2));
			myAssertEquals(0.9803, Bezier.cubicBezierTimingFunctionBinarySearch(0.9, x1, y1, x2, y2));
		}
	}

	@Test
	public void test_linear() {
		// linear
		{
			int N = 101;
			double x1 = 0, y1 = 0;
			double x2 = 1, y2 = 1;
			for (int i = 0; i < N; i++) {
				double time = i / (double) (N - 1);
				double progress = Bezier.cubicBezierTimingFunctionLinearApprox(time, x1, y1, x2, y2);
				// System.out.println("f(" + time + ") = " + progress);
				myAssertEquals(time, progress);
			}
		}

		// ease
		{
			double x1 = .25, y1 = .1;
			double x2 = .25, y2 = 1;
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionLinearApprox(0, x1, y1, x2, y2));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionLinearApprox(1, x1, y1, x2, y2));
			myAssertEquals(0.0948, Bezier.cubicBezierTimingFunctionLinearApprox(0.1, x1, y1, x2, y2));
			myAssertEquals(0.2952, Bezier.cubicBezierTimingFunctionLinearApprox(0.2, x1, y1, x2, y2));
			myAssertEquals(0.5133, Bezier.cubicBezierTimingFunctionLinearApprox(0.3, x1, y1, x2, y2));
			myAssertEquals(0.6825, Bezier.cubicBezierTimingFunctionLinearApprox(0.4, x1, y1, x2, y2));
			myAssertEquals(0.8024, Bezier.cubicBezierTimingFunctionLinearApprox(0.5, x1, y1, x2, y2));
			myAssertEquals(0.8852, Bezier.cubicBezierTimingFunctionLinearApprox(0.6, x1, y1, x2, y2));
			myAssertEquals(0.9408, Bezier.cubicBezierTimingFunctionLinearApprox(0.7, x1, y1, x2, y2));
			myAssertEquals(0.9756, Bezier.cubicBezierTimingFunctionLinearApprox(0.8, x1, y1, x2, y2));
			myAssertEquals(0.9943, Bezier.cubicBezierTimingFunctionLinearApprox(0.9, x1, y1, x2, y2));
		}
		// ease-in
		{
			double x1 = .42, y1 = 0;
			double x2 = 1, y2 = 1;
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionLinearApprox(0, x1, y1, x2, y2));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionLinearApprox(1, x1, y1, x2, y2));
			myAssertEquals(0.017, Bezier.cubicBezierTimingFunctionLinearApprox(0.1, x1, y1, x2, y2));
			myAssertEquals(0.0623, Bezier.cubicBezierTimingFunctionLinearApprox(0.2, x1, y1, x2, y2));
			myAssertEquals(0.1296, Bezier.cubicBezierTimingFunctionLinearApprox(0.3, x1, y1, x2, y2));
			myAssertEquals(0.2149, Bezier.cubicBezierTimingFunctionLinearApprox(0.4, x1, y1, x2, y2));
			myAssertEquals(0.3153, Bezier.cubicBezierTimingFunctionLinearApprox(0.5, x1, y1, x2, y2));
			myAssertEquals(0.4291, Bezier.cubicBezierTimingFunctionLinearApprox(0.6, x1, y1, x2, y2));
			myAssertEquals(0.5548, Bezier.cubicBezierTimingFunctionLinearApprox(0.7, x1, y1, x2, y2));
			myAssertEquals(0.6916, Bezier.cubicBezierTimingFunctionLinearApprox(0.8, x1, y1, x2, y2));
			myAssertEquals(0.8394, Bezier.cubicBezierTimingFunctionLinearApprox(0.9, x1, y1, x2, y2));

		}
		// ease-out
		{
			double x1 = 0, y1 = 0;
			double x2 = .58, y2 = 1;
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionLinearApprox(0, x1, y1, x2, y2));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionLinearApprox(1, x1, y1, x2, y2));
			myAssertEquals(0.1606, Bezier.cubicBezierTimingFunctionLinearApprox(0.1, x1, y1, x2, y2));
			myAssertEquals(0.3084, Bezier.cubicBezierTimingFunctionLinearApprox(0.2, x1, y1, x2, y2));
			myAssertEquals(0.4452, Bezier.cubicBezierTimingFunctionLinearApprox(0.3, x1, y1, x2, y2));
			myAssertEquals(0.5709, Bezier.cubicBezierTimingFunctionLinearApprox(0.4, x1, y1, x2, y2));
			myAssertEquals(0.6847, Bezier.cubicBezierTimingFunctionLinearApprox(0.5, x1, y1, x2, y2));
			myAssertEquals(0.7851, Bezier.cubicBezierTimingFunctionLinearApprox(0.6, x1, y1, x2, y2));
			myAssertEquals(0.8704, Bezier.cubicBezierTimingFunctionLinearApprox(0.7, x1, y1, x2, y2));
			myAssertEquals(0.9377, Bezier.cubicBezierTimingFunctionLinearApprox(0.8, x1, y1, x2, y2));
			myAssertEquals(0.983, Bezier.cubicBezierTimingFunctionLinearApprox(0.9, x1, y1, x2, y2));

		}
		// ease-in-out
		{
			double x1 = .42, y1 = 0;
			double x2 = .58, y2 = 1;
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionLinearApprox(0, x1, y1, x2, y2));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionLinearApprox(1, x1, y1, x2, y2));
			myAssertEquals(0.0197, Bezier.cubicBezierTimingFunctionLinearApprox(0.1, x1, y1, x2, y2));
			myAssertEquals(0.0817, Bezier.cubicBezierTimingFunctionLinearApprox(0.2, x1, y1, x2, y2));
			myAssertEquals(0.1874, Bezier.cubicBezierTimingFunctionLinearApprox(0.3, x1, y1, x2, y2));
			myAssertEquals(0.3318, Bezier.cubicBezierTimingFunctionLinearApprox(0.4, x1, y1, x2, y2));
			myAssertEquals(0.5, Bezier.cubicBezierTimingFunctionLinearApprox(0.5, x1, y1, x2, y2));
			myAssertEquals(0.6682, Bezier.cubicBezierTimingFunctionLinearApprox(0.6, x1, y1, x2, y2));
			myAssertEquals(0.8126, Bezier.cubicBezierTimingFunctionLinearApprox(0.7, x1, y1, x2, y2));
			myAssertEquals(0.9183, Bezier.cubicBezierTimingFunctionLinearApprox(0.8, x1, y1, x2, y2));
			myAssertEquals(0.9803, Bezier.cubicBezierTimingFunctionLinearApprox(0.9, x1, y1, x2, y2));
		}
	}

	@Test
	public void test_linearCached() {
		// linear
		{
			int N = 101;
			double x1 = 0, y1 = 0;
			double x2 = 1, y2 = 1;
			double x[] = Bezier.cubicBezierTimingFunctionLinearApproxBuildCache(x1, x2, 100);
			double y[] = Bezier.cubicBezierTimingFunctionLinearApproxBuildCache(y1, y2, 100);

			for (int i = 0; i < N; i++) {
				double time = i / (double) (N - 1);
				double progress = Bezier.cubicBezierTimingFunctionLinearApproxCached(time, x, y);
				// System.out.println("f(" + time + ") = " + progress);
				myAssertEquals(time, progress);
			}
		}

		// ease
		{
			double x1 = .25, y1 = .1;
			double x2 = .25, y2 = 1;
			double x[] = Bezier.cubicBezierTimingFunctionLinearApproxBuildCache(x1, x2, 100);
			double y[] = Bezier.cubicBezierTimingFunctionLinearApproxBuildCache(y1, y2, 100);
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionLinearApproxCached(0, x, y));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionLinearApproxCached(1, x, y));
			myAssertEquals(0.0948, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.1, x, y));
			myAssertEquals(0.2952, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.2, x, y));
			myAssertEquals(0.5133, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.3, x, y));
			myAssertEquals(0.6825, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.4, x, y));
			myAssertEquals(0.8024, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.5, x, y));
			myAssertEquals(0.8852, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.6, x, y));
			myAssertEquals(0.9408, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.7, x, y));
			myAssertEquals(0.9756, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.8, x, y));
			myAssertEquals(0.9943, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.9, x, y));
		}
		// ease-in
		{
			double x1 = .42, y1 = 0;
			double x2 = 1, y2 = 1;
			double x[] = Bezier.cubicBezierTimingFunctionLinearApproxBuildCache(x1, x2, 100);
			double y[] = Bezier.cubicBezierTimingFunctionLinearApproxBuildCache(y1, y2, 100);
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionLinearApproxCached(0, x, y));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionLinearApproxCached(1, x, y));
			myAssertEquals(0.017, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.1, x, y));
			myAssertEquals(0.0623, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.2, x, y));
			myAssertEquals(0.1296, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.3, x, y));
			myAssertEquals(0.2149, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.4, x, y));
			myAssertEquals(0.3153, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.5, x, y));
			myAssertEquals(0.4291, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.6, x, y));
			myAssertEquals(0.5548, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.7, x, y));
			myAssertEquals(0.6916, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.8, x, y));
			myAssertEquals(0.8394, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.9, x, y));

		}
		// ease-out
		{
			double x1 = 0, y1 = 0;
			double x2 = .58, y2 = 1;
			double x[] = Bezier.cubicBezierTimingFunctionLinearApproxBuildCache(x1, x2, 100);
			double y[] = Bezier.cubicBezierTimingFunctionLinearApproxBuildCache(y1, y2, 100);
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionLinearApproxCached(0, x, y));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionLinearApproxCached(1, x, y));
			myAssertEquals(0.1606, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.1, x, y));
			myAssertEquals(0.3084, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.2, x, y));
			myAssertEquals(0.4452, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.3, x, y));
			myAssertEquals(0.5709, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.4, x, y));
			myAssertEquals(0.6847, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.5, x, y));
			myAssertEquals(0.7851, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.6, x, y));
			myAssertEquals(0.8704, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.7, x, y));
			myAssertEquals(0.9377, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.8, x, y));
			myAssertEquals(0.983, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.9, x, y));

		}
		// ease-in-out
		{
			double x1 = .42, y1 = 0;
			double x2 = .58, y2 = 1;
			double x[] = Bezier.cubicBezierTimingFunctionLinearApproxBuildCache(x1, x2, 100);
			double y[] = Bezier.cubicBezierTimingFunctionLinearApproxBuildCache(y1, y2, 100);
			myAssertEquals(0.0, Bezier.cubicBezierTimingFunctionLinearApproxCached(0, x, y));
			myAssertEquals(1.0, Bezier.cubicBezierTimingFunctionLinearApproxCached(1, x, y));
			myAssertEquals(0.0197, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.1, x, y));
			myAssertEquals(0.0817, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.2, x, y));
			myAssertEquals(0.1874, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.3, x, y));
			myAssertEquals(0.3318, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.4, x, y));
			myAssertEquals(0.5, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.5, x, y));
			myAssertEquals(0.6682, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.6, x, y));
			myAssertEquals(0.8126, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.7, x, y));
			myAssertEquals(0.9183, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.8, x, y));
			myAssertEquals(0.9803, Bezier.cubicBezierTimingFunctionLinearApproxCached(0.9, x, y));
		}
	}

}
