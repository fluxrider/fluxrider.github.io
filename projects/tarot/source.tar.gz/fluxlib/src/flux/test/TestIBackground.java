package flux.test;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import flux.image.I;

public class TestIBackground extends JPanel {

	// Attributes
	private BufferedImage texture;
	private BufferedImage logo;

	// Construct
	public TestIBackground() throws IOException {
		texture = ImageIO.read(new File("/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/icons/texture00.png"));
		// logo = ImageIO.read(new File("/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/icons/pentagram-hi.png"));
		logo = ImageIO.read(new File("/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/icons/sword.png"));
	}

	// Paint
	public void paint(Graphics g) {
		int W = getWidth();
		int H = getHeight();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, W, H);

		int w = 128;
		int h = 128;
		Color fg = Color.BLUE;
		Color bg = Color.ORANGE;
		double textureOpacity = .5;
		double logoOpacity = .5;
		double logoRotation = 2 * Math.PI / 3;
		int centerLogo = 5;
		double logoScale = .5;
		BufferedImage coloredLogo = new BufferedImage(logo.getWidth(), logo.getHeight(), BufferedImage.TYPE_INT_ARGB);
		I.toColorMate(logo, coloredLogo, fg);
		for (int r = 0; r < 2; r++) {
			for (int c = 0; c < 3; c++) {
				int x = 100 + c * w;
				int y = 100 + r * h;
				I.paintSingleBackgroundTile((Graphics2D) g, x, y, w, h, bg, texture, textureOpacity, coloredLogo, logoOpacity, logoRotation, centerLogo, logoScale);
			}
		}
	}

	// Main
	public static void main(String[] args) throws IOException {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(10, 10, 800, 600);
		frame.setContentPane(new TestIBackground());
		frame.setVisible(true);
	}

}
