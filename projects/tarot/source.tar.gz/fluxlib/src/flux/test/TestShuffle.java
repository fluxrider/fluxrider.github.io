package flux.test;

import static org.junit.Assert.assertTrue;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;

import org.junit.Test;

import flux.math.M;
import flux.random.Shuffle;

public class TestShuffle {

	// Util
	private static final long N = 10000000;

	public void experiment(int k) {
		Map<String, Integer> count = new TreeMap<String, Integer>();

		// Create an array
		Integer tokens[] = new Integer[k];

		// Repeat experiment N times
		for (long j = 0; j < N; j++) {
			// Initialize it
			for (int i = 0; i < k; i++) {
				tokens[i] = i;
			}

			// Shuffle it
			Shuffle.shuffle(tokens);

			// Id permutation
			String id = Arrays.toString(tokens);

			// Increment count
			Integer c = count.get(id);
			if (c == null) c = new Integer(0);
			count.put(id, c + 1);
		}

		// Verify that each permutation are uniformly distributed
		// long expected = (new BigInteger(N)) / M.factorial(K).;
		long expected = (long) new BigInteger(Long.toString(N)).divide(M.factorial(k)).doubleValue();
		long variation = (long) (N * 0.001);
		String expectedMessage = "Expected range [" + (expected - variation) + ", " + (expected + variation) + "]";
		for (String id : count.keySet()) {
			Integer c = count.get(id);
			assertTrue(expectedMessage + " but found " + c, M.isInside(c, expected - variation, expected + variation));
		}

	}

	// Tests
	@Test
	public void test_shuffle_k1() {
		experiment(1);
	}

	@Test
	public void test_shuffle_k2() {
		experiment(2);
	}

	@Test
	public void test_shuffle_k3() {
		experiment(3);
	}

	@Test
	public void test_shuffle_k4() {
		experiment(4);
	}

	@Test
	public void test_shuffle_k5() {
		experiment(5);
	}

}
