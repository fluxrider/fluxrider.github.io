package flux.test;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import flux.image.I;

public class TestIDraw extends JPanel {

	// Attributes
	private BufferedImage image;

	// Construct
	public TestIDraw() throws IOException {
		image = ImageIO.read(new File("/home/fluxrider/_/media/stills_games/athena/Athena-3.png"));
	}

	// Paint
	public void paint(Graphics g) {
		int W = getWidth();
		int H = getHeight();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, W, H);
		I.drawImage((Graphics2D) g, 0, 0, W, H, image, Color.BLACK, true, true, null);
	}

	// Main
	public static void main(String[] args) throws IOException {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(10, 10, 100, 100);
		frame.setContentPane(new TestIDraw());
		frame.setVisible(true);
	}

}
