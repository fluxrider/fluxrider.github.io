package flux.test;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import flux.image.I;
import flux.math.M;
import flux.util.FPS;
import flux.util.Transition;

public class TestIBackgroundFPS extends JPanel implements Runnable {

	// Attributes
	private BufferedImage texture;
	private BufferedImage logo;
	private BufferedImage coloredLogo;
	private Thread thread;
	private FPS fps;
	private BufferedImage bgTile;

	Transition logoOpacity;
	Transition logoRotation;
	Transition logoScale;
	Transition fgHue, fgSaturation, fgBrightness;

	// Construct
	public TestIBackgroundFPS() throws IOException {
		texture = ImageIO.read(new File("/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/icons/texture00.png"));
		logo = ImageIO.read(new File("/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/icons/pentagram-hi.png"));
		// logo = ImageIO.read(new File("/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/icons/sword.png"));
		coloredLogo = new BufferedImage(logo.getWidth(), logo.getHeight(), BufferedImage.TYPE_INT_ARGB);
		bgTile = new BufferedImage(128, 128, BufferedImage.TYPE_INT_RGB);
		fps = new FPS();

		logoOpacity = new Transition(0, 1, 4000, 0, M.TimingFunction.LINEAR, Transition.LOOP_UNLIMITED, true);
		logoRotation = new Transition(0, 2 * Math.PI, 2500, 2000, M.TimingFunction.EASE, Transition.LOOP_UNLIMITED, false);
		logoScale = new Transition(0.25, .75, 1700, 0, M.TimingFunction.EASE_IN_OUT, Transition.LOOP_UNLIMITED, true);

		fgHue = new Transition(0, 1, 10000, 0, M.TimingFunction.LINEAR, Transition.LOOP_UNLIMITED, false);
		fgSaturation = new Transition(1);
		fgBrightness = new Transition(1);

		thread = new Thread(this);
		thread.start();

	}

	// Paint
	public void paint(Graphics g) {
		int W = getWidth();
		int H = getHeight();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, W, H);

		int w = bgTile.getWidth();
		int h = bgTile.getHeight();
		// Color fg = Color.BLUE;// HSBtoRGB
		Color fg = new Color(Color.HSBtoRGB((float) fgHue.get(), (float) fgSaturation.get(), (float) fgBrightness.get()));
		Color bg = Color.MAGENTA;
		double textureOpacity = .5;
		int centerLogo = 5;
		I.toColorMate(logo, coloredLogo, fg); // SLOW: bottle neck

		I.paintSingleBackgroundTile((Graphics2D) bgTile.getGraphics(), 0, 0, w, h, bg, texture, textureOpacity, coloredLogo, logoOpacity.get(), logoRotation.get(), centerLogo, logoScale.get());
		for (int r = 0; r < 2; r++) {
			for (int c = 0; c < 3; c++) {
				int x = 100 + c * w;
				int y = 100 + r * h;
				g.drawImage(bgTile, x, y, null);
			}
		}
		fps.frame();
	}

	// Run
	public void run() {
		logoOpacity.start();
		logoRotation.start();
		logoScale.start();
		fgHue.start();
		fgSaturation.start();
		fgBrightness.start();
		while (thread == Thread.currentThread()) {
			repaint();
			// U.sleep(10);

			if (Math.random() < .000001) System.out.println(fps.get() + " " + fps.period());
		}
	}

	// Main
	public static void main(String[] args) throws IOException {
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(10, 10, 800, 600);
		frame.setContentPane(new TestIBackgroundFPS());
		frame.setVisible(true);
	}

}
