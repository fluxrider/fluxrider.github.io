package flux.test;

import junit.framework.Assert;

import org.junit.Test;

import flux.time.T;
import flux.util.FPS;
import flux.util.U;

public class TestFPS {

	@Test
	public void test_period100() {
		FPS fps = new FPS();
		long t0 = System.currentTimeMillis();

		while (System.currentTimeMillis() < t0 + 8000) {
			fps.frame();
			U.sleep(100);
			if (System.currentTimeMillis() > t0 + 2000 && T.lastCheck(1000)) {
				// System.out.println("PERIOD " + fps.period() + " " + fps.periodHistoryAverage());
				// System.out.println("FPS    " + fps.get() + " " + fps.getHistoryAverage());
				Assert.assertEquals(100l, fps.period());
			}
		}
	}

	@Test
	public void test_period20() {
		FPS fps = new FPS();
		long t0 = System.currentTimeMillis();

		while (System.currentTimeMillis() < t0 + 8000) {
			fps.frame();
			U.sleep(20);
			if (System.currentTimeMillis() > t0 + 2000 && T.lastCheck(1000)) {
				// System.out.println("PERIOD " + fps.period() + " " + fps.periodHistoryAverage());
				// System.out.println("FPS    " + fps.get() + " " + fps.getHistoryAverage());
				Assert.assertEquals(20l, fps.period());
			}
		}
	}

}
