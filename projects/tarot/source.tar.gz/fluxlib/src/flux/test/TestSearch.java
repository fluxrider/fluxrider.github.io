package flux.test;

import junit.framework.Assert;

import org.junit.Test;

import flux.data.OverwriteCircularArray_long;
import flux.util.Search;

public class TestSearch {

	// Tests
	@Test
	public void test_binarySearch() {
		OverwriteCircularArray_long t = new OverwriteCircularArray_long(9);
		for (int i = 0; i < 15; i++) {
			t.add(i * i);
		}

		System.out.println(t);

		Assert.assertEquals(0, Search.binarySearch(t, 36));
		Assert.assertEquals(1, Search.binarySearch(t, 49));
		Assert.assertEquals(2, Search.binarySearch(t, 64));
		Assert.assertEquals(3, Search.binarySearch(t, 81));
		Assert.assertEquals(4, Search.binarySearch(t, 100));
		Assert.assertEquals(5, Search.binarySearch(t, 121));
		Assert.assertEquals(6, Search.binarySearch(t, 144));
		Assert.assertEquals(7, Search.binarySearch(t, 169));
		Assert.assertEquals(8, Search.binarySearch(t, 196));

		Assert.assertEquals(0, Search.binarySearch(t, 35));
		Assert.assertEquals(1, Search.binarySearch(t, 37));
		Assert.assertEquals(8, Search.binarySearch(t, 195));
		Assert.assertEquals(9, Search.binarySearch(t, 197));
	}

}
