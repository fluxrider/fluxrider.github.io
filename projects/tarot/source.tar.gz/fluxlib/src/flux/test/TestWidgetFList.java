package flux.test;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

import flux.input.EventBasedKeyboard;
import flux.widget.FList;

public class TestWidgetFList extends JPanel {

	// Attributes
	private BufferedImage up;
	private BufferedImage down;
	private BufferedImage left;
	private BufferedImage right;
	private Object[][] items;
	private Font font;
	private BufferedImage[] arrows;
	private FList list;

	// Construct
	public TestWidgetFList() throws IOException {
		up = ImageIO.read(new File("/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/icons/arrow_up.png"));
		down = ImageIO.read(new File("/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/icons/arrow_down.png"));
		left = ImageIO.read(new File("/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/icons/arrow_left.png"));
		right = ImageIO.read(new File("/home/fluxrider/_/dev/eclipse_workspace2/01Card/res/icons/arrow_right.png"));
		arrows = new BufferedImage[] { up, down, left, right };
		items = new Object[][] { { "a", "b", "c", "d", "e" }, { "1", "2", "3", "4" }, { "David", "Erin" } };
		list = new FList(this, true, items);
		font = new Font(Font.SANS_SERIF, Font.PLAIN, 18);
		EventBasedKeyboard.addListener(list);
	}

	// Paint
	public void paint(Graphics g) {
		int W = getWidth();
		int H = getHeight();
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, W, H);
		list.draw(g, font, W/4, H/2, W/2, H/2, arrows);
	}

	// Main
	public static void main(String[] args) throws IOException {
		EventBasedKeyboard.init();
		JFrame frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setBounds(10, 10, 800, 600);
		frame.setContentPane(new TestWidgetFList());
		frame.setVisible(true);
	}

}
