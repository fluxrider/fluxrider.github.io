package flux.test;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import flux.math.M;
import flux.random.R;

public class TestR {

	// Utils
	public static final long N = 10000000;

	private void verify(long t[]) {
		long expected = N / t.length;
		long variation = (long) (N * 0.001);
		String expectedMessage = "Expected range [" + (expected - variation) + ", " + (expected + variation) + "]";
		for (int i = 0; i < t.length; i++) {
			assertTrue(expectedMessage + " but found " + t[i], M.isInside(t[i], expected - variation, expected + variation));
		}
	}

	// Tests
	@Test
	public void test_uniform_inclusive_s32() {
		// create an array of buckets to store counters
		long t[] = new long[9];
		// roll N times
		for (long i = 0; i < N; i++) {
			int roll = R.uniform_inclusive_s32(-2, 6);
			t[roll + 2]++;
		}
		// verify that buckets were filled uniformly
		verify(t);
	}

	@Test
	public void test_uniform_exclusive_s32() {
		// create an array of buckets to store counters
		long t[] = new long[10];
		// roll N times
		for (long i = 0; i < N; i++) {
			int roll = R.uniform_exclusive_s32(-5, 5);
			t[roll + 5]++;
		}
		// verify that buckets were filled uniformly
		verify(t);
	}

	@Test
	public void test_d20() {
		// create an array of buckets to store counters
		long t[] = new long[20];
		// roll N times
		for (long i = 0; i < N; i++) {
			int roll = R.d20();
			t[roll - 1]++;
		}
		// verify that buckets were filled uniformly
		verify(t);
	}

}
