package flux.test;

public class TestBezierSpeed {

	public static void main(String[] args) {
		TestBezier test = new TestBezier();

		int N = 10000;

		{
			long t0 = System.currentTimeMillis();
			for (int i = 0; i < N; i++) {
				test.test_solve();
			}
			long t1 = System.currentTimeMillis();
			System.out.println("Solve: " + (t1 - t0) / (double) N);
		}

		{
			long t0 = System.currentTimeMillis();
			for (int i = 0; i < N; i++) {
				test.test_search();
			}
			long t1 = System.currentTimeMillis();
			System.out.println("Search: " + (t1 - t0) / (double) N);
		}

		{
			long t0 = System.currentTimeMillis();
			for (int i = 0; i < N; i++) {
				test.test_linear();
			}
			long t1 = System.currentTimeMillis();
			System.out.println("Linear: " + (t1 - t0) / (double) N);
		}

		{
			long t0 = System.currentTimeMillis();
			for (int i = 0; i < N; i++) {
				test.test_linearCached();
			}
			long t1 = System.currentTimeMillis();
			System.out.println("Linear Cached: " + (t1 - t0) / (double) N);
		}

	}

}
