/*
 * TODO Copyright (c)
 */

package flux.debug;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JOptionPane;

/**
 * This class splits error messages to stderr, gui popup, and an error file.
 * 
 * @author David Lareau
 */

public class ErrorHandler {

	// Attributes
	private boolean stderr;
	private boolean gui;
	private PrintWriter err;
	private String errFile;

	// Constructor
	public ErrorHandler(boolean stderr, boolean gui, String errFile) {
		this.stderr = stderr;
		this.gui = gui;
		this.err = null;
		this.errFile = errFile;
	}

	// Methods
	public void onThrowable(Throwable t) {
		if (stderr) t.printStackTrace();

		createErrStream();
		t.printStackTrace(err);

		if (gui) JOptionPane.showMessageDialog(null, t.toString(), "Throwable", JOptionPane.ERROR_MESSAGE);
	}

	public void onMessage(String s) {
		if (stderr) System.err.println(s);

		createErrStream();
		err.println(s);

		if (gui) JOptionPane.showMessageDialog(null, s, "Message", JOptionPane.ERROR_MESSAGE);
	}

	public void close() {
		if (err != null) {
			err.close();
			err = null;
		}
	}

	// Private Methods
	private void createErrStream() {
		try {
			if (err == null) err = new PrintWriter(new File(errFile));
		} catch (IOException e) {
			e.printStackTrace(); // Not much we can do here, report the problem no matter the parameters
		}
	}

}