/*
 * TODO Copyright (c)
 */

package flux.image;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

import flux.util.Graphics2DStack;

/**
 * This class consists of utility functions regarding images.
 * 
 * @author David Lareau
 */

public class I {

	/**
	 * Scale an image to a region.
	 * 
	 * @param background
	 *           if null, no background is painted
	 * @param interpolation
	 *           if null, shouldMagnifyWithNearestNeighbor will be used if magnifying, and will default to bicubic interpolation. An example value is
	 *           RenderingHints.VALUE_INTERPOLATION_BICUBIC.
	 */
	public static final void drawImage(Graphics2D g, int x, int y, int w, int h, BufferedImage image, Color background, boolean preserveAspectRatio, boolean cropMargin, Object interpolation) {
		// find crop area (if there is a margin, this will be smaller than the actual image)
		Rectangle source = cropMargin ? findMargin(image) : new Rectangle(0, 0, image.getWidth(), image.getHeight());

		if (preserveAspectRatio) {
			// clear
			if (background != null) {
				g.setColor(background);
				g.fillRect(x, y, w, h);
			}

			// find zoom and pan (fit to space)
			double zoom = Math.min(w / source.getWidth(), h / source.getHeight());
			double panX = (w - (source.getWidth() * zoom)) / 2;
			double panY = (h - (source.getHeight() * zoom)) / 2;

			// decide the scaling interpolation method.
			if (interpolation == null) {
				interpolation = zoom >= 1 && shouldMagnifyWithNearestNeighbor(image) ? RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR : RenderingHints.VALUE_INTERPOLATION_BICUBIC;
			}
			g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, interpolation);

			// draw on buffer
			// drawImage(Image img, int dx1, int dy1, int dx2, int dy2, int sx1, int sy1, int sx2, int sy2, ImageObserver observer)
			// note: the x2, y2 are exclusive in practice (not obvious in documentation)
			g.drawImage(image, x + (int) Math.round(panX), y + (int) Math.round(panY), x + (int) Math.round(panX + source.getWidth() * zoom), y + (int) Math.round(panY + source.getHeight() * zoom), source.x, source.y, source.x + source.width, source.y + source.height, null);
		}
		// if (!preserveAspectRatio) just stretch to fit
		else {
			if (interpolation == null) {
				boolean magnifying = w > source.width && h > source.height; // the && is arbitrary
				interpolation = magnifying && shouldMagnifyWithNearestNeighbor(image) ? RenderingHints.VALUE_INTERPOLATION_NEAREST_NEIGHBOR : RenderingHints.VALUE_INTERPOLATION_BICUBIC;
			}
			g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, interpolation);

			// note: the x2, y2 are exclusive in practice (not obvious in documentation)
			g.drawImage(image, x, y, x + w, y + h, source.x, source.y, source.x + source.width, source.y + source.height, null);
		}
	}

	/**
	 * Draw the foreground image on top of a background image with a degree of opacity.
	 */
	public static final void drawFadeTransition(Graphics2D g, BufferedImage background, BufferedImage foreground, double opacity) {
		g.drawImage(background, 0, 0, null);
		g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) opacity));
		g.drawImage(foreground, 0, 0, null);
	}

	/**
	 * Determine using heuristics if an image should be magnified with nearest neighbor interpolation.
	 */
	public static final boolean shouldMagnifyWithNearestNeighbor(BufferedImage image) {
		// Indexed/Palette image should only be magnified with nearest neighbor.
		int type = image.getType();
		if (type == BufferedImage.TYPE_BYTE_INDEXED || type == BufferedImage.TYPE_BYTE_BINARY) return true;

		// small image should not use interpolation (e.g. they are a screenshot from an old game), they would look over
		// stretched and blurry with anything else.
		if (image.getWidth() < 400 && image.getHeight() < 400) return true;

		return false;
	}

	/**
	 * Find the crop region that exclude an homogeneous color margin.
	 */
	private static final Rectangle findMargin(BufferedImage image) {
		int marginLeftX, marginRightX, marginTopY, marginBottomY;

		int W = image.getWidth();
		int H = image.getHeight();
		int topLeft = image.getRGB(0, 0);
		int bottomRight = image.getRGB(W - 1, H - 1);
		boolean allTheSame;
		// find top margin
		for (allTheSame = true, marginTopY = 0; marginTopY < H; marginTopY++) {
			for (int x = 0; x < W && allTheSame; x++) {
				allTheSame &= image.getRGB(x, marginTopY) == topLeft;
			}
			if (!allTheSame) break;
		}
		// find the bottom margin
		for (allTheSame = true, marginBottomY = H - 1; marginBottomY >= 0; marginBottomY--) {
			for (int x = 0; x < W && allTheSame; x++) {
				allTheSame &= image.getRGB(x, marginBottomY) == bottomRight;
			}
			if (!allTheSame) break;
		}
		// find the left margin
		for (allTheSame = true, marginLeftX = 0; marginLeftX < W; marginLeftX++) {
			for (int y = 0; y < H && allTheSame; y++) {
				allTheSame &= image.getRGB(marginLeftX, y) == topLeft;
			}
			if (!allTheSame) break;
		}
		// find the right margin
		for (allTheSame = true, marginRightX = W - 1; marginRightX >= 0; marginRightX--) {
			for (int y = 0; y < H && allTheSame; y++) {
				allTheSame &= image.getRGB(marginRightX, y) == bottomRight;
			}
			if (!allTheSame) break;
		}
		// Readjusts margins by one if some of the background can be found within the cropped region
		// (the guess is that the color of the margin is used as a border all around whatever is inside, so I should leave
		// some of the margin visible)
		if (marginTopY > 0) {
			boolean some = false;
			for (int x = marginLeftX; x <= marginRightX && !some; x++) {
				some |= image.getRGB(x, marginTopY) == topLeft;
			}
			if (some) marginTopY--;
		}
		if (marginBottomY < H - 1) {
			boolean some = false;
			for (int x = marginLeftX; x <= marginRightX && !some; x++) {
				some |= image.getRGB(x, marginBottomY) == bottomRight;
			}
			if (some) marginBottomY++;
		}
		if (marginLeftX > 0) {
			boolean some = false;
			for (int y = marginTopY; y <= marginBottomY && !some; y++) {
				some |= image.getRGB(marginLeftX, y) == topLeft;
			}
			if (some) marginLeftX--;
		}
		if (marginRightX < W - 1) {
			boolean some = false;
			for (int y = marginTopY; y <= marginBottomY && !some; y++) {
				some |= image.getRGB(marginRightX, y) == topLeft;
			}
			if (some) marginRightX++;
		}

		return new Rectangle(marginLeftX, marginTopY, marginRightX - marginLeftX + 1, marginBottomY - marginTopY + 1);
	}

	/**
	 * Reads an image and outputs all its non transparent black pixel to a specific color, and the rest to fully transparent pixels (and white).
	 * <p>
	 * This would be used to convert a black logo to the same logo in another color.
	 */
	public static void toColorMate(BufferedImage in, BufferedImage out, Color color) {
		int outputColor = color.getRGB();
		int transparent = 0x00FFFFFF;
		int W = in.getWidth();
		int H = in.getHeight();
		for (int y = 0; y < H; y++) {
			for (int x = 0; x < W; x++) {
				int rgb = in.getRGB(x, y);
				if (rgb == 0xFF000000) out.setRGB(x, y, outputColor);
				else out.setRGB(x, y, transparent);
			}
		}
	}

	/**
	 * Create a procedural tileable background similar to what http://bgpatterns.com/ does.
	 * <p>
	 * This method uses a BufferedImage instead of a Shape and foreground color to draw the logo. This is to avoid the complexity of supporting
	 * svg2shape or slowness of image2shape conversion.
	 * <p>
	 * In other words, instead of Shape logo, Color fg, I use BufferedImage logo, which is preprocessed with toColorMate
	 * 
	 * @param logoPositions
	 *           4 will center the logos at each corner of the bounding box, 5 will do like 4 plus one logo at the center of the box
	 */
	public static void paintSingleBackgroundTile(Graphics2D g, int x, int y, int w, int h, Color bg, BufferedImage texture, double textureOpacity, BufferedImage logo, double logoOpacity, double logoRotation, int logoPositions, double logoScale) {
		Graphics2DStack stack = new Graphics2DStack();
		g = stack.push(g);
		g.clipRect(x, y, w, h);
		// fill with bg color
		{
			g.setColor(bg);
			g.fillRect(x, y, w, h);
		}
		// draw texture image with texture opacity (as is, no color modification, texture must have transparency)
		{
			g = stack.push(g);
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) textureOpacity));
			drawImage(g, x, y, w, h, texture, null, false, false, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
			g = stack.pop();
		}
		// draw each logo rotated, scaled, and opacity
		{
			g = stack.push(g);
			g.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float) logoOpacity));
			// translate origin to center of where image will be drawn, and rotate around that center
			// array order: top left, top right, bottom left, bottom right, center
			double[] cx = new double[] { x, x + w, x, x + w, x + w / 2.0 };
			double[] cy = new double[] { y, y, y + h, y + h, y + h / 2.0 };
			for (int i = 0; i < logoPositions; i++) {
				g = stack.push(g);
				g.translate(cx[i], cy[i]);
				g.rotate(logoRotation);
				int sw = (int) Math.round(w * logoScale);
				int sh = (int) Math.round(h * logoScale);
				int sx = (int) Math.round(-sw / 2);
				int sy = (int) Math.round(-sh / 2);
				drawImage(g, sx, sy, sw, sh, logo, null, true, false, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
				g = stack.pop();
			}
			g = stack.pop();
		}
		g = stack.pop();
	}

}
