/*
 * TODO Copyright (c)
 */
package flux.widget;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;

import javax.swing.JComponent;

import flux.math.M;

/**
 * A scrollable list constrained to a specific region. The scrolling is up/down and left/right. An item may be selected.
 * 
 * The items are object displayed with their toString() The list is vertical. Left/right scrolling is pagefull. Up/down scrolling is pagefull when
 * selection is disabled, or when selection reached an edge and tries to move across. Selection is circular (the scrolling arrows are static)
 * 
 * We figure out how many items per page can be displayed at paint because font metrics can only be accessed with a Graphics object. For this reason,
 * the display region is dynamic (specified at paint)
 * 
 * @author David Lareau
 */

public class FList implements KeyListener {

	// Attributes
	private JComponent parent;
	private boolean selectable;
	private int selectedColumn;
	private int selectedRow;
	private int pageChangeRequest; // only applicable when selectable is set to false
	private Object[][] items; // [col][row]

	// Construct
	public FList(JComponent parent, boolean selectable, Object[]... items) {
		this.parent = parent;
		this.selectable = selectable;
		this.selectedRow = this.selectedColumn = 0;
		this.items = items;
	}

	public FList(JComponent parent, boolean selectable) {
		this(parent, selectable, (Object[][]) null);
	}

	public void setItems(boolean resetPosition, Object[]... items) {
		this.items = items;
		if (resetPosition) {
			selectedColumn = 0;
			selectedRow = 0;
			pageChangeRequest = 0;
		}
	}

	// Controls
	public void up() {
		if (items == null) return;
		if (selectable) selectedRow = M.previousIndex(selectedRow, items[selectedColumn].length);
		else pageChangeRequest--;
		if (parent != null) parent.repaint();
	}

	public void down() {
		if (items == null) return;
		if (selectable) selectedRow = M.nextIndex(selectedRow, items[selectedColumn].length);
		else pageChangeRequest++;
		if (parent != null) parent.repaint();
	}

	public void left() {
		if (items == null) return;
		selectedColumn = M.previousIndex(selectedColumn, items.length);
		selectedRow = 0;
		pageChangeRequest = 0;
		if (parent != null) parent.repaint();
	}

	public void right() {
		if (items == null) return;
		selectedColumn = M.nextIndex(selectedColumn, items.length);
		selectedRow = 0;
		pageChangeRequest = 0;
		if (parent != null) parent.repaint();
	}

	public Object getSelected() {
		if (items == null) throw new RuntimeException("null items");
		if (selectable) return items[selectedColumn][selectedRow];
		throw new RuntimeException("Not selectable");
	}

	public int getSelectedRow() {
		if (items == null) throw new RuntimeException("null items");
		if (selectable) return selectedRow;
		throw new RuntimeException("Not selectable");
	}

	public int getSelectedCol() {
		if (items == null) throw new RuntimeException("null items");
		if (selectable) return selectedColumn;
		throw new RuntimeException("Not selectable");
	}

	public void setSelected(int row, int col) {
		if (!selectable) throw new RuntimeException("Not selectable");
		selectedColumn = col;
		selectedRow = row;
		pageChangeRequest = 0;
	}

	// Paint
	public void draw(Graphics g, Font font, int X, int Y, int W, int H, BufferedImage[] arrows) {
		if (items == null) return;
		// set font
		g.setFont(font);
		FontMetrics metrics = g.getFontMetrics();
		int dy = metrics.getHeight();

		// get arrows
		BufferedImage up = arrows[0];
		BufferedImage down = arrows[1];
		BufferedImage left = arrows[2];
		BufferedImage right = arrows[3];

		// margins
		int side = 1; // between anything and region
		int inner = 1; // between arrows and text

		// figure out how many items per page can be displayed, and which arrows will be shown, and which items will be displayed
		int rows = items.length;
		boolean showLeftRightNavigation = rows > 1;
		int cols = items[selectedColumn].length;
		boolean showUpDownNavigation = dy * cols > H - 2 * side;
		int itemsPerPage;
		if (showUpDownNavigation) {
			int space = H - up.getHeight() - down.getHeight() - 2 * side + 2 * inner;
			itemsPerPage = space / dy;
		} else {
			itemsPerPage = cols;
		}
		if (itemsPerPage > 0) {
			int page = selectedRow / itemsPerPage;
			// handle pageChangeRequest
			if (showUpDownNavigation && !selectable) {
				int nPages = (int) Math.ceil(cols / (double) itemsPerPage);
				// selectedColumn
				// selectedColumn += itemsPerPage * pageChangeRequest;
				page = M.boundCyclicCapacity(page + pageChangeRequest, nPages);
			}
			// ensure that selectedRow is at beginning of page if !selectable
			if (!selectable) {
				selectedRow = page * itemsPerPage;
			}
			int from = page * itemsPerPage;
			int to = Math.min(from + itemsPerPage - 1, cols - 1);

			// draw arrows
			int ix, iy, iw, ih; // inner region after arrows after margin
			if (showLeftRightNavigation) {
				{
					int y = Y + (H - left.getHeight()) / 2;
					int x = X + side;
					g.drawImage(left, x, y, null);
					ix = x + left.getWidth() + inner;
				}
				{
					int y = Y + (H - right.getHeight()) / 2;
					int x = X + W - right.getWidth() - side;
					g.drawImage(right, x, y, null);
					iw = (x - inner) - ix + 1;
				}
			} else {
				ix = X + side;
				iw = W - 2 * side;
			}
			if (showUpDownNavigation) {
				{
					int y = Y + side;
					int x = X + (W - up.getWidth()) / 2;
					g.drawImage(up, x, y, null);
					iy = y + up.getHeight() + inner;
				}
				{
					int y = Y + H - down.getHeight() - side;
					int x = X + (W - down.getWidth()) / 2;
					g.drawImage(down, x, y, null);
					ih = (y - inner) - iy + 1;
				}
			} else {
				iy = Y + side;
				ih = (H - 2 * side);
			}

			// draw items (h-centered and v-centered)
			g.setColor(Color.BLACK);
			// g.drawRect(ix, iy, iw-1, ih-1);
			int th = (to - from + 1) * dy;
			int y = (int) Math.round((iy + dy) + (ih - th) / 2.0 - dy / 4.0); // v-centered
			for (int row = from; row <= to; row++) {
				String text = items[selectedColumn][row].toString();
				if (selectable && selectedRow == row) g.setColor(Color.RED);
				int tw = metrics.stringWidth(text);
				int x = ix + (iw - tw) / 2; // h-centered
				g.drawString(text, x, y);
				y += dy;
				if (selectable && selectedRow == row) g.setColor(Color.BLACK);
			}
		}

		pageChangeRequest = 0;
	}

	// KeyListener
	public void keyPressed(KeyEvent e) {
		switch (e.getKeyCode()) {
			case KeyEvent.VK_RIGHT:
				right();
				break;
			case KeyEvent.VK_LEFT:
				left();
				break;
			case KeyEvent.VK_UP:
				up();
				break;
			case KeyEvent.VK_DOWN:
				down();
				break;
		}
	}

	public void keyReleased(KeyEvent e) {
	}

	public void keyTyped(KeyEvent e) {
	}

}
