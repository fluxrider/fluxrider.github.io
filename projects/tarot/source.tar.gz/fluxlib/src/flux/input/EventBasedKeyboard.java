/*
 * TODO Copyright (c)
 */
package flux.input;

import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.LinkedList;
import java.util.List;

/**
 * This class catch all keyboard input for an application, and warns listeners about them.
 * 
 * @author David Lareau
 */

public class EventBasedKeyboard {

	private static List<KeyListener> listeners;

	public static final void addListener(KeyListener listener) {
		// TODO concurency error potentioal when called during one of the event
		listeners.add(listener);
	}

	public static final void removeListener(KeyListener listener) {
		listeners.remove(listener);
	}

	private static final void warnPressed(KeyEvent e) {
		for (KeyListener listener : listeners) {
			listener.keyPressed(e);
		}
	}

	private static final void warnReleased(KeyEvent e) {
		for (KeyListener listener : listeners) {
			listener.keyReleased(e);
		}
	}

	private static final void warnTyped(KeyEvent e) {
		for (KeyListener listener : listeners) {
			listener.keyTyped(e);
		}
	}

	public static final void init() {
		listeners = new LinkedList<KeyListener>();
		KeyboardFocusManager.getCurrentKeyboardFocusManager().addKeyEventDispatcher(new KeyEventDispatcher() {
			public boolean dispatchKeyEvent(KeyEvent e) {
				// System.out.println(e);
				switch (e.getID()) {
					case KeyEvent.KEY_PRESSED:
						warnPressed(e);
						break;
					case KeyEvent.KEY_RELEASED:
						warnReleased(e);
						break;
					case KeyEvent.KEY_TYPED:
						warnTyped(e);
						break;
				}
				return false;
			}
		});
	}

}
