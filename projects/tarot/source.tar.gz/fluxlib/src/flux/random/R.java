/*
 * TODO Copyright (c)
 */

package flux.random;

/**
 * This class consists of utility functions to generate random numbers.
 * 
 * @author David Lareau
 */

public class R {

	/**
	 * @return [0, 1[ double precision, uniform distribution
	 */
	public static final double uniform_exclusive_normalized() {
		return Math.random();
	}

	/**
	 * @param min
	 *           the minimum value to be returned
	 * @param max
	 *           the maxium value to be returned, must be >= to min
	 * @return [min, max] int precision, uniform distribution
	 */
	public static final int uniform_inclusive_s32(int min, int max) {
		if (min > max) throw new IllegalArgumentException("min > max, " + min + " > " + max);
		return min + (int) (uniform_exclusive_normalized() * (max - min + 1));
	}

	/**
	 * @param min
	 *           the minimum value to be returned
	 * @param max
	 *           the minimum value not to be returned, must be >= to min
	 * @return [min, max[ int precision, uniform distribution
	 */
	public static final int uniform_exclusive_s32(int min, int max) {
		return uniform_inclusive_s32(min, max - 1);
	}

	/**
	 * @param face
	 *           number of face on the die
	 * @return the result of a die roll
	 */
	public static final int d(int face) {
		return uniform_inclusive_s32(1, face);
	}

	/**
	 * @return the result of a 4-faced die roll
	 */
	public static final int d4() {
		return d(4);
	}

	/**
	 * @return the result of a 6-faced die roll
	 */
	public static final int d6() {
		return d(6);
	}

	/**
	 * @return the result of a 8-faced die roll
	 */
	public static final int d8() {
		return d(8);
	}

	/**
	 * @return the result of a 10-faced die roll
	 */
	public static final int d10() {
		return d(10);
	}

	/**
	 * @return the result of a 12-faced die roll
	 */
	public static final int d12() {
		return d(12);
	}

	/**
	 * @return the result of a 20-faced die roll
	 */
	public static final int d20() {
		return d(20);
	}

	/**
	 * @return the result of a 100-faced die roll
	 */
	public static final int d100() {
		return d(100);
	}

}
