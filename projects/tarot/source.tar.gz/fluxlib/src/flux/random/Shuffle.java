/*
 * TODO Copyright (c)
 */

package flux.random;

import flux.util.U;

/**
 * This class consists of utility functions to shuffle random access collections.
 * 
 * @author David Lareau
 */

public class Shuffle {

	/**
	 * Non bias shuffle (Fisher–Yates, Knuth)
	 */
	public static final void shuffle(Object t[], int offset, int length) {
		int n = length;
		for (int i = 0; i < n - 1; i++) {
			U.swap(t, offset + i, offset + R.uniform_exclusive_s32(i, n));
		}
	}

	/**
	 * Calls shuffle(t, 0, t.length);
	 */
	public static final void shuffle(Object t[]) {
		shuffle(t, 0, t.length);
	}

	/**
	 * Group Cross Shuffle (I made up this one, its not a standard shuffle)
	 * <p>
	 * The goal of this function is to shuffle such that the values at the beginning cannot jump to the end in one call and vice versa.
	 * <p>
	 * Motivation: shuffling images in a random slideshow, and I don't want the last image shown to be reshown soon, and I don't want the first image
	 * shown to now be the last such that I have to see 2n images before I can see it again.
	 * <p>
	 * I do this by independently shuffling section of the array, and then shuffling small crossover between parts. when doing the cross over shuffle,
	 * I do every even pair, then odd pairs to avoid carrying a values across many groups in the case of cross > .5. thus the name, groupCrossShuffle
	 * (shuffle groups, and allow some crossing). The cross parameter represent a percentage overlap of two group (1 means both group will completely
	 * mix, 0 means there will be no mixing, .5 means the last half of a group will mix with the first half of the next group)
	 */
	//
	public static final void groupCrossShuffle(String t[], int offset, int length, int nGroups, double cross) {
		if (cross < 0 || cross > 1) throw new IllegalArgumentException("cross should be a [0, 1] percentage, not " + cross);
		// Shuffle independently each group
		int currentOffset = 0;
		int nextOffset = 0;
		for (int group = 0; group < nGroups; group++) {
			currentOffset = nextOffset;
			nextOffset = ((length * (group + 1)) / nGroups);
			shuffle(t, currentOffset, nextOffset - currentOffset);
		}
		// Shuffle Cross-over section between groups
		// Even pairs
		nextOffset = 0;
		int nextNextOffset = (length / nGroups);
		for (int group = 0; group < nGroups - 1; group++) {
			currentOffset = nextOffset;
			nextOffset = nextNextOffset;
			nextNextOffset = ((length * (group + 2)) / nGroups);
			if (group % 2 == 0) {
				int n = nextNextOffset - currentOffset;
				int nCross = cross > 0 ? Math.max(2, (int) Math.round(n * cross)) : 0;
				if (nCross > 1) shuffle(t, currentOffset + (n - nCross) / 2, nCross);
			}
		}
		// Odd pairs
		nextOffset = 0;
		nextNextOffset = (length / nGroups);
		for (int group = 0; group < nGroups - 1; group++) {
			currentOffset = nextOffset;
			nextOffset = nextNextOffset;
			nextNextOffset = ((length * (group + 2)) / nGroups);
			if (group % 2 == 1) {
				int n = nextNextOffset - currentOffset;
				int nCross = cross > 0 ? Math.max(2, (int) Math.round(n * cross)) : 0;
				if (nCross > 1) shuffle(t, currentOffset + (n - nCross) / 2, nCross);
			}
		}
	}

	/**
	 * Calls groupCrossShuffle(t, 0, t.length, 4, .25);
	 */
	public static final void groupCrossShuffle(String t[]) {
		groupCrossShuffle(t, 0, t.length, 4, .25);
	}

}
