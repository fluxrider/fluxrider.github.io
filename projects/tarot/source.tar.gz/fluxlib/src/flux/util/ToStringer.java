package flux.util;

public interface ToStringer<T> {

	public String toString(T t);

}
