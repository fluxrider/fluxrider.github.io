/*
 * TODO Copyright (c)
 */
package flux.util;

import java.awt.Graphics2D;
import java.util.Deque;
import java.util.LinkedList;

/**
 * This class manages a stack of Graphics state.
 * 
 * @author David Lareau
 */

public class Graphics2DStack {

	// Attributes
	Deque<Graphics2D> stack;

	// Construct
	public Graphics2DStack() {
		stack = new LinkedList<Graphics2D>();
	}

	// Methods
	public Graphics2D push(Graphics2D g) {
		stack.push(g);
		return (Graphics2D) g.create();
	}

	public Graphics2D pop() {
		return stack.pop();
	}

}
