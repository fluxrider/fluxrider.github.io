/*
 * TODO Copyright (c)
 */
package flux.util;

import flux.data.OverwriteCircularArray_int;
import flux.math.M;
import flux.time.Timer;

/**
 * Computes frame per seconds.
 * 
 * @author David Lareau
 */

public class FPS {

	// Attributes
	private OverwriteCircularArray_int history;
	private long currentSecond;
	private int currentSecondCount;
	private Timer timer;

	// Construct
	public FPS(int historyCapacity, boolean verboseEverySeconds) {
		history = new OverwriteCircularArray_int(historyCapacity);
		currentSecond = System.currentTimeMillis() / 1000;
		currentSecondCount = 0;
		if (verboseEverySeconds) timer = new Timer();
	}

	public FPS() {
		this(10, true);
	}

	// Methods
	public void frame() {
		advanceToTime(System.currentTimeMillis());
		currentSecondCount++;
		if (timer != null && timer.lastCheck(1000)) System.out.println("FPS: " + M.round(this.get(), 2) + " (period=" + this.period() + ")");
	}

	/**
	 * @return the latest fully recorded second fps
	 */
	public double get() {
		advanceToTime(System.currentTimeMillis());
		if (history.empty()) return 0;
		// return frame count in the most recent second in the history
		return history.get(history.size() - 1);
	}

	/**
	 * @return the average of all fully recorded seconds in the history
	 */
	public double getHistoryAverage() {
		advanceToTime(System.currentTimeMillis());
		if (history.empty()) return 0;
		// return average frame count per seconds
		long sum = 0;
		for (int i = 0; i < history.size(); i++) {
			sum += history.get(i);
		}
		return sum / (double) history.size();
	}

	public long period() {
		double f = get();
		if (f == 0) return 0;
		return Math.round(1000 / f);
	}

	public long periodHistoryAverage() {
		double f = getHistoryAverage();
		if (f == 0) return 0;
		return Math.round(1000 / f);
	}

	// Private Methods
	private void advanceToTime(long millisecond) {
		long s = millisecond / 1000;
		while (currentSecond < s) {
			history.add(currentSecondCount);
			currentSecond++;
			currentSecondCount = 0;
		}
	}

}
