/*
 * TODO Copyright (c)
 */

package flux.util;

import flux.math.M;

/**
 * This class manages the transition of a value in time.
 * 
 * @author David Lareau
 */

public class Transition {

	// Constans
	public static final int LOOP_UNLIMITED = -1;

	// Attributes
	private double from;
	private double to;
	private long durationMilliseconds;
	private long delayMilliseconds;
	private M.TimingFunction timingFunction;
	private int loop; // when looping is UNLIMITED, you never reach 'to' exactly (its an exclusive bound) unless you are looping back and forth
	private boolean backAndForth; // loop forward/reverse instead of forward/reset

	private long t0;
	private boolean paused;
	private long pauseT;
	private boolean started;

	private boolean constant;

	private boolean initialized;

	// Construct
	public Transition() {
		this.initialized = false;
	}

	public Transition(double constant) {
		start(constant);
	}

	public Transition(double from, double to, long durationMilliseconds, long delayMilliseconds, M.TimingFunction timingFunction, int loop, boolean backAndForth) {
		start(from, to, durationMilliseconds, delayMilliseconds, timingFunction, loop, backAndForth);
	}

	// Methods
	public void start(double constant) {
		this.from = constant;
		this.constant = true;
		this.initialized = true;
		start();
	}

	public void start(double from, double to, long durationMilliseconds, long delayMilliseconds, M.TimingFunction timingFunction, int loop, boolean backAndForth) {
		this.from = from;
		this.to = to;
		this.durationMilliseconds = durationMilliseconds;
		this.delayMilliseconds = delayMilliseconds;
		this.timingFunction = timingFunction;
		this.loop = loop;
		this.backAndForth = backAndForth;
		this.constant = false;
		this.initialized = true;
		start();
	}

	public void start() {
		if (!initialized) throw new RuntimeException("Noy initialized");
		if (constant) return;
		t0 = System.currentTimeMillis() + delayMilliseconds;
		paused = false;
		started = true;
	}

	public void pause() {
		if (constant) return;
		pauseT = System.currentTimeMillis();
		paused = true;
	}

	public void resume() {
		if (constant) return;
		if (!paused) throw new RuntimeException();
		t0 += pauseT - t0;
		paused = false;
	}

	public double get() {
		double time = getRatio();
		if (time == 0) return from;
		// not looping
		if (loop == 0) {
			time = M.boundCrop(time, 0, 1);
		} else {
			// still looping
			if (loop == LOOP_UNLIMITED || time < loop + 1) {
				if (backAndForth) time = M.boundCyclicBackAndForth(time, 0, 1);
				else time = M.boundCyclic(time, 0, 1);
			}
			// done
			else {
				if (!backAndForth) time = 1;
				else time = (loop % 2 == 0 ? 1 : 0); // looping back and forth can stop you at the beginning or the end (back and forth counts as two)
			}
		}

		// compute progress
		return M.linearBezier(M.timingFunction(time, timingFunction), from, to);
	}

	public double getRatio() {
		if (constant) return 0;
		if (!started) return 0;
		// find progress relative to duration
		long currentTime = paused ? pauseT : System.currentTimeMillis();
		double time = (currentTime - t0) / (double) durationMilliseconds;
		// acknowledge delay
		if (time < 0) return 0;
		return time;
	}

	public double getTotalRatio() {
		if (loop == LOOP_UNLIMITED) return Double.POSITIVE_INFINITY;
		return getRatio() / (loop + 1);
	}

}
