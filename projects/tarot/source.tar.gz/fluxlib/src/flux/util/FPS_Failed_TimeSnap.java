/*
 * TODO Copyright (c)
 */
package flux.util;

import flux.data.OverwriteCircularArray_long;

/**
 * Computes frame per seconds.
 * 
 * @author David Lareau
 */

public class FPS_Failed_TimeSnap {

	// Attributes
	private OverwriteCircularArray_long frames;

	// Construct
	public FPS_Failed_TimeSnap(int frameCapacity) {
		frames = new OverwriteCircularArray_long(frameCapacity);
	}

	public FPS_Failed_TimeSnap() {
		this(1000);
	}

	// Methods
	public void frame() {
		frames.add(System.currentTimeMillis());
	}

	/**
	 * @return the fps between the specified interval of time
	 */
	public double get(long t0, long t1) {
		// find the two closest time frames inside this time interval and use those for computing the fps
		int a = Search.binarySearch(frames, t0) + 1;
		int b = Search.binarySearch(frames, t1) - 1;
		int n = frames.size();
		if (a >= n || b < 0) return 0;
		long ta = frames.get(a);
		long tb = frames.get(b);
		if (ta > t1 || tb < t0) return 0;
		long duration = tb - ta;
		long frameCount = b - a + 1;
		final long MIN_DURATION = 20;
		if (duration < MIN_DURATION) return 0;
		// System.out.println("duration: " + duration + " [" + ta + " - " + tb + "]");
		// System.out.println("frameCount: " + frameCount);
		return frameCount * 1000 / (double) duration;
	}

	/**
	 * @return the fps of the last t milliseconds
	 */
	public double get(long t) {
		long t1 = System.currentTimeMillis();
		return get(t1 - t, t1);
	}

	/**
	 * @return the fps of the last second
	 */
	public double get() {
		return get(1000);
	}

	public long period(long t0, long t1) {
		double f = get(t0, t1);
		if (f == 0) return 0;
		return Math.round(1000 / f);
	}

	public long period(long t) {
		double f = get(t);
		if (f == 0) return 0;
		return Math.round(1000 / f);
	}

	public long period() {
		double f = get();
		if (f == 0) return 0;
		return Math.round(1000 / f);
	}

}
