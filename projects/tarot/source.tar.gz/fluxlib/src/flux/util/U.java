/*
 * TODO Copyright (c)
 */

package flux.util;

import java.awt.Component;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

/**
 * This class consists of miscellaneous utility functions.
 * 
 * @author David Lareau
 */

public class U {

	/**
	 * Swaps the value of two entries in an array.
	 */
	public static final void swap(Object t[], int i, int j) {
		Object temp = t[i];
		t[i] = t[j];
		t[j] = temp;
	}

	/**
	 * Ignore exception sleep
	 */
	public static final boolean sleep(long milliseconds) {
		try {
			Thread.sleep(milliseconds);
		} catch (InterruptedException e) {
			return false;
		}
		return true;
	}

	public static final boolean yieldForRepaint() {
		return sleep(1);
	}

	/**
	 * Runtime exception image load
	 */
	public static final BufferedImage load(String filename) {
		try {
			return ImageIO.read(new File(filename));
		} catch (IOException e) {
			throw new RuntimeException(filename, e);
		}
	}

	public interface LoadAsyncCallback {
		public void loadAsyncCallback(String filename, BufferedImage loaded, Throwable error);
	}

	public static final void loadAsync(final String filename, final LoadAsyncCallback callback) {
		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					BufferedImage image = ImageIO.read(new File(filename));
					callback.loadAsyncCallback(filename, image, null);
				} catch (IOException e) {
					callback.loadAsyncCallback(filename, null, e);
				}
			}
		});
		t.start();
	}

	public static final void screenshot(Component component) {
		BufferedImage screenshot = new BufferedImage(component.getWidth(), component.getHeight(), BufferedImage.TYPE_INT_RGB);
		component.paint(screenshot.getGraphics());
		File file = new File("screenshot_" + System.currentTimeMillis());
		try {
			ImageIO.write(screenshot, "png", file);
		} catch (IOException e) {
			throw new RuntimeException(file.getAbsolutePath(), e);
		}
	}

	/**
	 * Prepend a path to a file unless its specified as an absolute path.
	 */
	public static final String path(String prepend, String filename) {
		File file = new File(filename);
		if (file.isAbsolute()) return filename;
		return prepend + filename;
	}

	public static final int find(Object[] array, Object value) {
		for (int i = 0; i < array.length; i++)
			if (array[i].equals(value)) return i;
		return -1;
	}
}