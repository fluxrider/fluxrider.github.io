/*
 * TODO Copyright (c)
 */

package flux.util;

import java.awt.geom.Point2D;

import flux.math.M;

/**
 * 2D position transition.
 * 
 * @author David Lareau
 */

public class Transition2D {

	// Attributes
	private Transition t;
	private double fromX, fromY, toX, toY;

	// Construct
	public Transition2D() {
		this(0, 0);
	}

	public Transition2D(double constantX, double constantY) {
		this.fromX = constantX;
		this.fromY = constantY;
		this.toX = constantX;
		this.toY = constantY;
		t = new Transition(1);
	}

	public Transition2D(double fromX, double fromY, double toX, double toY, long durationMilliseconds, long delayMilliseconds, M.TimingFunction timingFunction, int loop, boolean backAndForth) {
		this.fromX = fromX;
		this.fromY = fromY;
		this.toX = toX;
		this.toY = toY;
		t = new Transition(0, 1, durationMilliseconds, delayMilliseconds, timingFunction, loop, backAndForth);
	}

	// Methods
	public void start(double constantX, double constantY) {
		this.fromX = constantX;
		this.fromY = constantY;
		this.toX = constantX;
		this.toY = constantY;
		t.start(1);
	}

	public void start(double fromX, double fromY, double toX, double toY, long durationMilliseconds, long delayMilliseconds, M.TimingFunction timingFunction, int loop, boolean backAndForth) {
		this.fromX = fromX;
		this.fromY = fromY;
		this.toX = toX;
		this.toY = toY;
		t.start(0, 1, durationMilliseconds, delayMilliseconds, timingFunction, loop, backAndForth);
	}

	public void start() {
		t.start();
	}

	public void pause() {
		t.pause();
	}

	public void resume() {
		t.resume();
	}

	public Point2D get() {
		double p = t.get();
		double x = M.linearBezier(p, fromX, toX);
		double y = M.linearBezier(p, fromY, toY);
		return new Point2D.Double(x, y);
	}

	public double getRatio() {
		return t.getRatio();
	}

	public double getTotalRatio() {
		return t.getTotalRatio();
	}

}
