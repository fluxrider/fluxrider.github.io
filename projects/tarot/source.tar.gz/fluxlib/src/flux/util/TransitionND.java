/*
 * TODO Copyright (c)
 */

package flux.util;

import flux.math.M;

/**
 * N dimension transition.
 * 
 * @author David Lareau
 */

public class TransitionND {

	// Attributes
	private Transition t;
	private double from[], to[];

	// Construct
	public TransitionND(int n) {
		from = new double[n];
		to = new double[n];
		for (int i = 0; i < n; i++) {
			from[i] = to[i] = 0;
		}
		t = new Transition(1);
	}

	public TransitionND(double[] constants) {
		int n = constants.length;
		from = new double[n];
		to = new double[n];
		for (int i = 0; i < n; i++) {
			from[i] = to[i] = constants[i];
		}
		t = new Transition(1);
	}

	public TransitionND(double from[], double to[], long durationMilliseconds, long delayMilliseconds, M.TimingFunction timingFunction, int loop, boolean backAndForth) {
		int n = from.length;
		if (n != to.length) throw new RuntimeException("Mismatch length: " + from.length + " != " + to.length);
		this.from = new double[n];
		this.to = new double[n];
		for (int i = 0; i < n; i++) {
			this.from[i] = from[i];
			this.to[i] = to[i];
		}
		t = new Transition(0, 1, durationMilliseconds, delayMilliseconds, timingFunction, loop, backAndForth);
	}

	// Methods
	public void start(double... constants) {
		if (constants.length != from.length) throw new RuntimeException("New length unsupported: " + constants.length + " != " + from.length);
		int n = constants.length;
		for (int i = 0; i < n; i++) {
			from[i] = to[i] = constants[i];
		}
		t.start(1);
	}

	public void start(double from[], double to[], long durationMilliseconds, long delayMilliseconds, M.TimingFunction timingFunction, int loop, boolean backAndForth) {
		int n = from.length;
		if (n != to.length) throw new RuntimeException("Mismatch length: " + from.length + " != " + to.length);
		if (n != this.from.length) throw new RuntimeException("New length unsupported: " + this.from.length + " != " + from.length);
		for (int i = 0; i < n; i++) {
			this.from[i] = from[i];
			this.to[i] = to[i];
		}
		t.start(0, 1, durationMilliseconds, delayMilliseconds, timingFunction, loop, backAndForth);
	}

	public void start() {
		t.start();
	}

	public void pause() {
		t.pause();
	}

	public void resume() {
		t.resume();
	}

	public double [] get(double[] out) {
		if(out == null) out = new double[from.length];
		double p = t.get();
		for (int i = 0; i < out.length; i++) {
			out[i] = M.linearBezier(p, from[i], to[i]);
		}
		return out;
	}

	public double getRatio() {
		return t.getRatio();
	}

	public double getTotalRatio() {
		return t.getTotalRatio();
	}

}
