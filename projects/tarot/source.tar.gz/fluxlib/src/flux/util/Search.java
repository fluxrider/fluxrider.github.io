/*
 * TODO Copyright (c)
 */
package flux.util;

import flux.data.OverwriteCircularArray_long;

/**
 * This class consists of search functions.
 * 
 * @author David Lareau
 */

public class Search {

	/**
	 * Binary search a sorted random access collection.
	 * 
	 * @return the index where the item was found, or the insert-index if not found. The insert index would be the new place when all including the
	 *         currently residing item at that index are pushed up by one.
	 */
	public static final int binarySearch(OverwriteCircularArray_long t, int min, int max, long value) {
		if (max < min) return min;
		int middle = (min + max) / 2;
		long v = t.get(middle);
		if (v < value) return binarySearch(t, middle + 1, max, value);
		if (v > value) return binarySearch(t, min, middle - 1, value);
		return middle;
	}

	public static final int binarySearch(OverwriteCircularArray_long t, long value) {
		return binarySearch(t, 0, t.size() - 1, value);
	}

}
