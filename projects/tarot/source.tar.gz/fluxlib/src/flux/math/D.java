/*
 * TODO Copyright (c)
 */
package flux.math;

/**
 * This class consists of distance functions.
 * 
 * @author David Lareau
 */

public class D {

	public static final double euclidean(double x0, double y0, double x1, double y1) {
		double dx = x1 - x0;
		double dy = y1 - y0;
		return Math.sqrt(dx * dx + dy * dy);
	}

	public static final double chebyshev(double x0, double y0, double x1, double y1) {
		double dx = x1 - x0;
		double dy = y1 - y0;
		return Math.max(dx, dy);
	}

	public static final double manhattan(double x0, double y0, double x1, double y1) {
		double dx = x1 - x0;
		double dy = y1 - y0;
		return dx + dy;
	}

}
