/*
 * TODO Copyright (c)
 */
package flux.math;

import java.math.BigInteger;

/**
 * This class consists of miscellaneous math functions missing from java.lang.Math.
 * 
 * @author David Lareau
 */

public class M {

	public static final int sign(double x) {
		if (x < 0) return -1;
		return 1;
	}

	/**
	 * Factorial (simple implementation)
	 */
	public static final BigInteger factorial(int n) {
		BigInteger ret = BigInteger.ONE;
		for (int i = 1; i <= n; i++)
			ret = ret.multiply(BigInteger.valueOf(i));
		return ret;
	}

	/**
	 * @return true if the double is inside [0, 1]
	 */
	public static final boolean isNormalized(double x) {
		return x >= 0 && x <= 1;
	}

	// Kinda Equals
	public static final double EPSILON = 0.00001;

	public static final boolean kindaEquals(double a, double b) {
		return kindaEquals(a, b, EPSILON);
	}

	public static final boolean kindaEquals(double a, double b, double epsilon) {
		return Math.abs(a - b) <= epsilon;
	}

	public static final boolean isInside(int x, int min, int max) {
		return x >= min && x <= max;
	}

	public static final boolean isInside(long x, long min, long max) {
		return x >= min && x <= max;
	}

	public static final boolean isInside(double x, double min, double max) {
		return x >= min && x <= max;
	}

	// Round
	public static final double round(double x, int decimals) {
		double p = Math.pow(10, decimals);
		return Math.round(x * p) / p;
	}

	public static final int r(double x) {
		return (int) Math.round(x);
	}

	// Cyclic values
	// [min, max[
	public static final double boundCyclic(double x, double minInclusive, double maxExclusive) {
		double range = maxExclusive - minInclusive;
		double normalized = boundCyclicNormalized((x - minInclusive) / range);
		return minInclusive + normalized * range;
	}

	// [0, 1[
	public static final double boundCyclicNormalized(double x) {
		if (x < 0) {
			if ((int) x - x == 0) return 0;
			return 1 - boundCyclicNormalized(-x);
		}
		return x - (int) x;
	}

	// [0, 1]
	public static final double boundCyclicBackAndForth(double x, double minInclusive, double maxInclusive) {
		double range = maxInclusive - minInclusive;
		double normalized = boundCyclicBackAndForthNormalized((x - minInclusive) / range);
		return minInclusive + normalized * range;
	}

	public static final double boundCyclicBackAndForthNormalized(double x) {
		if (x < 0) return boundCyclicBackAndForthNormalized(-x);
		int i = (int) x;
		double cyclic = boundCyclicNormalized(x);
		// if pair
		if (i % 2 == 0) {
			return cyclic;
		}
		// if odd
		else {
			return 1 - cyclic; // this is where if it was 0, now its exactly 1, so the max limit is inclusive
		}
	}

	public static final double boundCrop(double x, double minInclusive, double maxInclusive) {
		return Math.max(minInclusive, Math.min(x, maxInclusive));
	}

	public static final double boundCropNormalized(double x) {
		return Math.max(0, Math.min(x, 1));
	}

	public static final int nextIndex(int index, int capacity) {
		return (index + 1) % capacity;
	}

	public static final int previousIndex(int index, int capacity) {
		return (index + capacity - 1) % capacity;
	}

	public static final int boundCyclicInt(int x, int minInclusive, int maxInclusive) {
		return boundCyclicCapacity(x - minInclusive, maxInclusive - minInclusive + 1) + minInclusive;
	}

	public static final int boundCyclicCapacity(int x, int capacity) {
		if (x >= 0) return x % capacity;
		return x + (-(x + 1) / capacity + 1) * capacity;
	}

	// Bezier
	public static final double linearBezier(double t, double p0, double p1) {
		if (!isNormalized(t)) throw new RuntimeException("t must be [0,1] not " + t);
		return p0 + t * (p1 - p0);
	}

	public static final double quadraticBezier(double t, double p0, double p1, double p2) {
		if (!isNormalized(t)) throw new RuntimeException("t must be [0,1] not " + t);
		double T = 1 - t;
		return T * (T * p0 + t * p1) + t * (T * p1 + t * p2);
	}

	public static final double cubicBezier(double t, double p0, double p1, double p2, double p3) {
		// linear combination of two quadratic bezier curves
		return (1 - t) * quadraticBezier(t, p0, p1, p2) + t * quadraticBezier(t, p1, p2, p3);
	}

	/**
	 * Algorithms can be found in Bezier.java. I'm picking my favorite here. With experimentation the binary search is the best solution, it's simpler
	 * and faster than the other ones (see TestBezierSpeed.java)
	 */
	public static final double cubicBezierTimingFunction(double time, double x1, double y1, double x2, double y2) {
		return Bezier.cubicBezierTimingFunctionBinarySearch(time, x1, y1, x2, y2);
	}

	public enum TimingFunction {
		LINEAR(0, 0, 1, 1), EASE(.25, .1, .25, 1), EASE_IN(.42, 0, 1, 1), EASE_OUT(0, 0, .58, 1), EASE_IN_OUT(.42, 0, .58, 1);

		private double x1, y1, x2, y2;

		private TimingFunction(double x1, double y1, double x2, double y2) {
			this.x1 = x1;
			this.y1 = y1;
			this.x2 = x2;
			this.y2 = y2;
		}

		public double getX1() {
			return x1;
		}

		public double getY1() {
			return y1;
		}

		public double getX2() {
			return x2;
		}

		public double getY2() {
			return y2;
		}
	}

	public static final double timingFunction(double time, TimingFunction function) {
		return Bezier.cubicBezierTimingFunctionBinarySearch(time, function.getX1(), function.getY1(), function.getX2(), function.getY2());
	}

}
