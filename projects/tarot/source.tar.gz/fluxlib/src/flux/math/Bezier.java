/*
 * TODO Copyright (c)
 */
package flux.math;

import java.awt.geom.Point2D;
import java.math.BigInteger;

/**
 * This class consists of miscellaneous strategy for solving bezier curves. My favorite one is duplicated in M.java
 * 
 * @author David Lareau
 */

public class Bezier {

	/**
	 * Factorial (simple implementation)
	 */
	public static final BigInteger factorial(int n) {
		BigInteger ret = BigInteger.ONE;
		for (int i = 1; i <= n; i++)
			ret = ret.multiply(BigInteger.valueOf(i));
		return ret;
	}

	/**
	 * @return true if the double is inside [0, 1]
	 */
	public static final boolean isNormalized(double x) {
		return x >= 0 && x <= 1;
	}

	// Kinda Equals
	public static final double EPSILON = 0.00001;

	public static final boolean kindaEquals(double a, double b) {
		return kindaEquals(a, b, EPSILON);
	}

	public static final boolean kindaEquals(double a, double b, double epsilon) {
		return Math.abs(a - b) <= epsilon;
	}

	public static final boolean isInside(int x, int min, int max) {
		return x >= min && x <= max;
	}

	public static final boolean isInside(long x, long min, long max) {
		return x >= min && x <= max;
	}

	public static final boolean isInside(double x, double min, double max) {
		return x >= min && x <= max;
	}

	// Round
	public static final double round(double x, int decimals) {
		double p = Math.pow(10, decimals);
		return Math.round(x * p) / p;
	}

	// Bezier
	public static final double linearBezier(double t, double p0, double p1) {
		if (!isNormalized(t)) throw new RuntimeException("t must be [0,1] not " + t);
		return p0 + t * (p1 - p0);
	}

	public static final double quadraticBezier(double t, double p0, double p1, double p2) {
		if (!isNormalized(t)) throw new RuntimeException("t must be [0,1] not " + t);
		double T = 1 - t;
		return T * (T * p0 + t * p1) + t * (T * p1 + t * p2);
	}

	public static final double cubicBezier(double t, double p0, double p1, double p2, double p3) {
		// linear combination of two quadratic bezier curves
		return (1 - t) * quadraticBezier(t, p0, p1, p2) + t * quadraticBezier(t, p1, p2, p3);
	}

	// ======================================================
	// Solution #1: CODE TRANSCODED FROM: view-source:http://www.netzgesta.de/dev/cubic-bezier-timing-function.html
	// ======================================================
	// currently used function to determine position
	public static final Point2D CubicBezierAtPosition(double t, double P1x, double P1y, double P2x, double P2y) {
		double x, y, k = ((1 - t) * (1 - t) * (1 - t));
		x = P1x * (3 * t * t * (1 - t)) + P2x * (3 * t * (1 - t) * (1 - t)) + k;
		y = P1y * (3 * t * t * (1 - t)) + P2y * (3 * t * (1 - t) * (1 - t)) + k;
		return new Point2D.Double(Math.abs(x), Math.abs(y));
	};

	// currently used function to determine time
	// 1:1 conversion to js from webkit source files
	// UnitBezier.h, WebCore_animation_AnimationBase.cpp
	public static final double CubicBezierAtTime(double t, double p1x, double p1y, double p2x, double p2y, double duration) {
		double ax = 0, bx = 0, cx = 0, ay = 0, by = 0, cy = 0;
		// Calculate the polynomial coefficients, implicit first and last control points are (0,0) and (1,1).
		cx = 3.0 * p1x;
		bx = 3.0 * (p2x - p1x) - cx;
		ax = 1.0 - cx - bx;
		cy = 3.0 * p1y;
		by = 3.0 * (p2y - p1y) - cy;
		ay = 1.0 - cy - by;
		// Convert from input time to parametric value in curve, then from that to output time.
		return solve(t, solveEpsilon(duration), ax, bx, cx, ay, by, cy);
	};

	// `ax t^3 + bx t^2 + cx t' expanded using Horner's rule.
	public static final double sampleCurveX(double t, double ax, double bx, double cx) {
		return ((ax * t + bx) * t + cx) * t;
	}

	public static final double sampleCurveY(double t, double ay, double by, double cy) {
		return ((ay * t + by) * t + cy) * t;
	}

	public static final double sampleCurveDerivativeX(double t, double ax, double bx, double cx) {
		return (3.0 * ax * t + 2.0 * bx) * t + cx;
	}

	// The epsilon value to pass given that the animation is going to run over |dur| seconds. The longer the
	// animation, the more precision is needed in the timing function result to avoid ugly discontinuities.
	public static final double solveEpsilon(double duration) {
		return 1.0 / (200.0 * duration);
	}

	public static final double solve(double x, double epsilon, double ax, double bx, double cx, double ay, double by, double cy) {
		return sampleCurveY(solveCurveX(x, epsilon, ax, bx, cx), ay, by, cy);
	}

	// Given an x value, find a parametric value it came from.
	public static final double solveCurveX(double x, double epsilon, double ax, double bx, double cx) {
		double t0, t1, t2, x2, d2, i;
		// First try a few iterations of Newton's method -- normally very fast.
		for (t2 = x, i = 0; i < 8; i++) {
			x2 = sampleCurveX(t2, ax, bx, cx) - x;
			if (fabs(x2) < epsilon) {
				return t2;
			}
			d2 = sampleCurveDerivativeX(t2, ax, bx, cx);
			if (fabs(d2) < 1e-6) {
				break;
			}
			t2 = t2 - x2 / d2;
		}
		// Fall back to the bisection method for reliability.
		t0 = 0.0;
		t1 = 1.0;
		t2 = x;
		if (t2 < t0) {
			return t0;
		}
		if (t2 > t1) {
			return t1;
		}
		while (t0 < t1) {
			x2 = sampleCurveX(t2, ax, bx, cx);
			if (fabs(x2 - x) < epsilon) {
				return t2;
			}
			if (x > x2) {
				t0 = t2;
			} else {
				t1 = t2;
			}
			t2 = (t1 - t0) * .5 + t0;
		}
		return t2; // Failure.
	}

	public static final double fabs(double n) {
		if (n >= 0) {
			return n;
		} else {
			return 0 - n;
		}
	}

	// ======================================================
	// End of transcoded code
	// ======================================================

	// Solution #2: binary search
	public static final double cubicBezierTimingFunctionBinarySearch(double time, double x1, double y1, double x2, double y2) {
		if (!isNormalized(x1) || !isNormalized(y1) || !isNormalized(x2) || !isNormalized(y2)) throw new RuntimeException("For the timing function, the parameters must be [0,1]. You gave: " + x1 + "," + y1 + " " + x2 + "," + y2);
		if (!isNormalized(time)) throw new RuntimeException("For the timing function, time must be [0, 1] not " + time);

		// Binary search the parametric curve
		double tMin = 0;
		double tMax = 1;
		double t = .5;

		final int MAX_ITERATION = 100;
		for (int i = 0; i < MAX_ITERATION; i++) {
			double x = cubicBezier(t, 0, x1, x2, 1); // x = time axis
			if (kindaEquals(x, time)) return cubicBezier(t, 0, y1, y2, 1); // y = progress axis
			else if (x < time) tMin = t;
			else tMax = t;
			t = (tMin + tMax) / 2;
		}
		throw new RuntimeException("could not reach precision request: " + cubicBezier(t, 0, x1, x2, 1) + " != " + time);
	}

	// Solution #3: multi part linear interpolation
	public static final double cubicBezierTimingFunctionLinearApprox(double time, double x1, double y1, double x2, double y2) {
		// Make N lines to approximate the curve
		final int N = 100;
		double x[] = new double[N];
		double y[] = new double[N];
		for (int i = 0; i < N; i++) {
			double t = i / (double) (N - 1);
			x[i] = cubicBezier(t, 0, x1, x2, 1);
			y[i] = cubicBezier(t, 0, y1, y2, 1);
		}

		// find the line containing 'time'
		int l2 = 1;
		while (time > x[l2])
			l2++;
		int l1 = l2 - 1;

		// approximate 't' of 'time' on this line
		double t = (time - x[l1]) / (x[l2] - x[l1]);
		return linearBezier(t, y[l1], y[l2]);
	}

	// Solution #4: cached solution #3
	// Usage:
	// double x[] = cubicBezierTimingFunctionLinearApproxBuildCache(x1, x2, 100);
	// double y[] = cubicBezierTimingFunctionLinearApproxBuildCache(y1, y2, 100);
	// double progress = cubicBezierTimingFunctionLinearApproxCached(time, x, y);
	public static final double cubicBezierTimingFunctionLinearApproxCached(double time, double[] x, double[] y) {
		// find the line containing 'time'
		int l2 = 1;
		while (time > x[l2])
			l2++;
		int l1 = l2 - 1;

		// approximate 't' of 'time' on this line
		double t = (time - x[l1]) / (x[l2] - x[l1]);
		return linearBezier(t, y[l1], y[l2]);
	}

	public static final double[] cubicBezierTimingFunctionLinearApproxBuildCache(double p1, double p2, int N) {
		double p[] = new double[N];
		for (int i = 0; i < N; i++) {
			double t = i / (double) (N - 1);
			p[i] = cubicBezier(t, 0, p1, p2, 1);
		}
		return p;
	}

}
